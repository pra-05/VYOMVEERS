import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Float } from '@react-three/drei';
import { ArrowLeft, Check, Sparkles, User, Shield } from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { Astronaut3D } from '../3d/Astronaut3D';

const SUIT_COLORS = [
  { name: 'Moon White', value: '#FFFFFF' },
  { name: 'Cyan Neon', value: '#00D9FF' },
  { name: 'Mars Amber', value: '#FF9D42' },
  { name: 'Cosmic Blue', value: '#168BFF' },
  { name: 'Nebula Purple', value: '#8B5CF6' },
  { name: 'Stealth Black', value: '#1E293B' },
];

const ACCENT_COLORS = [
  { name: 'Cyan Glow', value: '#00D9FF' },
  { name: 'Neon Green', value: '#39FF14' },
  { name: 'Solar Gold', value: '#FFD700' },
  { name: 'Rocket Red', value: '#FF3B30' },
  { name: 'Deep Purple', value: '#8B5CF6' },
];

const VISOR_COLORS = [
  { name: 'Gold Mirror', value: '#FFD700' },
  { name: 'Holo Cyan', value: '#00D9FF' },
  { name: 'Obsidian Tint', value: '#151515' },
  { name: 'Ruby Glare', value: '#FF3B30' },
];

const BADGES: Array<{ id: 'artemis' | 'nasa_worm' | 'vyom_star' | 'mars_pathfinder'; label: string; desc: string }> = [
  { id: 'artemis', label: 'NASA Artemis', desc: 'Return to the Moon to stay' },
  { id: 'nasa_worm', label: 'NASA Retro Worm', desc: 'Iconic space heritage' },
  { id: 'vyom_star', label: 'VYOM Star', desc: 'Junior Astronaut Explorer' },
  { id: 'mars_pathfinder', label: 'Mars Pioneer', desc: 'First humans on the Red Planet' },
];

export const AstronautCustomizer: React.FC = () => {
  const astronaut = useGameStore((state) => state.astronaut);
  const updateAstronaut = useGameStore((state) => state.updateAstronaut);
  const setScreen = useGameStore((state) => state.setScreen);

  return (
    <div className="absolute inset-0 bg-[#061329] flex flex-col md:flex-row z-20">
      {/* --- LEFT: 3D ASTRONAUT INTERACTIVE PREVIEW --- */}
      <div className="w-full md:w-1/2 h-1/2 md:h-full relative flex flex-col">
        {/* Top Back Button */}
        <div className="absolute top-6 left-6 z-10 flex items-center space-x-3">
          <button
            onClick={() => setScreen('station')}
            className="flex items-center space-x-2 bg-[#0B1F3A]/80 hover:bg-[#168BFF]/40 border border-[#00D9FF]/40 rounded-xl px-4 py-2.5 text-xs text-white transition duration-200 shadow-lg"
          >
            <ArrowLeft className="w-4 h-4 text-[#00D9FF]" />
            <span>Command Station</span>
          </button>
        </div>

        {/* 3D Canvas */}
        <div className="w-full h-full">
          <Canvas camera={{ position: [0, 1.4, 3.8], fov: 45 }}>
            <ambientLight intensity={0.6} />
            <directionalLight position={[5, 8, 5]} intensity={1.5} color="#FFFFFF" />
            <pointLight position={[-4, 2, -2]} intensity={2.0} color={astronaut.accentColor} />
            <pointLight position={[4, 2, 2]} intensity={1.5} color="#00D9FF" />

            <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.4}>
              <group position={[0, -0.6, 0]}>
                <Astronaut3D scale={1.3} isFloating={false} />
              </group>
            </Float>

            {/* Pedestal platform */}
            <mesh position={[0, -0.65, 0]} receiveShadow>
              <cylinderGeometry args={[1.5, 1.7, 0.12, 32]} />
              <meshStandardMaterial color="#0B1F3A" metalness={0.8} roughness={0.2} />
            </mesh>
            <mesh position={[0, -0.58, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[1.2, 1.35, 32]} />
              <meshBasicMaterial color={astronaut.accentColor} />
            </mesh>

            <OrbitControls 
              enablePan={false} 
              minDistance={2.5} 
              maxDistance={6.0} 
              maxPolarAngle={Math.PI / 1.8} 
              minPolarAngle={Math.PI / 3} 
              autoRotate={true}
              autoRotateSpeed={1.0}
            />
          </Canvas>
        </div>

        {/* Hint text at bottom of canvas */}
        <div className="absolute bottom-4 left-6 text-[11px] text-slate-400 font-mono">
          Drag to orbit 360° • Scroll to zoom
        </div>
      </div>

      {/* --- RIGHT: CUSTOMIZATION CONTROL DECK --- */}
      <div className="w-full md:w-1/2 h-1/2 md:h-full bg-[#0B1F3A]/95 border-t md:border-t-0 md:border-l border-[#00D9FF]/30 p-6 overflow-y-auto flex flex-col justify-between">
        <div className="space-y-6">
          {/* Header */}
          <div>
            <div className="flex items-center space-x-2 text-xs text-[#00D9FF] font-mono mb-1">
              <User className="w-4 h-4" />
              <span>CREW SUIT SPECIFICATION BAY</span>
            </div>
            <h2 className="text-2xl font-bold font-orbitron text-white">Customize Astronaut</h2>
            <p className="text-xs text-slate-300">Choose colors and insignia for your personal NASA spacesuit.</p>
          </div>

          {/* Cadet Name Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 font-mono">
              ASTRONAUT CALLSIGN / NAME:
            </label>
            <input
              type="text"
              value={astronaut.name}
              onChange={(e) => updateAstronaut({ name: e.target.value })}
              maxLength={20}
              className="w-full bg-[#061329] border border-[#00D9FF]/40 rounded-xl px-4 py-2.5 text-white font-space font-semibold text-sm focus:outline-none focus:border-[#00D9FF]"
            />
          </div>

          {/* Suit Primary Color */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2 font-mono">
              PRIMARY SPACESUIT COLOR:
            </label>
            <div className="flex flex-wrap gap-2.5">
              {SUIT_COLORS.map((col) => (
                <button
                  key={col.value}
                  onClick={() => updateAstronaut({ suitColor: col.value, helmetColor: col.value })}
                  className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition ${
                    astronaut.suitColor === col.value
                      ? 'border-[#00D9FF] bg-[#168BFF]/30 text-white'
                      : 'border-slate-700 bg-[#061329] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <span className="w-3.5 h-3.5 rounded-full border border-black/40 shadow-inner" style={{ backgroundColor: col.value }} />
                  <span>{col.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Visor Mirror Color */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2 font-mono">
              HELMET VISOR REFLECTIVITY:
            </label>
            <div className="flex flex-wrap gap-2.5">
              {VISOR_COLORS.map((col) => (
                <button
                  key={col.value}
                  onClick={() => updateAstronaut({ visorColor: col.value })}
                  className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition ${
                    astronaut.visorColor === col.value
                      ? 'border-[#00D9FF] bg-[#168BFF]/30 text-white'
                      : 'border-slate-700 bg-[#061329] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <span className="w-3.5 h-3.5 rounded-full border border-black/40 shadow-inner" style={{ backgroundColor: col.value }} />
                  <span>{col.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Accent Stripe Color */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2 font-mono">
              GLOW ACCENT & GLOVES:
            </label>
            <div className="flex flex-wrap gap-2.5">
              {ACCENT_COLORS.map((col) => (
                <button
                  key={col.value}
                  onClick={() => updateAstronaut({ accentColor: col.value, glovesColor: col.value, bootsColor: col.value })}
                  className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition ${
                    astronaut.accentColor === col.value
                      ? 'border-[#00D9FF] bg-[#168BFF]/30 text-white'
                      : 'border-slate-700 bg-[#061329] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <span className="w-3.5 h-3.5 rounded-full border border-black/40 shadow-inner" style={{ backgroundColor: col.value }} />
                  <span>{col.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mission Patch / Badge */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2 font-mono">
              CHEST EXPEDITION BADGE:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {BADGES.map((badge) => (
                <button
                  key={badge.id}
                  onClick={() => updateAstronaut({ badge: badge.id })}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    astronaut.badge === badge.id
                      ? 'border-[#00D9FF] bg-[#168BFF]/25 shadow-md'
                      : 'border-slate-700 bg-[#061329] hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold text-white">{badge.label}</span>
                    {astronaut.badge === badge.id && <Check className="w-3.5 h-3.5 text-[#00D9FF]" />}
                  </div>
                  <div className="text-[10px] text-slate-400">{badge.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-6 border-t border-slate-700 flex space-x-3">
          <button
            onClick={() => setScreen('equipment')}
            className="flex-1 py-3.5 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:from-[#1a94ff] hover:to-[#22e3ff] text-slate-950 font-bold rounded-xl transition duration-200 font-orbitron text-xs tracking-wider flex items-center justify-center space-x-2 shadow-lg"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>SAVE & PROCEED TO EQUIPMENT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
