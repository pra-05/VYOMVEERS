import { EquipmentConfig } from '../types/game';

export interface EquipmentItemInfo {
  key: keyof EquipmentConfig;
  name: string;
  category: 'life_support' | 'power' | 'science' | 'safety';
  icon: string;
  min: number;
  max: number;
  defaultVal: number;
  weightPerUnitKg: number;
  description: string;
  effectExplanation: string;
  nasaFact: string;
}

export const EQUIPMENT_CATALOG: EquipmentItemInfo[] = [
  {
    key: 'oxygenTanks',
    name: 'High-Pressure O₂ Tanks',
    category: 'life_support',
    icon: 'Wind',
    min: 2,
    max: 6,
    defaultVal: 4,
    weightPerUnitKg: 35,
    description: 'Cryogenic carbon-composite tanks storing pressurized breathable oxygen (95% O₂ / 5% N₂ mix).',
    effectExplanation: '+20% starting oxygen supply and +15% reserve buffer for extended EVAs.',
    nasaFact: 'NASA space suits maintain a cabin pressure of 4.3 psi (about 30 kPa) with pure oxygen to prevent decompression sickness (the bends).'
  },
  {
    key: 'waterPurifiers',
    name: 'Closed-Loop Water Purifier',
    category: 'life_support',
    icon: 'Droplet',
    min: 2,
    max: 5,
    defaultVal: 3,
    weightPerUnitKg: 40,
    description: 'Multi-filtration membrane and catalytic oxidizer that recycles 98% of graywater and atmospheric moisture.',
    effectExplanation: '+25% water reserve capacity and reduces daily water consumption rate by 30%.',
    nasaFact: 'The ISS Water Recovery System purifies humidity condensate and astronaut sweat into water cleaner than municipal tap water on Earth!'
  },
  {
    key: 'foodRations',
    name: 'Nutrient-Dense Space Rations',
    category: 'life_support',
    icon: 'Utensils',
    min: 2,
    max: 6,
    defaultVal: 4,
    weightPerUnitKg: 20,
    description: 'Freeze-dried balanced rations fortified with calcium and Vitamin D to protect bone mineral density.',
    effectExplanation: '+20% food reserve. Prevents astronaut stamina depletion and cognitive fatigue.',
    nasaFact: 'NASA food scientists prepare thermostabilized, irradiated, and freeze-dried meals that retain nutrition for over 3 years in deep space.'
  },
  {
    key: 'solarPanels',
    name: 'Deployable Ultraflex Solar Wings',
    category: 'power',
    icon: 'Sun',
    min: 2,
    max: 5,
    defaultVal: 3,
    weightPerUnitKg: 50,
    description: 'High-efficiency multi-junction gallium arsenide photovoltaic cells that unfurl in circular arrays.',
    effectExplanation: 'Generates +30 kW power during planetary daytime. Must be kept dust-free for maximum efficiency.',
    nasaFact: 'Similar to the solar arrays powering NASA’s Lucy and Orion spacecraft, providing continuous power even under low-angle sunlight.'
  },
  {
    key: 'emergencyBatteries',
    name: 'Solid-State Lithium Backup Banks',
    category: 'power',
    icon: 'Zap',
    min: 1,
    max: 4,
    defaultVal: 2,
    weightPerUnitKg: 45,
    description: 'Extreme-temperature solid-state batteries that provide uninterrupted power through freezing planetary nights.',
    effectExplanation: 'Stores +25 units of reserve electricity to keep life support heaters warm during darkness.',
    nasaFact: 'Lunar nights last 14 Earth days, where temperatures plummet to -130°C! Battery heaters are essential to prevent electronics from freezing.'
  },
  {
    key: 'researchTools',
    name: 'X-Ray Raman Spectrometer & Core Drill',
    category: 'science',
    icon: 'Search',
    min: 1,
    max: 4,
    defaultVal: 2,
    weightPerUnitKg: 25,
    description: 'Precision mineralogy sensors and rotary-percussive sample coring drill for sub-surface planetary geology.',
    effectExplanation: '+40% Science XP bonus when analyzing rocks, regolith, and water-ice samples.',
    nasaFact: 'Similar to PIXL and SHERLOC instruments on NASA’s Perseverance rover searching for ancient chemical signatures of microbial life.'
  },
  {
    key: 'commRelays',
    name: 'Deep Space Optical Communications (DSOC)',
    category: 'science',
    icon: 'Radio',
    min: 1,
    max: 3,
    defaultVal: 2,
    weightPerUnitKg: 30,
    description: 'Near-infrared laser transceiver delivering high-bandwidth telemetry and mission data back to NASA Mission Control.',
    effectExplanation: 'Reduces telemetry latency, prevents data loss, and unlocks real-time NASA ground advice.',
    nasaFact: 'In 2023, NASA Psyche spacecraft streamed ultra-high-definition video from 31 million km away using laser communications!'
  },
  {
    key: 'firstAidKits',
    name: 'Autonomous Medical & Radiation Countermeasures',
    category: 'safety',
    icon: 'ShieldAlert',
    min: 1,
    max: 4,
    defaultVal: 2,
    weightPerUnitKg: 15,
    description: 'Radiation prophylactic radioprotectants, wound sealant gel, and biometric monitoring injectables.',
    effectExplanation: 'Instantly recovers 35% health/radiation protection during emergency medical events.',
    nasaFact: 'Deep-space astronauts are trained as Crew Medical Officers to treat trauma, decompression, and radiation exposure autonomously.'
  },
  {
    key: 'roverDrillModules',
    name: 'Subsurface Ultrasonic Drill Kit',
    category: 'science',
    icon: 'Hammer',
    min: 1,
    max: 3,
    defaultVal: 1,
    weightPerUnitKg: 35,
    description: 'Drill attachment for the rover to penetrate compacted permafrost regolith up to 1 meter deep.',
    effectExplanation: 'Allows extraction of deep-core ice samples and subterranean geological specimens.',
    nasaFact: 'NASA’s TRIDENT drill (The Regolith and Ice Drill for Exploring New Terrains) is designed to hammer 1 meter into the Moon to sample water ice.'
  }
];
