import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGameStore } from '../../store/useGameStore';

interface Outpost3DProps {
  scale?: number;
  position?: [number, number, number];
  destination?: 'moon' | 'mars';
}

export const Outpost3D: React.FC<Outpost3DProps> = ({
  scale = 1,
  position = [0, 0, 0],
  destination = 'moon'
}) => {
  const outpost = useGameStore((state) => state.outpost);
  const beaconRef = useRef<THREE.PointLight>(null);
  const solarRotRef = useRef<THREE.Group>(null);
  const greenhouseGlowRef = useRef<THREE.PointLight>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();

    // Pulse beacon light on communications tower
    if (beaconRef.current) {
      beaconRef.current.intensity = (Math.sin(t * 3) + 1) * 1.5 + 0.5;
    }

    // Gentle sun-tracking rotation for solar wings
    if (solarRotRef.current) {
      solarRotRef.current.rotation.y = Math.sin(t * 0.1) * 0.2;
    }

    // Greenhouse pulsation
    if (greenhouseGlowRef.current && outpost.greenhouseActive) {
      greenhouseGlowRef.current.intensity = 2.0 + Math.sin(t * 2) * 0.5;
    }
  });

  const baseColor = destination === 'moon' ? '#E2E8F0' : '#D1D5DB';

  return (
    <group position={position} scale={[scale, scale, scale]}>
      {/* --- CENTRAL PRESSURIZED HABITAT DOME --- */}
      <mesh position={[0, 2.2, 0]} castShadow receiveShadow>
        <sphereGeometry args={[4.2, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.5]} />
        <meshStandardMaterial 
          color={baseColor} 
          metalness={0.5} 
          roughness={0.35} 
        />
      </mesh>

      {/* Observation Cupola Windows at Dome Top */}
      <mesh position={[0, 4.25, 0]}>
        <sphereGeometry args={[1.2, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.4]} />
        <meshPhysicalMaterial 
          color="#00D9FF" 
          emissive="#00D9FF" 
          emissiveIntensity={0.4} 
          metalness={0.9} 
          roughness={0.1} 
          transparent 
          opacity={0.85} 
        />
      </mesh>

      {/* Outer Hexagonal Shielding Ring around Habitat */}
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[4.6, 4.8, 0.8, 6]} />
        <meshStandardMaterial color="#0B1F3A" metalness={0.8} roughness={0.3} />
      </mesh>

      {/* --- AIRLOCK MODULE TUNNEL & MAIN ENTRANCE --- */}
      <group position={[0, 0.9, 4.2]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.8, 1.8, 2.4]} />
          <meshStandardMaterial color="#334155" metalness={0.7} roughness={0.3} />
        </mesh>
        {/* Airlock Doorway */}
        <mesh position={[0, 0, 1.22]}>
          <boxGeometry args={[1.2, 1.5, 0.1]} />
          <meshStandardMaterial color="#FF9D42" metalness={0.6} roughness={0.4} />
        </mesh>
        {/* Airlock Status Glow Light */}
        <mesh position={[0, 0.95, 1.25]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.1, 0.1, 0.08, 12]} />
          <meshBasicMaterial color="#39FF14" />
        </mesh>
        <pointLight position={[0, 0.95, 1.4]} color="#39FF14" intensity={2} distance={4} />

        {/* Entrance Welcome Sign */}
        <mesh position={[0, 1.2, 1.24]}>
          <planeGeometry args={[1.4, 0.3]} />
          <meshBasicMaterial color="#00D9FF" />
        </mesh>
      </group>

      {/* --- HYDROPOPONIC GREENHOUSE MODULE (CONNECTED POD) --- */}
      <group position={[5.5, 1.6, 0]}>
        {/* Connecting Airlock Tube */}
        <mesh position={[-1.4, -0.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.9, 0.9, 2.0, 16]} />
          <meshStandardMaterial color="#475569" metalness={0.7} />
        </mesh>

        {/* Translucent Bio-Dome */}
        <mesh castShadow>
          <sphereGeometry args={[2.5, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55]} />
          <meshPhysicalMaterial 
            color="#22C55E" 
            roughness={0.2} 
            metalness={0.2} 
            transparent 
            opacity={outpost.greenhouseActive ? 0.65 : 0.3} 
            transmission={0.4} 
          />
        </mesh>
        {/* Hydroponic Plant Trays Inside */}
        <mesh position={[0, 0.2, 0]}>
          <cylinderGeometry args={[2.2, 2.3, 0.4, 16]} />
          <meshStandardMaterial color="#14532D" roughness={0.9} />
        </mesh>
        {/* Greenhouse Glow Light */}
        <pointLight 
          ref={greenhouseGlowRef} 
          position={[0, 1.2, 0]} 
          color="#39FF14" 
          intensity={outpost.greenhouseActive ? 3.0 : 0.2} 
          distance={8} 
        />
      </group>

      {/* --- SOLAR ARRAY WINGS FIELD --- */}
      <group ref={solarRotRef} position={[-5.8, 2.4, 0]}>
        {/* Pylon Stand */}
        <mesh position={[0, -1.2, 0]}>
          <cylinderGeometry args={[0.15, 0.2, 2.4, 12]} />
          <meshStandardMaterial color="#475569" metalness={0.8} />
        </mesh>
        {/* Horizontal Cross-Beam */}
        <mesh position={[0, 0.1, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.08, 0.08, 5.0, 12]} />
          <meshStandardMaterial color="#64748B" metalness={0.8} />
        </mesh>
        {/* Left Solar Wing */}
        <mesh position={[-1.5, 0.1, 0]} rotation={[0.4, 0, 0]}>
          <boxGeometry args={[2.4, 1.6, 0.06]} />
          <meshStandardMaterial 
            color={outpost.solarArraysClean ? '#0077EE' : '#8B7355'} 
            metalness={outpost.solarArraysClean ? 0.9 : 0.4} 
            roughness={outpost.solarArraysClean ? 0.15 : 0.8} 
          />
        </mesh>
        {/* Right Solar Wing */}
        <mesh position={[1.5, 0.1, 0]} rotation={[0.4, 0, 0]}>
          <boxGeometry args={[2.4, 1.6, 0.06]} />
          <meshStandardMaterial 
            color={outpost.solarArraysClean ? '#0077EE' : '#8B7355'} 
            metalness={outpost.solarArraysClean ? 0.9 : 0.4} 
            roughness={outpost.solarArraysClean ? 0.15 : 0.8} 
          />
        </mesh>
      </group>

      {/* --- MOXIE / ELECTROLYSIS OXYGEN GENERATOR TOWER --- */}
      <group position={[0, 1.8, -5.2]}>
        {/* Connecting Tube */}
        <mesh position={[0, -0.8, 1.4]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.6, 0.6, 2.0, 12]} />
          <meshStandardMaterial color="#475569" />
        </mesh>
        {/* High Pressure O2 Storage Spheres */}
        <mesh position={[-0.8, 0.4, 0]}>
          <sphereGeometry args={[0.8, 16, 16]} />
          <meshStandardMaterial color="#00D9FF" metalness={0.8} roughness={0.2} />
        </mesh>
        <mesh position={[0.8, 0.4, 0]}>
          <sphereGeometry args={[0.8, 16, 16]} />
          <meshStandardMaterial color="#00D9FF" metalness={0.8} roughness={0.2} />
        </mesh>
      </group>

      {/* --- COMMUNICATIONS MAST & SPACE WEATHER SENSOR --- */}
      <group position={[3.2, 0, -3.2]}>
        {/* Tower Truss */}
        <mesh position={[0, 3.5, 0]}>
          <cylinderGeometry args={[0.06, 0.25, 7.0, 8]} />
          <meshStandardMaterial color="#94A3B8" metalness={0.9} />
        </mesh>
        {/* Red Beacon at Mast Top */}
        <mesh position={[0, 7.05, 0]}>
          <sphereGeometry args={[0.15, 12, 12]} />
          <meshBasicMaterial color="#FF3B30" />
        </mesh>
        <pointLight ref={beaconRef} position={[0, 7.1, 0]} color="#FF3B30" intensity={2} distance={15} />
      </group>

      {/* --- BASE PERIMETER GROUND LIGHTS --- */}
      {[0, 1, 2, 3, 4, 5].map((idx) => {
        const ang = (idx * Math.PI) / 3;
        const r = 7.5;
        const lx = Math.cos(ang) * r;
        const lz = Math.sin(ang) * r;
        return (
          <group key={idx} position={[lx, 0.1, lz]}>
            <mesh>
              <cylinderGeometry args={[0.15, 0.18, 0.2, 12]} />
              <meshStandardMaterial color="#334155" />
            </mesh>
            <mesh position={[0, 0.12, 0]}>
              <sphereGeometry args={[0.08, 12, 12]} />
              <meshBasicMaterial color="#00D9FF" />
            </mesh>
          </group>
        );
      })}
    </group>
  );
};
