import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface Rocket3DProps {
  scale?: number;
  thrusterFiring?: boolean;
  legsExtended?: boolean;
  hatchOpen?: boolean;
  elevatorProgress?: number; // 0 (stowed at door) to 1 (at ground)
}

export const Rocket3D: React.FC<Rocket3DProps> = ({
  scale = 1,
  thrusterFiring = false,
  legsExtended = true,
  hatchOpen = false,
  elevatorProgress = 0
}) => {
  const flameRef = useRef<THREE.Group>(null);
  const smokeRef = useRef<THREE.Points>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (flameRef.current && thrusterFiring) {
      flameRef.current.scale.y = 1 + Math.sin(t * 25) * 0.25;
      flameRef.current.scale.x = 1 + Math.cos(t * 30) * 0.15;
      flameRef.current.scale.z = 1 + Math.sin(t * 28) * 0.15;
    }
  });

  return (
    <group scale={[scale, scale, scale]}>
      {/* --- MAIN FUSELAGE (Cylinder) --- */}
      <mesh position={[0, 4.5, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[1.3, 1.4, 6.5, 32]} />
        <meshStandardMaterial 
          color="#E6EDF5" 
          metalness={0.7} 
          roughness={0.25} 
        />
      </mesh>

      {/* Heat Shield Tiles on Windward Side */}
      <mesh position={[0, 4.5, 0.05]} rotation={[0, 0, 0]}>
        <cylinderGeometry args={[1.31, 1.41, 6.5, 32, 1, false, -Math.PI / 2, Math.PI]} />
        <meshStandardMaterial 
          color="#151A24" 
          metalness={0.3} 
          roughness={0.8} 
        />
      </mesh>

      {/* --- AERODYNAMIC NOSE CONE --- */}
      <mesh position={[0, 9.2, 0]} castShadow>
        <coneGeometry args={[1.3, 3.0, 32]} />
        <meshStandardMaterial color="#E6EDF5" metalness={0.7} roughness={0.25} />
      </mesh>

      {/* Nose Windows (Flight Deck Observational Cupola) */}
      <mesh position={[0, 8.8, 0.95]} rotation={[0.4, 0, 0]}>
        <boxGeometry args={[0.9, 0.35, 0.2]} />
        <meshPhysicalMaterial 
          color="#00D9FF" 
          emissive="#00D9FF" 
          emissiveIntensity={0.6} 
          metalness={0.9} 
          roughness={0.1} 
        />
      </mesh>

      {/* --- NASA / VYOMVEER LOGO BAND --- */}
      <mesh position={[0, 6.2, 0]}>
        <cylinderGeometry args={[1.33, 1.33, 0.7, 32]} />
        <meshStandardMaterial color="#168BFF" roughness={0.4} />
      </mesh>
      {/* Red Accent Trim */}
      <mesh position={[0, 5.8, 0]}>
        <cylinderGeometry args={[1.34, 1.34, 0.08, 32]} />
        <meshStandardMaterial color="#FF3B30" />
      </mesh>

      {/* --- AIRLOCK HATCH & ELEVATOR SYSTEM --- */}
      {/* Hatch Frame */}
      <mesh position={[0, 3.8, 1.32]} rotation={[0, 0, 0]}>
        <boxGeometry args={[0.9, 1.5, 0.15]} />
        <meshStandardMaterial color="#0B1F3A" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Hatch Door (opens outward/upward if hatchOpen) */}
      <group position={[0, 4.5, 1.38]} rotation={[hatchOpen ? -Math.PI / 1.8 : 0, 0, 0]}>
        <mesh position={[0, -0.7, 0]}>
          <boxGeometry args={[0.78, 1.35, 0.08]} />
          <meshStandardMaterial color="#FF9D42" metalness={0.5} roughness={0.4} />
        </mesh>
        {/* Hatch Portal Window */}
        <mesh position={[0, -0.4, 0.05]}>
          <circleGeometry args={[0.15, 16]} />
          <meshBasicMaterial color="#00D9FF" />
        </mesh>
      </group>

      {/* Elevator Platform / Descent Winch System */}
      {/* Elevator Guide Cables */}
      <mesh position={[-0.35, 2.2, 1.6]}>
        <cylinderGeometry args={[0.015, 0.015, 3.6, 8]} />
        <meshBasicMaterial color="#888888" />
      </mesh>
      <mesh position={[0.35, 2.2, 1.6]}>
        <cylinderGeometry args={[0.015, 0.015, 3.6, 8]} />
        <meshBasicMaterial color="#888888" />
      </mesh>

      {/* Moving Elevator Basket Platform: travels from y=3.2 down to y=0.15 */}
      <group position={[0, 3.2 - elevatorProgress * 3.05, 1.6]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.0, 0.08, 0.9]} />
          <meshStandardMaterial color="#223344" metalness={0.8} roughness={0.3} />
        </mesh>
        {/* Safety Guardrails */}
        <mesh position={[-0.45, 0.35, 0]}>
          <boxGeometry args={[0.04, 0.65, 0.85]} />
          <meshStandardMaterial color="#FF9D42" />
        </mesh>
        <mesh position={[0.45, 0.35, 0]}>
          <boxGeometry args={[0.04, 0.65, 0.85]} />
          <meshStandardMaterial color="#FF9D42" />
        </mesh>
        <mesh position={[0, 0.35, -0.4]}>
          <boxGeometry args={[0.9, 0.65, 0.04]} />
          <meshStandardMaterial color="#FF9D42" />
        </mesh>
      </group>

      {/* --- FORWARD CANARDS / FLAPS --- */}
      <mesh position={[1.45, 8.2, 0]} rotation={[0, 0, -0.3]}>
        <boxGeometry args={[1.0, 0.1, 0.8]} />
        <meshStandardMaterial color="#E6EDF5" metalness={0.6} />
      </mesh>
      <mesh position={[-1.45, 8.2, 0]} rotation={[0, 0, 0.3]}>
        <boxGeometry args={[1.0, 0.1, 0.8]} />
        <meshStandardMaterial color="#E6EDF5" metalness={0.6} />
      </mesh>

      {/* --- AFT STABILIZER FINS --- */}
      <mesh position={[1.7, 2.2, 0]} rotation={[0, 0, -0.2]}>
        <boxGeometry args={[1.4, 0.12, 1.8]} />
        <meshStandardMaterial color="#151A24" metalness={0.5} />
      </mesh>
      <mesh position={[-1.7, 2.2, 0]} rotation={[0, 0, 0.2]}>
        <boxGeometry args={[1.4, 0.12, 1.8]} />
        <meshStandardMaterial color="#151A24" metalness={0.5} />
      </mesh>

      {/* --- LANDING LEGS (4 Quad-pods) --- */}
      {legsExtended && (
        <group>
          {[0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2].map((angle, i) => {
            const r = 1.35;
            const x = Math.cos(angle) * r;
            const z = Math.sin(angle) * r;
            const footX = Math.cos(angle) * 2.3;
            const footZ = Math.sin(angle) * 2.3;
            return (
              <group key={i}>
                {/* Leg Upper Strut */}
                <mesh position={[(x + footX) / 2, 0.75, (z + footZ) / 2]} rotation={[0, -angle, 0.45]}>
                  <cylinderGeometry args={[0.09, 0.09, 2.1, 12]} />
                  <meshStandardMaterial color="#445566" metalness={0.8} roughness={0.3} />
                </mesh>
                {/* Landing Foot Pad */}
                <mesh position={[footX, 0.05, footZ]} receiveShadow>
                  <cylinderGeometry args={[0.38, 0.45, 0.1, 16]} />
                  <meshStandardMaterial color="#2B3A4A" metalness={0.7} />
                </mesh>
              </group>
            );
          })}
        </group>
      )}

      {/* --- ROCKET ENGINE CLUSTER (RAPTOR ENGINES) --- */}
      <group position={[0, 1.15, 0]}>
        {/* Center Engine Bell */}
        <mesh position={[0, -0.4, 0]}>
          <cylinderGeometry args={[0.2, 0.45, 0.7, 24, 1, true]} />
          <meshStandardMaterial color="#333333" metalness={0.9} roughness={0.2} side={THREE.DoubleSide} />
        </mesh>
        {/* Outer Engine Bells */}
        {[0, Math.PI * 0.66, Math.PI * 1.33].map((ang, i) => (
          <mesh key={i} position={[Math.cos(ang) * 0.55, -0.35, Math.sin(ang) * 0.55]}>
            <cylinderGeometry args={[0.18, 0.38, 0.6, 20, 1, true]} />
            <meshStandardMaterial color="#333333" metalness={0.9} roughness={0.2} side={THREE.DoubleSide} />
          </mesh>
        ))}

        {/* --- DYNAMIC THRUSTER FLAME & PLASMA GLOW --- */}
        {thrusterFiring && (
          <group ref={flameRef} position={[0, -0.8, 0]}>
            {/* Core blue shock diamond flame */}
            <mesh position={[0, -1.2, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.5, 2.4, 24]} />
              <meshBasicMaterial color="#00D9FF" transparent opacity={0.85} />
            </mesh>
            {/* Outer violent orange expansion flame */}
            <mesh position={[0, -1.6, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.85, 3.5, 24]} />
              <meshBasicMaterial color="#FF9D42" transparent opacity={0.65} />
            </mesh>
            {/* Engine Point Light illuminating ground and rocket hull */}
            <pointLight color="#FF9D42" intensity={18} distance={20} decay={2} />
            <pointLight color="#00D9FF" intensity={12} distance={8} decay={2} />
          </group>
        )}
      </group>
    </group>
  );
};
