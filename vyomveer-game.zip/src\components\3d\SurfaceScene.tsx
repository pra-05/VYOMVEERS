import React, { useRef, useState, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Stars } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore } from '../../store/useGameStore';
import { Astronaut3D } from './Astronaut3D';
import { Rover3D } from './Rover3D';
import { Rocket3D } from './Rocket3D';
import { Outpost3D } from './Outpost3D';
import { HoloPlanet } from './PlanetsHolo';
import { soundManager } from '../../utils/soundEffects';

interface SurfaceSceneProps {
  onNearSample?: (sampleId: string | null) => void;
  onNearRover?: (near: boolean) => void;
  onNearOutpost?: (near: boolean) => void;
}

export const SurfaceScene: React.FC<SurfaceSceneProps> = ({
  onNearSample,
  onNearRover,
  onNearOutpost
}) => {
  const { camera } = useThree();
  const selectedMission = useGameStore((state) => state.selectedMission);
  const vehicleMode = useGameStore((state) => state.vehicleMode);
  const astronautPosition = useGameStore((state) => state.astronautPosition);
  const roverPosition = useGameStore((state) => state.roverPosition);
  const roverRotation = useGameStore((state) => state.roverRotation);
  const setAstronautPosition = useGameStore((state) => state.setAstronautPosition);
  const setRoverPosition = useGameStore((state) => state.setRoverPosition);
  const samples = useGameStore((state) => state.samples);
  const collectSample = useGameStore((state) => state.collectSample);
  const toggleVehicleMode = useGameStore((state) => state.toggleVehicleMode);
  const setScreen = useGameStore((state) => state.setScreen);

  // Movement input tracking
  const [keys, setKeys] = useState({
    w: false,
    a: false,
    s: false,
    d: false,
    space: false,
    e: false
  });

  const [isJumping, setIsJumping] = useState(false);
  const jumpVelocityRef = useRef(0);
  const isWalking = (keys.w || keys.s || keys.a || keys.d) && vehicleMode === 'astronaut';
  const isDriving = (keys.w || keys.s || keys.a || keys.d) && vehicleMode === 'rover';

  const isMoon = selectedMission === 'moon';
  const gravity = isMoon ? 1.62 : 3.72; // m/s^2
  const terrainColor = isMoon ? '#475569' : '#993D22';
  const skyColor = isMoon ? '#061329' : '#451A14';

  // Listen to keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') setKeys(prev => ({ ...prev, w: true }));
      if (k === 's' || k === 'arrowdown') setKeys(prev => ({ ...prev, s: true }));
      if (k === 'a' || k === 'arrowleft') setKeys(prev => ({ ...prev, a: true }));
      if (k === 'd' || k === 'arrowright') setKeys(prev => ({ ...prev, d: true }));
      if (k === ' ') {
        e.preventDefault();
        setKeys(prev => ({ ...prev, space: true }));
      }
      if (k === 'e') {
        // Interaction key
        checkInteractions();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') setKeys(prev => ({ ...prev, w: false }));
      if (k === 's' || k === 'arrowdown') setKeys(prev => ({ ...prev, s: false }));
      if (k === 'a' || k === 'arrowleft') setKeys(prev => ({ ...prev, a: false }));
      if (k === 'd' || k === 'arrowright') setKeys(prev => ({ ...prev, d: false }));
      if (k === ' ') setKeys(prev => ({ ...prev, space: false }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [vehicleMode, astronautPosition, roverPosition, samples]);

  const checkInteractions = () => {
    const playerX = vehicleMode === 'astronaut' ? astronautPosition[0] : roverPosition[0];
    const playerZ = vehicleMode === 'astronaut' ? astronautPosition[2] : roverPosition[2];

    // Check proximity to uncollected samples
    for (const sample of samples) {
      if (!sample.collected) {
        const dist = Math.hypot(playerX - sample.position[0], playerZ - sample.position[2]);
        if (dist < 4.5) {
          collectSample(sample.id);
          return;
        }
      }
    }

    // Check proximity to Rover (if on foot)
    if (vehicleMode === 'astronaut') {
      const distToRover = Math.hypot(astronautPosition[0] - roverPosition[0], astronautPosition[2] - roverPosition[2]);
      if (distToRover < 4.0) {
        toggleVehicleMode();
        return;
      }
    } else {
      // If inside rover, pressing E dismounts to walking
      toggleVehicleMode();
      return;
    }

    // Check proximity to Outpost entrance (at [16, 0, -10])
    const distToOutpost = Math.hypot(playerX - 16, playerZ - (-10));
    if (distToOutpost < 7.0) {
      setScreen('outpost_mgmt');
    }
  };

  useFrame((state, delta) => {
    const dt = Math.min(0.1, delta);

    // --- ASTRONAUT WALKING & JUMPING CONTROLS ---
    if (vehicleMode === 'astronaut') {
      const moveSpeed = 4.5;
      let dx = 0;
      let dz = 0;

      if (keys.w) dz -= moveSpeed * dt;
      if (keys.s) dz += moveSpeed * dt;
      if (keys.a) dx -= moveSpeed * dt;
      if (keys.d) dx += moveSpeed * dt;

      // Normalize diagonal movement
      if (dx !== 0 && dz !== 0) {
        dx *= 0.707;
        dz *= 0.707;
      }

      // Jump Physics
      let currentY = astronautPosition[1];
      if (keys.space && !isJumping && currentY <= 0.05) {
        setIsJumping(true);
        // Moon jump is higher and floatier
        jumpVelocityRef.current = isMoon ? 4.2 : 3.0;
        soundManager.playClick();
      }

      if (isJumping || currentY > 0) {
        currentY += jumpVelocityRef.current * dt;
        jumpVelocityRef.current -= gravity * dt;
        if (currentY <= 0) {
          currentY = 0;
          setIsJumping(false);
          jumpVelocityRef.current = 0;
        }
      }

      const newPos: [number, number, number] = [
        astronautPosition[0] + dx,
        currentY,
        astronautPosition[2] + dz
      ];

      setAstronautPosition(newPos);

      // Camera smoothly follows astronaut
      camera.position.x = THREE.MathUtils.lerp(camera.position.x, newPos[0], 0.08);
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, newPos[1] + 3.5, 0.08);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, newPos[2] + 7.5, 0.08);
      camera.lookAt(newPos[0], newPos[1] + 1.2, newPos[2]);

    } else {
      // --- ROVER DRIVING CONTROLS ---
      const driveSpeed = 8.5; // Faster than walking
      const turnSpeed = 2.2;
      let steer = 0;
      let throttle = 0;

      if (keys.a) steer += turnSpeed * dt;
      if (keys.d) steer -= turnSpeed * dt;
      if (keys.w) throttle += driveSpeed * dt;
      if (keys.s) throttle -= (driveSpeed * 0.5) * dt; // slower reverse

      const newRotation = roverRotation + steer;
      const forwardX = Math.sin(newRotation) * throttle;
      const forwardZ = Math.cos(newRotation) * throttle;

      const newRoverPos: [number, number, number] = [
        roverPosition[0] + forwardX,
        0,
        roverPosition[2] + forwardZ
      ];

      setRoverPosition(newRoverPos, newRotation);
      // Keep astronaut position synced with rover so when player exits they are right by the rover
      setAstronautPosition([newRoverPos[0] + 1.5, 0, newRoverPos[2]]);

      if (isDriving) {
        soundManager.setRoverSpeed(0.8);
      }

      // Camera smoothly tracks rover with chase perspective
      const camDist = 9.0;
      const camHeight = 4.5;
      const targetCamX = newRoverPos[0] - Math.sin(newRotation) * camDist;
      const targetCamZ = newRoverPos[2] - Math.cos(newRotation) * camDist;

      camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetCamX, 0.08);
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, newRoverPos[1] + camHeight, 0.08);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, targetCamZ, 0.08);
      camera.lookAt(newRoverPos[0], newRoverPos[1] + 1.2, newRoverPos[2]);
    }

    // Check proximity for HUD prompts
    const activeX = vehicleMode === 'astronaut' ? astronautPosition[0] : roverPosition[0];
    const activeZ = vehicleMode === 'astronaut' ? astronautPosition[2] : roverPosition[2];

    // Proximity to uncollected sample
    let nearbySampleId: string | null = null;
    for (const sample of samples) {
      if (!sample.collected) {
        const d = Math.hypot(activeX - sample.position[0], activeZ - sample.position[2]);
        if (d < 4.5) {
          nearbySampleId = sample.id;
          break;
        }
      }
    }
    if (onNearSample) onNearSample(nearbySampleId);

    // Proximity to rover
    if (vehicleMode === 'astronaut' && onNearRover) {
      const dRover = Math.hypot(astronautPosition[0] - roverPosition[0], astronautPosition[2] - roverPosition[2]);
      onNearRover(dRover < 4.0);
    } else if (onNearRover) {
      onNearRover(false);
    }

    // Proximity to outpost
    if (onNearOutpost) {
      const dOutpost = Math.hypot(activeX - 16, activeZ - (-10));
      onNearOutpost(dOutpost < 7.0);
    }
  });

  return (
    <>
      <ambientLight intensity={isMoon ? 0.35 : 0.65} />
      <directionalLight 
        position={[25, 35, 15]} 
        intensity={isMoon ? 2.0 : 1.6} 
        color="#FFFFFF" 
        castShadow 
      />
      <color attach="background" args={[skyColor]} />
      {isMoon && <Stars radius={150} depth={60} count={6000} factor={4} fade />}

      {/* Earth or Sun in sky */}
      {isMoon ? (
        <group position={[-35, 25, -60]}>
          <HoloPlanet planet="earth" radius={8} showAtmosphere={true} />
        </group>
      ) : (
        <group position={[-25, 30, -50]}>
          <HoloPlanet planet="sun" radius={3.5} showAtmosphere={true} />
        </group>
      )}

      {/* --- ASTRONAUT ON FOOT --- */}
      {vehicleMode === 'astronaut' && (
        <group position={astronautPosition}>
          <Astronaut3D 
            scale={1.0} 
            isWalking={isWalking} 
            isJumping={isJumping} 
          />
        </group>
      )}

      {/* --- ROVER VEHICLE --- */}
      <group position={roverPosition} rotation={[0, roverRotation, 0]}>
        <Rover3D 
          scale={1.1} 
          isDriving={isDriving} 
          speedRatio={isDriving ? 1 : 0} 
          isPlayerInside={vehicleMode === 'rover'} 
        />
      </group>

      {/* --- TOUCHED-DOWN ROCKET (LANDING PAD AT ORIGIN [0, 0, 0]) --- */}
      <group position={[0, 0, 0]}>
        <Rocket3D 
          scale={1.2} 
          thrusterFiring={false} 
          legsExtended={true} 
          hatchOpen={true} 
          elevatorProgress={1.0} 
        />
      </group>

      {/* Landing Pad Base */}
      <mesh position={[0, 0.02, 0]} receiveShadow>
        <cylinderGeometry args={[5.5, 5.8, 0.15, 6]} />
        <meshStandardMaterial color="#1E293B" metalness={0.6} roughness={0.5} />
      </mesh>

      {/* --- RESEARCH OUTPOST BASE AT [16, 0, -10] --- */}
      <group position={[16, 0, -10]}>
        <Outpost3D scale={1.0} destination={selectedMission} />
      </group>

      {/* --- SCIENTIFIC SAMPLES SPREAD ACROSS TERRAIN --- */}
      {samples.map((sample) => {
        if (sample.collected) return null;
        return (
          <group key={sample.id} position={sample.position}>
            {/* 3D Scientific Sample Mineral Rock / Ice Core */}
            <mesh position={[0, 0.35, 0]} castShadow>
              {sample.type === 'water_ice' ? (
                <octahedronGeometry args={[0.45]} />
              ) : (
                <dodecahedronGeometry args={[0.5]} />
              )}
              <meshStandardMaterial 
                color={
                  sample.type === 'water_ice' ? '#00D9FF' :
                  sample.type === 'martian_hematite' ? '#991B1B' :
                  sample.type === 'lunar_anorthosite' ? '#E2E8F0' : '#475569'
                }
                metalness={sample.type === 'water_ice' ? 0.8 : 0.2}
                roughness={sample.type === 'water_ice' ? 0.1 : 0.8}
                emissive={sample.type === 'water_ice' ? '#00D9FF' : '#FF9D42'}
                emissiveIntensity={0.3}
              />
            </mesh>

            {/* Pulsing Science Hologram Beacon */}
            <mesh position={[0, 2.0, 0]}>
              <cylinderGeometry args={[0.04, 0.04, 3.2, 8]} />
              <meshBasicMaterial 
                color={sample.type === 'water_ice' ? '#00D9FF' : '#FF9D42'} 
                transparent 
                opacity={0.6} 
              />
            </mesh>

            {/* Glowing Beacon Diamond */}
            <mesh position={[0, 3.8, 0]} rotation={[0, Math.PI / 4, 0]}>
              <octahedronGeometry args={[0.25]} />
              <meshBasicMaterial color={sample.type === 'water_ice' ? '#00D9FF' : '#FF9D42'} />
            </mesh>
            <pointLight 
              position={[0, 1.5, 0]} 
              color={sample.type === 'water_ice' ? '#00D9FF' : '#FF9D42'} 
              intensity={2.5} 
              distance={6} 
            />
          </group>
        );
      })}

      {/* --- PLANETARY VAST TERRAIN SURFACE --- */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[180, 180, 64, 64]} />
        <meshStandardMaterial 
          color={terrainColor} 
          roughness={0.92} 
          metalness={0.08} 
        />
      </mesh>

      {/* Surface Boulders & Crater Formations */}
      {[
        [-12, 0, 14, 1.4],
        [-22, 0, -8, 2.2],
        [8, 0, 18, 1.6],
        [24, 0, 10, 1.9],
        [-18, 0, 26, 2.5],
        [14, 0, -22, 1.7],
        [-28, 0, -22, 2.8]
      ].map(([bx, by, bz, bscale], idx) => (
        <group key={idx} position={[bx, by, bz]} scale={[bscale, bscale * 0.7, bscale]}>
          <mesh castShadow receiveShadow>
            <dodecahedronGeometry args={[1.0]} />
            <meshStandardMaterial 
              color={isMoon ? '#334155' : '#7C2D12'} 
              roughness={0.95} 
            />
          </mesh>
        </group>
      ))}
    </>
  );
};
