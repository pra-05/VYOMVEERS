import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Stars, Float, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { Astronaut3D } from './Astronaut3D';
import { HoloPlanet } from './PlanetsHolo';

export const SpaceStationScene: React.FC = () => {
  const stationGroupRef = useRef<THREE.Group>(null);
  const ringRotateRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (ringRotateRef.current) {
      ringRotateRef.current.rotation.y += delta * 0.08;
    }
  });

  return (
    <>
      {/* Dynamic Orbital Space Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 15, 10]} intensity={1.8} color="#FFFFFF" castShadow />
      <pointLight position={[-8, 4, -4]} intensity={2.5} color="#00D9FF" distance={20} />
      <pointLight position={[8, 3, -4]} intensity={2.0} color="#8B5CF6" distance={20} />
      <pointLight position={[0, -2, 5]} intensity={1.5} color="#168BFF" distance={15} />

      {/* Deep Cosmos Background with Stars */}
      <color attach="background" args={['#061329']} />
      <Stars radius={150} depth={60} count={6000} factor={4} saturation={0.8} fade speed={1.2} />

      {/* Camera Controls for exploration */}
      <OrbitControls 
        enablePan={false} 
        enableZoom={true} 
        minDistance={3.5} 
        maxDistance={14} 
        maxPolarAngle={Math.PI / 1.75} 
        minPolarAngle={Math.PI / 3.5} 
        autoRotate={false} 
      />

      {/* --- EARTH OUTSIDE THE CUPOLA OBSERVATION WINDOW --- */}
      <group position={[0, -6, -22]}>
        <HoloPlanet planet="earth" radius={9} rotationSpeed={0.06} showAtmosphere={true} />
      </group>

      {/* --- HOLOGRAPHIC PLANETS IN THE STATION HUB --- */}
      <group position={[-3.8, 1.8, -2]}>
        <HoloPlanet planet="moon" radius={0.8} rotationSpeed={0.15} />
      </group>
      <group position={[3.8, 1.8, -2]}>
        <HoloPlanet planet="mars" radius={0.95} rotationSpeed={0.12} />
      </group>

      {/* --- 3D ASTRONAUT FLOATING IN ZERO GRAVITY --- */}
      <Float speed={2} rotationIntensity={0.4} floatIntensity={0.8}>
        <group position={[0, 0, 0]}>
          <Astronaut3D scale={1.2} isFloating={true} />
        </group>
      </Float>

      {/* --- FUTURISTIC SPACE STATION MODULE INTERIOR --- */}
      <group ref={stationGroupRef}>
        {/* Curved Circular Modular Hull Ring */}
        <mesh position={[0, 0, 0]} rotation={[0, 0, 0]}>
          <cylinderGeometry args={[7.5, 7.5, 9, 36, 1, true]} />
          <meshStandardMaterial 
            color="#0B1F3A" 
            metalness={0.7} 
            roughness={0.4} 
            side={THREE.BackSide} 
          />
        </mesh>

        {/* Observation Panoramic Window Frame (Arch Cutouts facing Earth) */}
        <mesh position={[0, 0, -6.8]}>
          <ringGeometry args={[2.5, 7.4, 32]} />
          <meshStandardMaterial color="#061329" metalness={0.8} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
        {/* Translucent Window Glass */}
        <mesh position={[0, 0, -6.7]}>
          <circleGeometry args={[5.2, 32]} />
          <meshPhysicalMaterial 
            color="#00D9FF" 
            transparent 
            opacity={0.12} 
            roughness={0.05} 
            metalness={0.9} 
            transmission={0.9} 
          />
        </mesh>

        {/* Structural Hexagonal Reinforcement Ribs */}
        {[-3, 0, 3].map((yOffset, i) => (
          <mesh key={i} position={[0, yOffset, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[7.4, 0.12, 12, 36]} />
            <meshStandardMaterial color="#00D9FF" emissive="#00D9FF" emissiveIntensity={0.4} />
          </mesh>
        ))}

        {/* Station Deck Floor Platform */}
        <mesh position={[0, -3.2, 0]} receiveShadow>
          <cylinderGeometry args={[5.5, 5.5, 0.4, 24]} />
          <meshStandardMaterial color="#11223A" metalness={0.8} roughness={0.3} />
        </mesh>

        {/* Floor Holographic Target Ring */}
        <group ref={ringRotateRef} position={[0, -2.95, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <mesh>
            <ringGeometry args={[2.0, 2.15, 32]} />
            <meshBasicMaterial color="#00D9FF" transparent opacity={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh>
            <ringGeometry args={[3.2, 3.28, 48]} />
            <meshBasicMaterial color="#168BFF" transparent opacity={0.4} side={THREE.DoubleSide} />
          </mesh>
        </group>

        {/* Glowing Science Control Consoles around Deck */}
        {[Math.PI * 0.25, Math.PI * 0.75, Math.PI * 1.25, Math.PI * 1.75].map((ang, i) => {
          const cx = Math.sin(ang) * 4.4;
          const cz = Math.cos(ang) * 4.4;
          return (
            <group key={i} position={[cx, -2.2, cz]} rotation={[0, ang + Math.PI, 0]}>
              {/* Console Stand */}
              <mesh castShadow>
                <boxGeometry args={[1.6, 1.4, 0.7]} />
                <meshStandardMaterial color="#1E2E48" metalness={0.7} />
              </mesh>
              {/* Holographic Screen Display */}
              <mesh position={[0, 0.8, -0.05]} rotation={[-0.35, 0, 0]}>
                <planeGeometry args={[1.3, 0.7]} />
                <meshBasicMaterial color="#00D9FF" transparent opacity={0.85} side={THREE.DoubleSide} />
              </mesh>
            </group>
          );
        })}
      </group>
    </>
  );
};
