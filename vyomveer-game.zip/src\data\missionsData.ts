import { MissionData } from '../types/game';

export const MISSIONS_DATA: Record<'moon' | 'mars', MissionData> = {
  moon: {
    id: 'moon',
    title: 'ARTEMIS LUNAR BASE CAMP',
    subtitle: 'Project Shackleton South Pole Expedition',
    planetName: 'The Moon (Luna)',
    gravity: 1.62,
    tempRange: '-130°C to +120°C',
    commDelay: '1.28 seconds',
    distance: '384,400 km from Earth',
    description: 'Establish humanity’s permanent presence at the Lunar South Pole! Harvest deep crater water-ice, set up solar power arrays on eternal light peaks, and test deep-space living systems for future Mars exploration.',
    objectives: [
      {
        id: 'obj_moon_land',
        text: 'Land the Artemis Starship safely on the Shackleton landing pad',
        completed: false,
        xp: 150,
        hint: 'Use the landing thrusters during descent.'
      },
      {
        id: 'obj_moon_exit',
        text: 'Egress from the spacecraft airlock onto the lunar regolith',
        completed: false,
        xp: 100,
        hint: 'Lower the access lift and step onto the Moon.'
      },
      {
        id: 'obj_moon_samples',
        text: 'Collect 3 geological samples: Anorthosite Rock, Water-Ice Core, and Basalt',
        completed: false,
        xp: 300,
        hint: 'Follow the holographic science beacons with your scanner.'
      },
      {
        id: 'obj_moon_rover',
        text: 'Deploy and drive the Lunar Terrain Rover across the crater rim',
        completed: false,
        xp: 250,
        hint: 'Press the "Drive Rover" button or press "E" when near the rover.'
      },
      {
        id: 'obj_moon_outpost',
        text: 'Manage Outpost Life Support: Clean solar panels and balance electrical power',
        completed: false,
        xp: 350,
        hint: 'Visit the Outpost Control Console to clean panels and recycle water.'
      }
    ],
    funFacts: [
      'Moon dust (regolith) is made of tiny, sharp volcanic glass shards that stick to everything!',
      'Near the South Pole, some mountain peaks receive almost continuous sunlight for 200 days straight.',
      'Shackleton Crater is deeper than the Grand Canyon and permanently cloaked in pitch-black shadow.',
      'Water ice on the Moon can be split into liquid hydrogen and liquid oxygen for rocket propellant!'
    ],
    realNasaContext: 'Based on NASA’s Artemis III and Base Camp architecture, utilizing Starship HLS, the Gateway lunar orbital station, and VIPER rover exploration data.'
  },
  mars: {
    id: 'mars',
    title: 'ARES RED HORIZON EXPEDITION',
    subtitle: 'Jezero Crater Science Station One',
    planetName: 'Mars (The Red Planet)',
    gravity: 3.72,
    tempRange: '-140°C to +20°C',
    commDelay: '4 to 20 minutes',
    distance: '225,000,000 km from Earth',
    description: 'Pioneer the first human landing on the Red Planet! Touch down in ancient Jezero Crater, search for fossilized microbial biosignatures in dried delta clays, drive the pressurized rover, and extract life-giving oxygen from the thin CO₂ atmosphere with MOXIE.',
    objectives: [
      {
        id: 'obj_mars_land',
        text: 'Execute supersonic retro-propulsion touchdown in Jezero Crater',
        completed: false,
        xp: 200,
        hint: 'Touchdown at the designated Ares Base coordinates.'
      },
      {
        id: 'obj_mars_exit',
        text: 'Egress down the descent ladder onto Martian rust-red soil',
        completed: false,
        xp: 120,
        hint: 'Step down into the ancient Martian river delta.'
      },
      {
        id: 'obj_mars_samples',
        text: 'Collect 3 Martian specimens: Hematite Blueberries, Riverbed Clay, and Basaltic Crust',
        completed: false,
        xp: 350,
        hint: 'Investigate the geological rock markers on the red terrain.'
      },
      {
        id: 'obj_mars_rover',
        text: 'Drive the Heavy Exploration Rover across the Martian desert',
        completed: false,
        xp: 300,
        hint: 'Use the rover vehicle controls for fast cross-terrain navigation.'
      },
      {
        id: 'obj_mars_outpost',
        text: 'Activate MOXIE oxygen generation and wipe dust from solar panels',
        completed: false,
        xp: 400,
        hint: 'Protect the habitat against Martian dust storm accumulation.'
      }
    ],
    funFacts: [
      'Mars looks red because its surface is coated in iron oxide — the same chemical as rust on Earth!',
      'Olympus Mons on Mars is the largest volcano in the solar system, three times taller than Mount Everest!',
      'Sunset on Mars appears distinctly blue due to how fine atmospheric dust scatters sunlight.',
      'A Martian day is called a "sol" and lasts 24 hours, 39 minutes, and 35 seconds.'
    ],
    realNasaContext: 'Modeled after NASA Mars Exploration Program, Perseverance Rover Jezero Delta explorations, and the NASA Moon-to-Mars human architecture.'
  }
};
