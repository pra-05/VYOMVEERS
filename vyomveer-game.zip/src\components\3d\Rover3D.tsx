import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Astronaut3D } from './Astronaut3D';

interface Rover3DProps {
  scale?: number;
  isDriving?: boolean;
  speedRatio?: number;
  isPlayerInside?: boolean;
}

export const Rover3D: React.FC<Rover3DProps> = ({
  scale = 1,
  isDriving = false,
  speedRatio = 0,
  isPlayerInside = false
}) => {
  const wheelRefs = useRef<THREE.Mesh[]>([]);
  const mastRef = useRef<THREE.Group>(null);
  const dishRef = useRef<THREE.Group>(null);
  const armRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();

    // Rotate wheels when driving
    if (isDriving) {
      const rotSpeed = (speedRatio || 1) * 8;
      wheelRefs.current.forEach((wheel) => {
        if (wheel) {
          wheel.rotation.x += rotSpeed * 0.02;
        }
      });
    }

    // Gentle camera mast panning
    if (mastRef.current) {
      mastRef.current.rotation.y = Math.sin(t * 0.5) * 0.3;
    }

    // High gain dish tracking
    if (dishRef.current) {
      dishRef.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    }

    // Robotic arm idle / prospecting motion
    if (armRef.current && !isDriving) {
      armRef.current.rotation.z = Math.sin(t * 0.8) * 0.1;
    }
  });

  return (
    <group scale={[scale, scale, scale]}>
      {/* --- ROVER MAIN CHASSIS / HULL --- */}
      <mesh position={[0, 0.75, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.6, 0.5, 2.6]} />
        <meshStandardMaterial color="#E0E6ED" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Futuristic Blue Decal Trim */}
      <mesh position={[0, 0.76, 0]}>
        <boxGeometry args={[1.62, 0.12, 2.4]} />
        <meshStandardMaterial color="#168BFF" roughness={0.4} />
      </mesh>

      {/* --- COCKPIT & PILOT SEAT --- */}
      {/* Front Cockpit Seat */}
      <mesh position={[0, 1.05, 0.2]} castShadow>
        <boxGeometry args={[0.9, 0.5, 0.7]} />
        <meshStandardMaterial color="#0B1F3A" roughness={0.7} />
      </mesh>
      {/* Seat Backrest */}
      <mesh position={[0, 1.45, -0.1]}>
        <boxGeometry args={[0.85, 0.6, 0.15]} />
        <meshStandardMaterial color="#1A2D4A" roughness={0.7} />
      </mesh>

      {/* Control Console & Holographic Display */}
      <mesh position={[0, 1.25, 0.75]} rotation={[-0.4, 0, 0]}>
        <boxGeometry args={[0.7, 0.3, 0.12]} />
        <meshStandardMaterial color="#061329" metalness={0.5} roughness={0.2} />
      </mesh>
      {/* Glowing Screen */}
      <mesh position={[0, 1.27, 0.79]} rotation={[-0.4, 0, 0]}>
        <planeGeometry args={[0.6, 0.22]} />
        <meshBasicMaterial color="#00D9FF" />
      </mesh>

      {/* Steering Yoke Controls */}
      <mesh position={[0, 1.15, 0.65]} rotation={[0.4, 0, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 0.3, 8]} />
        <meshStandardMaterial color="#555555" metalness={0.8} />
      </mesh>
      <mesh position={[0, 1.28, 0.68]}>
        <torusGeometry args={[0.12, 0.02, 8, 16, Math.PI]} />
        <meshStandardMaterial color="#168BFF" />
      </mesh>

      {/* If player is driving the rover, render the seated astronaut! */}
      {isPlayerInside && (
        <group position={[0, 0.75, 0.2]}>
          <Astronaut3D scale={0.7} isDriving={true} />
        </group>
      )}

      {/* --- HIGH-GAIN PARABOLIC DISH (COMMUNICATIONS) --- */}
      <group ref={dishRef} position={[-0.55, 1.4, -0.9]}>
        {/* Support Rod */}
        <mesh position={[0, -0.2, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.45, 8]} />
          <meshStandardMaterial color="#445566" metalness={0.8} />
        </mesh>
        {/* Parabolic Dish */}
        <mesh rotation={[0.5, 0.2, 0]}>
          <cylinderGeometry args={[0.35, 0.05, 0.15, 16, 1, true]} />
          <meshStandardMaterial color="#FFFFFF" metalness={0.7} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
        {/* Feed Horn in Dish Center */}
        <mesh position={[0, 0.1, 0]}>
          <sphereGeometry args={[0.05, 12, 12]} />
          <meshBasicMaterial color="#FF9D42" />
        </mesh>
      </group>

      {/* --- SCIENCE CAMERA MAST (PANCAM / SPECTROMETER) --- */}
      <group ref={mastRef} position={[0.55, 1.3, 0.8]}>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.04, 0.04, 0.7, 12]} />
          <meshStandardMaterial color="#445566" metalness={0.8} />
        </mesh>
        {/* Camera Sensor Bar Head */}
        <mesh position={[0, 0.68, 0]}>
          <boxGeometry args={[0.3, 0.12, 0.16]} />
          <meshStandardMaterial color="#223344" metalness={0.6} />
        </mesh>
        {/* Stereo Optics Lenses */}
        <mesh position={[-0.09, 0.68, 0.09]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.03, 12]} />
          <meshBasicMaterial color="#00D9FF" />
        </mesh>
        <mesh position={[0.09, 0.68, 0.09]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.03, 12]} />
          <meshBasicMaterial color="#00D9FF" />
        </mesh>
      </group>

      {/* --- SOLAR ARRAY CANOPY ROOF --- */}
      <mesh position={[0, 1.45, -0.6]} receiveShadow>
        <boxGeometry args={[1.4, 0.04, 1.0]} />
        <meshStandardMaterial color="#061329" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Blue Solar Cells Grid on Roof */}
      <mesh position={[0, 1.48, -0.6]}>
        <planeGeometry args={[1.35, 0.95]} />
        <meshStandardMaterial color="#0055AA" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* --- FRONT SCIENTIFIC SAMPLING ARM & DRILL --- */}
      <group ref={armRef} position={[-0.65, 0.7, 1.3]}>
        <mesh position={[0, -0.15, 0.25]} rotation={[0.4, 0, 0]}>
          <cylinderGeometry args={[0.04, 0.04, 0.6, 8]} />
          <meshStandardMaterial color="#888888" metalness={0.8} />
        </mesh>
        {/* Diamond Core Drill Bit */}
        <mesh position={[0, -0.38, 0.5]} rotation={[Math.PI / 2, 0, 0]}>
          <coneGeometry args={[0.07, 0.22, 12]} />
          <meshStandardMaterial color="#333333" metalness={0.9} roughness={0.1} />
        </mesh>
      </group>

      {/* --- REAR CARGO BED FOR COLLECTED ROCK SAMPLES --- */}
      <mesh position={[0, 0.8, -1.05]}>
        <boxGeometry args={[1.3, 0.25, 0.7]} />
        <meshStandardMaterial color="#3A4A5A" metalness={0.5} />
      </mesh>
      {/* Sample Container Tubes in Cargo Bed */}
      {[-0.35, 0, 0.35].map((xOffset, idx) => (
        <mesh key={idx} position={[xOffset, 0.92, -1.05]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.09, 0.09, 0.35, 12]} />
          <meshStandardMaterial color="#00D9FF" metalness={0.7} roughness={0.2} />
        </mesh>
      ))}

      {/* --- BRIGHT DUAL HEADLIGHTS --- */}
      <mesh position={[-0.6, 0.75, 1.32]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.08, 16]} />
        <meshBasicMaterial color="#F3F8FF" />
      </mesh>
      <mesh position={[0.6, 0.75, 1.32]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.08, 16]} />
        <meshBasicMaterial color="#F3F8FF" />
      </mesh>
      {/* Headlight illumination onto terrain */}
      <pointLight 
        position={[0, 0.8, 2.2]} 
        intensity={6} 
        distance={25} 
        color="#F3F8FF" 
      />

      {/* --- 6 ALL-TERRAIN MOBILITY WHEELS (ROCKER-BOGIE SYSTEM) --- */}
      {[
        // [x, y, z, index]
        [-0.95, 0.38, 0.9, 0],
        [0.95, 0.38, 0.9, 1],
        [-1.02, 0.38, 0.0, 2],
        [1.02, 0.38, 0.0, 3],
        [-0.95, 0.38, -0.9, 4],
        [0.95, 0.38, -0.9, 5]
      ].map(([x, y, z, idx]) => (
        <group key={idx} position={[x, y, z]}>
          {/* Suspension Arm Link */}
          <mesh position={[-Math.sign(x) * 0.12, 0.15, 0]}>
            <boxGeometry args={[0.15, 0.08, 0.35]} />
            <meshStandardMaterial color="#556677" metalness={0.8} />
          </mesh>
          {/* Rotating Wheel Hub & Tire */}
          <mesh 
            ref={(el) => { if (el) wheelRefs.current[idx as number] = el; }} 
            rotation={[0, 0, Math.PI / 2]}
            castShadow
          >
            <cylinderGeometry args={[0.38, 0.38, 0.28, 20]} />
            <meshStandardMaterial color="#1E232B" roughness={0.85} metalness={0.2} />
          </mesh>
          {/* Wheel Metallic Rim */}
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.22, 0.22, 0.29, 16]} />
            <meshStandardMaterial color="#00D9FF" metalness={0.9} roughness={0.2} />
          </mesh>
        </group>
      ))}
    </group>
  );
};
