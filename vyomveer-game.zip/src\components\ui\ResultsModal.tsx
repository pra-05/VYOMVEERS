import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Trophy, 
  Star, 
  CheckCircle2, 
  RotateCcw, 
  Home, 
  Award, 
  Sparkles,
  Compass
} from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { MISSIONS_DATA } from '../../data/missionsData';

export const ResultsModal: React.FC = () => {
  const selectedMission = useGameStore((state) => state.selectedMission);
  const objectives = useGameStore((state) => state.objectives);
  const score = useGameStore((state) => state.score);
  const samples = useGameStore((state) => state.samples);
  const achievements = useGameStore((state) => state.achievements);
  const resetGame = useGameStore((state) => state.resetGame);
  const setScreen = useGameStore((state) => state.setScreen);
  const selectMission = useGameStore((state) => state.selectMission);

  const mission = MISSIONS_DATA[selectedMission];
  const completedCount = objectives.filter((o) => o.completed).length;
  const samplesCollected = samples.filter((s) => s.collected).length;
  const unlockedBadges = achievements.filter((a) => a.unlocked);

  // Calculate 1 to 3 stars
  const starsEarned = completedCount >= 4 ? 3 : completedCount >= 2 ? 2 : 1;

  useEffect(() => {
    // Launch celebratory confetti bursts
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
      setTimeout(() => {
        confetti({
          particleCount: 50,
          angle: 60,
          spread: 55,
          origin: { x: 0 }
        });
        confetti({
          particleCount: 50,
          angle: 120,
          spread: 55,
          origin: { x: 1 }
        });
      }, 400);
    } catch {}
  }, []);

  return (
    <div className="absolute inset-0 bg-[#061329]/95 backdrop-blur-lg z-50 flex items-center justify-center p-6 overflow-y-auto">
      <div className="bg-[#0B1F3A] border-2 border-[#00D9FF] rounded-3xl max-w-3xl w-full p-8 text-white shadow-2xl relative my-auto">
        {/* Top Trophy Banner */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF9D42] to-[#FFD700] flex items-center justify-center shadow-lg shadow-amber-500/30 mb-3 animate-bounce">
            <Trophy className="w-10 h-10 text-slate-950" />
          </div>
          <span className="text-xs font-mono text-[#00D9FF] tracking-widest uppercase">NASA MISSION DEBRIEF</span>
          <h2 className="text-2xl md:text-3xl font-extrabold font-orbitron text-white">
            Expedition Successful!
          </h2>
          <p className="text-xs text-slate-300 max-w-md mt-1">
            Congratulations Junior Astronaut! You successfully navigated, explored, and gathered real science on {mission.planetName}.
          </p>

          {/* 3 Stars Rating */}
          <div className="flex items-center space-x-2 my-4">
            {[1, 2, 3].map((starIdx) => (
              <Star
                key={starIdx}
                className={`w-9 h-9 transition-all duration-300 ${
                  starIdx <= starsEarned
                    ? 'text-[#FFD700] fill-[#FFD700] drop-shadow-[0_0_12px_rgba(255,215,0,0.8)]'
                    : 'text-slate-700'
                }`}
              />
            ))}
          </div>

          <div className="text-sm font-mono text-[#39FF14] font-bold">
            MISSION SCORE: {score} XP
          </div>
        </div>

        {/* Breakdown Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Objectives Summary */}
          <div className="p-4 bg-[#061329] rounded-2xl border border-slate-800">
            <h3 className="text-xs font-bold font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>MISSION OBJECTIVES:</span>
              <span className="text-[#00D9FF]">{completedCount} / {objectives.length}</span>
            </h3>
            <div className="space-y-1.5">
              {objectives.map((obj) => (
                <div key={obj.id} className="flex items-center space-x-2 text-xs">
                  <CheckCircle2 className={`w-4 h-4 flex-shrink-0 ${obj.completed ? 'text-[#39FF14]' : 'text-slate-600'}`} />
                  <span className={obj.completed ? 'text-slate-200' : 'text-slate-500'}>{obj.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Geological Samples & Badges */}
          <div className="p-4 bg-[#061329] rounded-2xl border border-slate-800 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold font-mono text-slate-400 mb-2 flex items-center justify-between">
                <span>SAMPLES RETRIEVED:</span>
                <span className="text-[#FF9D42]">{samplesCollected} / {samples.length}</span>
              </h3>
              <div className="space-y-1 mb-4">
                {samples.map((s) => (
                  <div key={s.id} className="text-xs flex justify-between">
                    <span className={s.collected ? 'text-slate-200' : 'text-slate-600'}>• {s.name}</span>
                    <span className="text-slate-400 font-mono text-[10px]">{s.collected ? 'SECURED' : 'MISSED'}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Badges preview */}
            <div>
              <div className="text-[10px] font-mono text-slate-400 mb-1">ACHIEVEMENTS EARNED:</div>
              <div className="flex flex-wrap gap-1.5">
                {unlockedBadges.map((b) => (
                  <span key={b.id} className="px-2 py-0.5 rounded-md bg-[#168BFF]/20 text-[#00D9FF] border border-[#00D9FF]/40 text-[10px] font-mono">
                    {b.title}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => {
              const otherDest = selectedMission === 'moon' ? 'mars' : 'moon';
              selectMission(otherDest);
              setScreen('mission_select');
            }}
            className="flex-1 py-3.5 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:from-[#1a94ff] hover:to-[#22e3ff] text-slate-950 font-bold rounded-xl font-orbitron text-xs flex items-center justify-center space-x-2 shadow-lg"
          >
            <Compass className="w-4 h-4" />
            <span>PLAY {selectedMission === 'moon' ? 'MARS EXPEDITION' : 'MOON EXPEDITION'} →</span>
          </button>

          <button
            onClick={() => setScreen('station')}
            className="py-3.5 px-6 bg-[#061329] hover:bg-slate-800 border border-[#00D9FF]/40 text-white font-semibold rounded-xl text-xs flex items-center justify-center space-x-2"
          >
            <Home className="w-4 h-4 text-[#00D9FF]" />
            <span>Gateway Station</span>
          </button>
        </div>
      </div>
    </div>
  );
};
