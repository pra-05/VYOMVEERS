import React, { useState } from 'react';
import { ArrowLeft, CheckSquare, Square, Rocket, ShieldCheck, UserCheck, PackageCheck, AlertCircle } from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { MISSIONS_DATA } from '../../data/missionsData';

export const LaunchPrepModal: React.FC = () => {
  const setScreen = useGameStore((state) => state.setScreen);
  const startLaunchSequence = useGameStore((state) => state.startLaunchSequence);
  const selectedMission = useGameStore((state) => state.selectedMission);
  const astronaut = useGameStore((state) => state.astronaut);
  const equipment = useGameStore((state) => state.equipment);

  const mission = MISSIONS_DATA[selectedMission];

  const [checklist, setChecklist] = useState({
    lifeSupport: false,
    solarArrays: false,
    roverLocked: false,
    trajectory: false,
    radiationReview: false
  });

  const allChecked = Object.values(checklist).every(Boolean);

  const toggleCheck = (key: keyof typeof checklist) => {
    setChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="absolute inset-0 bg-[#061329] flex flex-col z-20 overflow-hidden">
      {/* --- TOP BAR --- */}
      <div className="p-5 border-b border-[#00D9FF]/30 bg-[#0B1F3A]/90 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setScreen('mission_select')}
            className="flex items-center space-x-2 bg-[#061329] hover:bg-[#168BFF]/40 border border-[#00D9FF]/40 rounded-xl px-3.5 py-2 text-xs text-white transition"
          >
            <ArrowLeft className="w-4 h-4 text-[#00D9FF]" />
            <span>Mission Select</span>
          </button>
          <div>
            <h2 className="text-xl font-bold font-orbitron text-white">Pre-Flight Launch Verification</h2>
            <p className="text-xs text-slate-300">Complete pre-launch protocols before authorizing engine ignition.</p>
          </div>
        </div>
      </div>

      {/* --- CONTENT CONTAINER --- */}
      <div className="flex-1 p-6 overflow-y-auto max-w-4xl mx-auto w-full flex flex-col justify-between">
        <div className="space-y-6">
          {/* Mission Manifest Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-[#0B1F3A] rounded-2xl border border-slate-800">
              <div className="flex items-center space-x-2.5 text-xs text-[#00D9FF] font-mono mb-2">
                <UserCheck className="w-4 h-4" />
                <span>COMMANDER</span>
              </div>
              <h4 className="text-base font-bold text-white">{astronaut.name}</h4>
              <p className="text-xs text-slate-400">Badge: {astronaut.badge.toUpperCase()}</p>
            </div>

            <div className="p-4 bg-[#0B1F3A] rounded-2xl border border-slate-800">
              <div className="flex items-center space-x-2.5 text-xs text-[#FF9D42] font-mono mb-2">
                <Rocket className="w-4 h-4" />
                <span>DESTINATION</span>
              </div>
              <h4 className="text-base font-bold text-white">{mission.planetName}</h4>
              <p className="text-xs text-slate-400">Target: {mission.subtitle}</p>
            </div>

            <div className="p-4 bg-[#0B1F3A] rounded-2xl border border-slate-800">
              <div className="flex items-center space-x-2.5 text-xs text-[#39FF14] font-mono mb-2">
                <PackageCheck className="w-4 h-4" />
                <span>LIFE SUPPORT PAYLOAD</span>
              </div>
              <h4 className="text-base font-bold text-white">
                {equipment.oxygenTanks} Tanks O₂ • {equipment.solarPanels} Solar Wings
              </h4>
              <p className="text-xs text-slate-400">All systems certified flight-ready</p>
            </div>
          </div>

          {/* Interactive Launch Checklist */}
          <div className="bg-[#0B1F3A]/80 border border-[#00D9FF]/30 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold font-orbitron text-white">NASA Pre-Launch Checklist</h3>
                <p className="text-xs text-[#00D9FF] font-mono">ALL ITEMS MUST BE MANUALLY VERIFIED</p>
              </div>
              <div className="text-xs font-mono text-slate-400">
                {Object.values(checklist).filter(Boolean).length} / 5 COMPLETE
              </div>
            </div>

            <div className="space-y-3">
              <div
                onClick={() => toggleCheck('lifeSupport')}
                className="flex items-center space-x-3.5 p-3 rounded-xl bg-[#061329] hover:bg-slate-800/80 cursor-pointer border border-slate-800 transition"
              >
                {checklist.lifeSupport ? (
                  <CheckSquare className="w-5 h-5 text-[#39FF14]" />
                ) : (
                  <Square className="w-5 h-5 text-slate-500" />
                )}
                <div>
                  <div className="text-sm font-semibold text-white">Life Support Systems Sealed & Pressurized</div>
                  <div className="text-xs text-slate-400">Oxygen tanks verified at 3000 psi; cabin atmospheric scrubber active.</div>
                </div>
              </div>

              <div
                onClick={() => toggleCheck('solarArrays')}
                className="flex items-center space-x-3.5 p-3 rounded-xl bg-[#061329] hover:bg-slate-800/80 cursor-pointer border border-slate-800 transition"
              >
                {checklist.solarArrays ? (
                  <CheckSquare className="w-5 h-5 text-[#39FF14]" />
                ) : (
                  <Square className="w-5 h-5 text-slate-500" />
                )}
                <div>
                  <div className="text-sm font-semibold text-white">Solar Array Wings Stowed & Latched</div>
                  <div className="text-xs text-slate-400">Photovoltaic cells folded for high-aerodynamic ascent stress.</div>
                </div>
              </div>

              <div
                onClick={() => toggleCheck('roverLocked')}
                className="flex items-center space-x-3.5 p-3 rounded-xl bg-[#061329] hover:bg-slate-800/80 cursor-pointer border border-slate-800 transition"
              >
                {checklist.roverLocked ? (
                  <CheckSquare className="w-5 h-5 text-[#39FF14]" />
                ) : (
                  <Square className="w-5 h-5 text-slate-500" />
                )}
                <div>
                  <div className="text-sm font-semibold text-white">Exploration Rover Lashed in Lower Hold</div>
                  <div className="text-xs text-slate-400">Suspension locked and batteries charged at 100%.</div>
                </div>
              </div>

              <div
                onClick={() => toggleCheck('trajectory')}
                className="flex items-center space-x-3.5 p-3 rounded-xl bg-[#061329] hover:bg-slate-800/80 cursor-pointer border border-slate-800 transition"
              >
                {checklist.trajectory ? (
                  <CheckSquare className="w-5 h-5 text-[#39FF14]" />
                ) : (
                  <Square className="w-5 h-5 text-slate-500" />
                )}
                <div>
                  <div className="text-sm font-semibold text-white">Trans-Planetary Trajectory Uploaded</div>
                  <div className="text-xs text-slate-400">Hohmann transfer guidance vectors synchronized with NASA Deep Space Network.</div>
                </div>
              </div>

              <div
                onClick={() => toggleCheck('radiationReview')}
                className="flex items-center space-x-3.5 p-3 rounded-xl bg-[#061329] hover:bg-slate-800/80 cursor-pointer border border-slate-800 transition"
              >
                {checklist.radiationReview ? (
                  <CheckSquare className="w-5 h-5 text-[#39FF14]" />
                ) : (
                  <Square className="w-5 h-5 text-slate-500" />
                )}
                <div>
                  <div className="text-sm font-semibold text-white">Space Weather & Solar Radiation Briefing Acknowledged</div>
                  <div className="text-xs text-slate-400">Crew trained on solar storm shelter protocol and electromagnetic shield operation.</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ignition Action Button */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400 font-mono">
            {allChecked ? (
              <span className="text-[#39FF14] flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>FLIGHT DIRECTOR APPROVAL: GO FOR LAUNCH!</span>
              </span>
            ) : (
              <span className="text-[#FF9D42] flex items-center space-x-1.5">
                <AlertCircle className="w-4 h-4" />
                <span>Check all 5 verification boxes above to enable ignition.</span>
              </span>
            )}
          </div>

          <button
            onClick={startLaunchSequence}
            disabled={!allChecked}
            className={`py-4 px-10 rounded-xl font-orbitron font-extrabold text-sm tracking-wider flex items-center space-x-3 shadow-xl transition-all duration-300 ${
              allChecked
                ? 'bg-gradient-to-r from-[#FF9D42] via-[#FF3B30] to-[#168BFF] text-white hover:scale-105 shadow-red-500/30 animate-pulse'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            <Rocket className="w-5 h-5" />
            <span>IGNITION: LAUNCH TO {mission.planetName.toUpperCase()}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
