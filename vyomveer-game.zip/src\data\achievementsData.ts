import { Achievement } from '../types/game';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_first_steps',
    title: 'One Giant Leap',
    description: 'Egress from the rocket and touch the alien planetary regolith for the first time.',
    icon: 'Footprints',
    category: 'exploration',
    unlocked: false
  },
  {
    id: 'ach_rover_ace',
    title: 'Off-World Driver',
    description: 'Drive the Planetary Exploration Rover across the rugged terrain.',
    icon: 'Car',
    category: 'engineering',
    unlocked: false
  },
  {
    id: 'ach_geologist',
    title: 'Planetary Geologist',
    description: 'Successfully discover and collect all 3 geological scientific samples.',
    icon: 'Gem',
    category: 'science',
    unlocked: false
  },
  {
    id: 'ach_clean_energy',
    title: 'Dust Buster',
    description: 'Clean the Outpost solar panels to restore 100% solar array generation efficiency.',
    icon: 'Sparkles',
    category: 'engineering',
    unlocked: false
  },
  {
    id: 'ach_storm_survivor',
    title: 'Cosmic Shield',
    description: 'Survive a space weather alert (Solar Flare / CME) by engaging protective protocols.',
    icon: 'Shield',
    category: 'survival',
    unlocked: false
  },
  {
    id: 'ach_green_thumb',
    title: 'Botanist of Mars & Luna',
    description: 'Activate hydroponic greenhouse modules to produce fresh food and oxygen off-world.',
    icon: 'Sprout',
    category: 'science',
    unlocked: false
  },
  {
    id: 'ach_nasa_scholar',
    title: 'NASA Space Apps Champion',
    description: 'Complete the expedition with all resources above 50% and achieve a high score!',
    icon: 'Trophy',
    category: 'survival',
    unlocked: false
  }
];
