export type GameScreen = 
  | 'station'
  | 'customization'
  | 'equipment'
  | 'mission_select'
  | 'launch_prep'
  | 'launch_anim'
  | 'landing_anim'
  | 'exit_rocket_anim'
  | 'surface_exploration'
  | 'outpost_mgmt'
  | 'results';

export type Destination = 'moon' | 'mars';

export type VehicleMode = 'astronaut' | 'rover';

export interface AstronautConfig {
  name: string;
  gender: 'cadet_alex' | 'cadet_maya' | 'cadet_leo' | 'cadet_sam';
  skinTone: string;
  hairStyle: 'short' | 'curly' | 'ponytail' | 'spiky' | 'dreadlocks';
  hairColor: string;
  suitColor: string;
  accentColor: string;
  helmetColor: string;
  visorColor: string;
  glovesColor: string;
  bootsColor: string;
  backpackColor: string;
  badge: 'nasa_worm' | 'artemis' | 'vyom_star' | 'mars_pathfinder';
}

export interface EquipmentConfig {
  oxygenTanks: number;      // 1 tank = 25 oxygen capacity
  waterPurifiers: number;   // 1 unit = 25 water capacity
  foodRations: number;      // 1 pack = 25 food capacity
  firstAidKits: number;     // for emergencies
  researchTools: number;    // increases science yield
  commRelays: number;       // reduces comm delay/glitches
  solarPanels: number;      // adds 20 power gen
  emergencyBatteries: number; // backup power reserve
  roverDrillModules: number; // enables deeper drilling
}

export interface MissionObjective {
  id: string;
  text: string;
  completed: boolean;
  xp: number;
  hint: string;
}

export interface MissionData {
  id: Destination;
  title: string;
  subtitle: string;
  planetName: string;
  gravity: number; // m/s^2 (Moon: 1.62, Mars: 3.72)
  tempRange: string;
  commDelay: string;
  distance: string;
  description: string;
  objectives: MissionObjective[];
  funFacts: string[];
  realNasaContext: string;
}

export interface ResourceState {
  oxygen: number;           // 0 to 100
  water: number;            // 0 to 100
  food: number;             // 0 to 100
  power: number;            // 0 to 100
  radiationProtection: number; // 0 to 100
  roverBattery: number;     // 0 to 100
  habitatIntegrity: number; // 0 to 100
}

export interface SampleItem {
  id: string;
  name: string;
  type: 'mineral' | 'water_ice' | 'regolith' | 'basalt' | 'martian_hematite' | 'lunar_anorthosite';
  position: [number, number, number];
  collected: boolean;
  description: string;
  scienceFact: string;
  weightKg: number;
}

export interface ScienceOutpost {
  solarArraysClean: boolean; // if false, power gen drops 50%
  greenhouseActive: boolean; // if true, generates food & oxygen slowly
  electrolysisActive: boolean; // generates oxygen from water
  shieldingActive: boolean; // uses power to keep radiation low
  lastMaintenance: number;
}

export interface SpaceWeatherAlert {
  id: string;
  title: string;
  type: 'solar_flare' | 'cme' | 'dust_storm' | 'geomagnetic_storm';
  severity: 'moderate' | 'high' | 'extreme';
  radiationSurgeRate: number; // % drain per sec if unshielded
  durationSeconds: number;
  nasaReference: string;
  educationalTip: string;
}

export interface MissionEventChoice {
  id: string;
  text: string;
  description: string;
  resourceDelta: Partial<ResourceState>;
  scienceExplanation: string;
  achievementTrigger?: string;
}

export interface MissionEvent {
  id: string;
  title: string;
  category: 'malfunction' | 'weather' | 'discovery' | 'system';
  description: string;
  consequenceWarning: string;
  choices: MissionEventChoice[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'exploration' | 'survival' | 'science' | 'engineering';
  unlocked: boolean;
  unlockedAt?: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  text: string;
  type: 'info' | 'science' | 'alert' | 'success';
}
