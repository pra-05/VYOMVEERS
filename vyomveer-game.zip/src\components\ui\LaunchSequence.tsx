import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Stars } from '@react-three/drei';
import * as THREE from 'three';
import { Rocket3D } from '../3d/Rocket3D';
import { HoloPlanet } from '../3d/PlanetsHolo';
import { useGameStore } from '../../store/useGameStore';
import { MISSIONS_DATA } from '../../data/missionsData';

const LaunchAscentScene: React.FC<{ progress: number }> = ({ progress }) => {
  const rocketRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (rocketRef.current) {
      // Ascend from y=0 to y=35
      rocketRef.current.position.y = progress * 35;
      // Slight atmospheric vibration
      if (progress < 0.8) {
        rocketRef.current.position.x = Math.sin(t * 30) * 0.05 * (1 - progress);
      }
    }
  });

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 20, 10]} intensity={1.8} castShadow />

      {/* Earth surface below when low altitude */}
      {progress < 0.6 && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]}>
          <planeGeometry args={[100, 100]} />
          <meshStandardMaterial color="#1E293B" />
        </mesh>
      )}

      {/* Launch Pad Tower */}
      {progress < 0.5 && (
        <group position={[-2.8, 4, 0]}>
          <mesh>
            <cylinderGeometry args={[0.3, 0.4, 8, 8]} />
            <meshStandardMaterial color="#94A3B8" metalness={0.9} />
          </mesh>
        </group>
      )}

      {/* Deep Space & Earth visible when high altitude */}
      {progress >= 0.4 && (
        <>
          <Stars radius={120} depth={50} count={5000} factor={4} fade />
          <group position={[0, -25, -45]}>
            <HoloPlanet planet="earth" radius={16} showAtmosphere={true} />
          </group>
        </>
      )}

      {/* Rising Spacecraft */}
      <group ref={rocketRef} position={[0, 0, 0]}>
        <Rocket3D scale={1.2} thrusterFiring={true} legsExtended={false} />
      </group>
    </>
  );
};

export const LaunchSequence: React.FC = () => {
  const finishLaunchToLanding = useGameStore((state) => state.finishLaunchToLanding);
  const selectedMission = useGameStore((state) => state.selectedMission);
  const mission = MISSIONS_DATA[selectedMission];

  const [countdown, setCountdown] = useState(3);
  const [isLiftoff, setIsLiftoff] = useState(false);
  const [ascentProgress, setAscentProgress] = useState(0); // 0 to 1
  const [altitudeKm, setAltitudeKm] = useState(0);
  const [velocityKmh, setVelocityKmh] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev > 1) return prev - 1;
        setIsLiftoff(true);
        clearInterval(timer);
        return 0;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!isLiftoff) return;

    const start = Date.now();
    const duration = 6500; // 6.5s ascent sequence

    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const p = Math.min(1, elapsed / duration);
      setAscentProgress(p);

      setAltitudeKm(Math.round(p * 220));
      setVelocityKmh(Math.round(p * 28000));

      if (p >= 1) {
        clearInterval(interval);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isLiftoff]);

  return (
    <div className="absolute inset-0 bg-[#061329] z-30 flex flex-col justify-between overflow-hidden">
      {/* 3D Canvas */}
      <div className="absolute inset-0">
        <Canvas camera={{ position: [0, 4, 12], fov: 45 }}>
          <LaunchAscentScene progress={ascentProgress} />
        </Canvas>
      </div>

      {/* --- TOP TELEMETRY BAR --- */}
      <div className="relative z-10 p-6 flex justify-between items-start pointer-events-none">
        <div className="bg-[#0B1F3A]/85 backdrop-blur-md border border-[#00D9FF]/40 rounded-xl p-3 shadow-lg">
          <div className="text-[10px] text-slate-400 font-mono">MISSION TARGET</div>
          <div className="text-base font-bold text-white font-orbitron">{mission.title}</div>
          <div className="text-xs text-[#00D9FF] font-mono">EN ROUTE TO {mission.planetName.toUpperCase()}</div>
        </div>

        {/* Live Flight Telemetry */}
        <div className="bg-[#0B1F3A]/85 backdrop-blur-md border border-[#00D9FF]/40 rounded-xl p-3 shadow-lg font-mono text-right">
          <div className="text-xs text-slate-400">ALTITUDE: <strong className="text-white text-sm">{altitudeKm} km</strong></div>
          <div className="text-xs text-slate-400">VELOCITY: <strong className="text-[#39FF14] text-sm">{velocityKmh.toLocaleString()} km/h</strong></div>
          <div className="text-[10px] text-[#00D9FF] mt-0.5">
            {ascentProgress < 0.3 ? 'MAX-Q ATMOSPHERIC AERODYNAMIC PRESSURE' : ascentProgress < 0.7 ? 'STAGE 1 BOOST PHASE' : 'TRANS-INJECTION ORBITAL INSERTION'}
          </div>
        </div>
      </div>

      {/* --- CENTER COUNTDOWN OVERLAY --- */}
      {!isLiftoff && (
        <div className="relative z-10 flex flex-col items-center justify-center my-auto pointer-events-none">
          <div className="text-8xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-b from-white to-[#00D9FF] drop-shadow-[0_0_35px_rgba(0,217,255,0.8)] animate-pulse">
            T-{countdown}
          </div>
          <div className="text-sm font-mono text-[#00D9FF] tracking-widest mt-2 uppercase">
            Main Engine Pre-Chill & Ignition Sequence
          </div>
        </div>
      )}

      {/* --- BOTTOM PROGRESS & TRANSITION BUTTON --- */}
      <div className="relative z-10 p-6 flex flex-col sm:flex-row items-center justify-between gap-4 bg-gradient-to-t from-[#061329] via-[#061329]/80 to-transparent">
        <div className="w-full sm:max-w-md">
          <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
            <span>TRANSIT TRAJECTORY PROGRESS</span>
            <span>{Math.round(ascentProgress * 100)}%</span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div 
              className="h-full bg-gradient-to-r from-[#168BFF] to-[#00D9FF] transition-all duration-100"
              style={{ width: `${ascentProgress * 100}%` }}
            />
          </div>
        </div>

        {ascentProgress >= 0.7 && (
          <button
            onClick={finishLaunchToLanding}
            className="py-3.5 px-8 bg-gradient-to-r from-[#FF9D42] to-[#FF3B30] hover:scale-105 text-white font-bold rounded-xl transition duration-200 font-orbitron text-xs tracking-wider shadow-xl shadow-orange-500/30 animate-pulse pointer-events-auto"
          >
            ENTER {mission.planetName.toUpperCase()} ORBIT & INITIATE LANDING →
          </button>
        )}
      </div>
    </div>
  );
};
