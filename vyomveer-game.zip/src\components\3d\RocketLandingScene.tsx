import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Stars } from '@react-three/drei';
import * as THREE from 'three';
import { Rocket3D } from './Rocket3D';
import { Outpost3D } from './Outpost3D';
import { HoloPlanet } from './PlanetsHolo';
import { useGameStore } from '../../store/useGameStore';

export const RocketLandingScene: React.FC = () => {
  const selectedMission = useGameStore((state) => state.selectedMission);
  const finishLandingToExit = useGameStore((state) => state.finishLandingToExit);

  // Landing sequence animation parameters
  const [altitude, setAltitude] = useState(250); // meters
  const [velocity, setVelocity] = useState(45); // m/s
  const [touchdownDone, setTouchdownDone] = useState(false);

  const rocketGroupRef = useRef<THREE.Group>(null);
  const startTimeRef = useRef<number>(Date.now());

  const isMoon = selectedMission === 'moon';
  const terrainColor = isMoon ? '#475569' : '#993D22';
  const skyColor = isMoon ? '#061329' : '#451A14';

  useEffect(() => {
    startTimeRef.current = Date.now();
  }, []);

  useFrame(() => {
    const elapsed = (Date.now() - startTimeRef.current) / 1000;
    const duration = 7.0; // 7 seconds landing sequence
    const progress = Math.min(1, elapsed / duration);

    // Rocket descends from y = 35 down to y = 0
    if (rocketGroupRef.current) {
      if (progress < 1) {
        // Ease out quadratic descent curve
        const ease = 1 - Math.pow(1 - progress, 2);
        const currentY = 32 * (1 - ease);
        rocketGroupRef.current.position.y = currentY;

        // Subtle attitude stabilization tilt
        rocketGroupRef.current.rotation.z = Math.sin(elapsed * 4) * (1 - progress) * 0.08;
        rocketGroupRef.current.rotation.x = Math.cos(elapsed * 3.5) * (1 - progress) * 0.08;

        const simulatedAlt = Math.max(0, Math.round((1 - ease) * 250));
        const simulatedVel = Math.max(0, Math.round((1 - progress) * 45));
        setAltitude(simulatedAlt);
        setVelocity(simulatedVel);
      } else {
        rocketGroupRef.current.position.y = 0;
        rocketGroupRef.current.rotation.z = 0;
        rocketGroupRef.current.rotation.x = 0;
        setAltitude(0);
        setVelocity(0);

        if (!touchdownDone) {
          setTouchdownDone(true);
        }
      }
    }
  });

  return (
    <>
      <ambientLight intensity={isMoon ? 0.35 : 0.6} />
      <directionalLight position={[15, 20, 10]} intensity={isMoon ? 1.8 : 1.4} castShadow />
      <color attach="background" args={[skyColor]} />
      {isMoon && <Stars radius={120} depth={50} count={5000} factor={4} fade />}

      {/* Earth visible in Moon sky or Phobos in Mars sky */}
      {isMoon ? (
        <group position={[-25, 20, -50]}>
          <HoloPlanet planet="earth" radius={6} showAtmosphere={true} />
        </group>
      ) : (
        <group position={[-20, 22, -40]}>
          <HoloPlanet planet="sun" radius={3} showAtmosphere={true} />
        </group>
      )}

      {/* --- DESCENT ROCKET --- */}
      <group ref={rocketGroupRef} position={[0, 32, 0]}>
        <Rocket3D 
          scale={1.2} 
          thrusterFiring={!touchdownDone} 
          legsExtended={true} 
          hatchOpen={false} 
        />
      </group>

      {/* --- LANDING SITE TERRAIN --- */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[120, 120, 48, 48]} />
        <meshStandardMaterial 
          color={terrainColor} 
          roughness={0.9} 
          metalness={0.1} 
        />
      </mesh>

      {/* Craters & Dunes around Landing Zone */}
      {[-18, 16, -24, 22].map((xPos, idx) => (
        <group key={idx} position={[xPos, 0, idx % 2 === 0 ? -16 : 14]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[2.5, 5.0, 24]} />
            <meshStandardMaterial color={isMoon ? '#334155' : '#7C2D12'} />
          </mesh>
        </group>
      ))}

      {/* --- LANDING PAD TARGET --- */}
      <group position={[0, 0.02, 0]}>
        {/* Hexagonal Concrete Landing Pad */}
        <mesh receiveShadow>
          <cylinderGeometry args={[5.5, 5.8, 0.15, 6]} />
          <meshStandardMaterial color="#1E293B" metalness={0.6} roughness={0.5} />
        </mesh>
        {/* Yellow Target Crosshairs */}
        <mesh position={[0, 0.09, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[3.2, 3.5, 32]} />
          <meshBasicMaterial color="#FF9D42" />
        </mesh>
        <mesh position={[0, 0.09, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.5, 1.7, 32]} />
          <meshBasicMaterial color="#00D9FF" />
        </mesh>
        {/* Pad Floodlights */}
        {[0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2].map((ang, i) => (
          <group key={i} position={[Math.cos(ang) * 5.0, 0.1, Math.sin(ang) * 5.0]}>
            <mesh>
              <cylinderGeometry args={[0.2, 0.25, 0.4, 8]} />
              <meshStandardMaterial color="#475569" />
            </mesh>
            <pointLight color="#00D9FF" intensity={3} distance={10} />
          </group>
        ))}
      </group>

      {/* Outpost visible in background */}
      <group position={[20, 0, -12]}>
        <Outpost3D scale={0.7} destination={selectedMission} />
      </group>
    </>
  );
};
