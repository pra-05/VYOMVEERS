import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { ArrowLeft, Rocket, Check, Compass, Radio, Target, Sparkles } from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { MISSIONS_DATA } from '../../data/missionsData';
import { HoloPlanet } from '../3d/PlanetsHolo';
import { Destination } from '../../types/game';

export const MissionSelector: React.FC = () => {
  const selectedMission = useGameStore((state) => state.selectedMission);
  const selectMission = useGameStore((state) => state.selectMission);
  const setScreen = useGameStore((state) => state.setScreen);

  const mission = MISSIONS_DATA[selectedMission];

  return (
    <div className="absolute inset-0 bg-[#061329] flex flex-col z-20 overflow-hidden">
      {/* --- TOP BAR --- */}
      <div className="p-5 border-b border-[#00D9FF]/30 bg-[#0B1F3A]/90 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setScreen('equipment')}
            className="flex items-center space-x-2 bg-[#061329] hover:bg-[#168BFF]/40 border border-[#00D9FF]/40 rounded-xl px-3.5 py-2 text-xs text-white transition"
          >
            <ArrowLeft className="w-4 h-4 text-[#00D9FF]" />
            <span>Equipment Bay</span>
          </button>
          <div>
            <h2 className="text-xl font-bold font-orbitron text-white">Planetary Destination Selection</h2>
            <p className="text-xs text-slate-300">Choose your destination for the NASA Space Apps 2026 expedition.</p>
          </div>
        </div>

        <div className="text-xs font-mono text-[#00D9FF] bg-[#061329] px-3.5 py-1.5 rounded-lg border border-[#00D9FF]/30 hidden sm:block">
          TARGET: {mission.planetName.toUpperCase()}
        </div>
      </div>

      {/* --- CENTER CONTENT: 2 DESTINATIONS COMPARISON --- */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 p-6 overflow-y-auto max-w-6xl mx-auto w-full">
        {(['moon', 'mars'] as Destination[]).map((dest) => {
          const m = MISSIONS_DATA[dest];
          const isSelected = selectedMission === dest;

          return (
            <div
              key={dest}
              onClick={() => selectMission(dest)}
              className={`cursor-pointer rounded-2xl border-2 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-2xl relative ${
                isSelected
                  ? 'border-[#00D9FF] bg-[#0B1F3A] ring-4 ring-[#00D9FF]/20'
                  : 'border-slate-800 bg-[#0B1F3A]/60 hover:border-slate-600'
              }`}
            >
              {/* Selected Tag */}
              {isSelected && (
                <div className="absolute top-4 right-4 z-10 bg-[#00D9FF] text-slate-950 text-[10px] font-extrabold px-3 py-1 rounded-full font-orbitron flex items-center space-x-1 shadow-md">
                  <Check className="w-3.5 h-3.5" />
                  <span>SELECTED TARGET</span>
                </div>
              )}

              {/* 3D Planet Preview Area */}
              <div className="h-52 w-full relative bg-gradient-to-b from-[#061329] to-[#0B1F3A]">
                <Canvas camera={{ position: [0, 0, 4.2], fov: 45 }}>
                  <ambientLight intensity={0.5} />
                  <directionalLight position={[4, 5, 4]} intensity={1.8} />
                  <HoloPlanet planet={dest} radius={1.4} rotationSpeed={0.2} />
                  <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.8} />
                </Canvas>
                <div className="absolute bottom-2 left-4 text-xs font-mono font-bold text-slate-300">
                  {m.subtitle}
                </div>
              </div>

              {/* Mission Details */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-bold font-orbitron text-white mb-1">{m.title}</h3>
                  <p className="text-xs text-slate-300 mb-4">{m.description}</p>

                  {/* STEM Telemetry Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-4">
                    <div className="p-2.5 bg-[#061329] rounded-xl border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">SURFACE GRAVITY:</span>
                      <strong className="text-[#00D9FF]">{m.gravity} m/s²</strong>
                      <span className="text-[10px] text-slate-400 block">({dest === 'moon' ? '1/6th Earth' : '38% Earth'})</span>
                    </div>

                    <div className="p-2.5 bg-[#061329] rounded-xl border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">DISTANCE:</span>
                      <strong className="text-[#FF9D42]">{m.distance}</strong>
                    </div>

                    <div className="p-2.5 bg-[#061329] rounded-xl border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">COMM SIGNAL DELAY:</span>
                      <strong className="text-[#39FF14]">{m.commDelay}</strong>
                    </div>

                    <div className="p-2.5 bg-[#061329] rounded-xl border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">TEMP RANGE:</span>
                      <strong className="text-[#8B5CF6]">{m.tempRange}</strong>
                    </div>
                  </div>

                  {/* Objectives Preview */}
                  <div className="space-y-1.5 mb-4">
                    <div className="text-[11px] font-bold text-slate-300 flex items-center space-x-1.5 font-mono">
                      <Target className="w-3.5 h-3.5 text-[#00D9FF]" />
                      <span>MISSION OBJECTIVES:</span>
                    </div>
                    {m.objectives.slice(0, 3).map((obj) => (
                      <div key={obj.id} className="text-xs text-slate-300 flex items-start space-x-2">
                        <span className="text-[#00D9FF] mt-0.5">•</span>
                        <span>{obj.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 italic">
                  NASA Context: {m.realNasaContext}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* --- BOTTOM ACTION BAR --- */}
      <div className="p-4 border-t border-[#00D9FF]/30 bg-[#0B1F3A]/90 flex justify-between items-center px-8">
        <button
          onClick={() => setScreen('station')}
          className="text-xs text-slate-400 hover:text-white font-mono"
        >
          Return to Station
        </button>
        <button
          onClick={() => setScreen('launch_prep')}
          className="py-3 px-8 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:from-[#1a94ff] hover:to-[#22e3ff] text-slate-950 font-bold rounded-xl transition duration-200 font-orbitron text-xs tracking-wider shadow-lg shadow-[#00D9FF]/20 flex items-center space-x-2"
        >
          <Rocket className="w-4 h-4 text-slate-950" />
          <span>PROCEED TO PRE-FLIGHT CHECKLIST →</span>
        </button>
      </div>
    </div>
  );
};
