import React from 'react';
import { X, Radio, ExternalLink, ShieldAlert, Award, Compass, BookOpen } from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { REAL_NASA_DONKI_ARCHIVE, NASA_EDUCATIONAL_FACTS } from '../../data/nasaData';

export const NASAInfoModal: React.FC = () => {
  const showNasaModal = useGameStore((state) => state.showNasaModal);
  const setShowNasaModal = useGameStore((state) => state.setShowNasaModal);

  if (!showNasaModal) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#0B1F3A] border-2 border-[#00D9FF] rounded-3xl max-w-4xl w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-700 pb-4 mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-[#061329] rounded-2xl border border-[#00D9FF]">
              <Radio className="w-6 h-6 text-[#39FF14] animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-[#00D9FF]">OFFICIAL NASA STEM INTEGRATION</div>
              <h2 className="text-xl font-bold font-orbitron text-white">NASA Space Weather & Mission Data</h2>
            </div>
          </div>
          <button
            onClick={() => setShowNasaModal(false)}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* DONKI Space Weather Feeds */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 text-xs font-mono text-[#FF9D42] mb-3">
            <ShieldAlert className="w-4 h-4" />
            <span>NASA DONKI (SPACE WEATHER DATABASE OF NOTIFICATIONS, KNOWLEDGE, AND INFORMATION)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {REAL_NASA_DONKI_ARCHIVE.map((report, idx) => (
              <div key={idx} className="bg-[#061329] border border-slate-700 rounded-2xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-mono text-slate-400">{report.timestamp}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                      report.flareClass === 'X' ? 'bg-red-950 text-red-400 border border-red-700' :
                      report.flareClass === 'M' ? 'bg-amber-950 text-amber-400 border border-amber-700' :
                      'bg-green-950 text-[#39FF14] border border-green-700'
                    }`}>
                      Class {report.flareClass} Flare
                    </span>
                  </div>

                  <div className="text-xs font-mono space-y-1 mb-2">
                    <div>Solar Wind: <strong className="text-white">{report.solarWindSpeedKmS} km/s</strong></div>
                    <div>Kp Index: <strong className="text-[#00D9FF]">{report.kpIndex} / 9</strong></div>
                  </div>

                  <p className="text-[11px] text-slate-300 mb-2">{report.summary}</p>
                </div>
                <div className="text-[9px] text-slate-500 font-mono pt-2 border-t border-slate-800">
                  Source: {report.source}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Educational STEM Tabs: Artemis & Mars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Artemis Moon Facts */}
          <div className="p-4 bg-[#061329] border border-slate-800 rounded-2xl">
            <h3 className="text-sm font-bold font-orbitron text-[#00D9FF] mb-2 flex items-center space-x-2">
              <Compass className="w-4 h-4" />
              <span>NASA Artemis Program (Moon)</span>
            </h3>
            <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside">
              <li><strong>Water Ice:</strong> {NASA_EDUCATIONAL_FACTS.moon.waterIce}</li>
              <li><strong>Low Gravity:</strong> {NASA_EDUCATIONAL_FACTS.moon.gravity}</li>
              <li><strong>Temperature Extremes:</strong> {NASA_EDUCATIONAL_FACTS.moon.temperature}</li>
              <li><strong>Moon Dust (Regolith):</strong> {NASA_EDUCATIONAL_FACTS.moon.atmosphere}</li>
            </ul>
          </div>

          {/* Mars Exploration Facts */}
          <div className="p-4 bg-[#061329] border border-slate-800 rounded-2xl">
            <h3 className="text-sm font-bold font-orbitron text-[#FF9D42] mb-2 flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>NASA Perseverance & MOXIE (Mars)</span>
            </h3>
            <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside">
              <li><strong>MOXIE Oxygen:</strong> {NASA_EDUCATIONAL_FACTS.mars.moxieExperiment}</li>
              <li><strong>Martian Gravity:</strong> {NASA_EDUCATIONAL_FACTS.mars.gravity}</li>
              <li><strong>Signal Latency:</strong> {NASA_EDUCATIONAL_FACTS.mars.commDelay}</li>
              <li><strong>Global Dust Storms:</strong> {NASA_EDUCATIONAL_FACTS.mars.dustStorms}</li>
            </ul>
          </div>
        </div>

        {/* NASA OSDR Space Biology */}
        <div className="p-4 bg-[#061329] border border-slate-800 rounded-2xl mb-6">
          <h3 className="text-sm font-bold font-orbitron text-[#39FF14] mb-2 flex items-center space-x-2">
            <Award className="w-4 h-4" />
            <span>NASA Open Science Data Repository (OSDR) Astronaut Health</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300">
            <div>
              <strong className="text-white block mb-0.5">Bone & Muscle:</strong>
              {NASA_EDUCATIONAL_FACTS.osdrScience.boneDensity}
            </div>
            <div>
              <strong className="text-white block mb-0.5">Space Farming:</strong>
              {NASA_EDUCATIONAL_FACTS.osdrScience.plantsInSpace}
            </div>
            <div>
              <strong className="text-white block mb-0.5">Water Recycling:</strong>
              {NASA_EDUCATIONAL_FACTS.osdrScience.waterRecycling}
            </div>
          </div>
        </div>

        {/* Attribution & Close */}
        <div className="pt-4 border-t border-slate-700 flex justify-between items-center text-xs text-slate-400">
          <span>NASA Space Apps Challenge 2026 STEM Educational Simulator</span>
          <button
            onClick={() => setShowNasaModal(false)}
            className="py-2.5 px-6 bg-[#00D9FF] text-slate-950 font-bold font-orbitron rounded-xl hover:bg-white"
          >
            DISMISS BRIEFING
          </button>
        </div>
      </div>
    </div>
  );
};
