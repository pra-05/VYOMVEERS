/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        space: {
          darkest: '#061329',
          deep: '#0B1F3A',
          cyan: '#00D9FF',
          blue: '#168BFF',
          purple: '#8B5CF6',
          orange: '#FF9D42',
          light: '#F3F8FF',
          neon: '#39FF14',
          alert: '#FF3B30'
        }
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        space: ['Rajdhani', 'sans-serif']
      },
      animation: {
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { filter: 'drop-shadow(0 0 10px rgba(0, 217, 255, 0.6))' },
          '50%': { filter: 'drop-shadow(0 0 25px rgba(0, 217, 255, 0.9))' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        }
      }
    },
  },
  plugins: [],
}
