import React, { useState } from 'react';
import { 
  Rocket, 
  User, 
  Package, 
  Compass, 
  HelpCircle, 
  Volume2, 
  VolumeX, 
  Award, 
  Info,
  Radio,
  Download
} from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { REAL_NASA_DONKI_ARCHIVE } from '../../data/nasaData';

export const WelcomeScreen: React.FC = () => {
  const setScreen = useGameStore((state) => state.setScreen);
  const soundMuted = useGameStore((state) => state.soundMuted);
  const toggleSound = useGameStore((state) => state.toggleSound);
  const astronaut = useGameStore((state) => state.astronaut);
  const achievements = useGameStore((state) => state.achievements);
  const setShowNasaModal = useGameStore((state) => state.setShowNasaModal);

  const [showHowToPlay, setShowHowToPlay] = useState(false);

  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const currentDonki = REAL_NASA_DONKI_ARCHIVE[0];

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 z-10">
      {/* --- TOP BAR --- */}
      <div className="flex justify-between items-start pointer-events-auto">
        {/* NASA & Project Badge */}
        <div className="bg-[#0B1F3A]/80 backdrop-blur-md border border-[#00D9FF]/40 rounded-xl p-3.5 shadow-lg shadow-[#00D9FF]/10 flex items-center space-x-3.5">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#168BFF] to-[#00D9FF] flex items-center justify-center shadow-md">
            <Rocket className="w-6 h-6 text-white transform -rotate-45" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[11px] font-bold tracking-wider px-2 py-0.5 rounded bg-[#168BFF]/30 text-[#00D9FF] border border-[#00D9FF]/30">
                NASA SPACE APPS 2026
              </span>
              <span className="text-xs text-slate-300 font-mono">AGES 7–12</span>
            </div>
            <h1 className="text-xl font-extrabold tracking-wide font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-white via-[#00D9FF] to-[#168BFF]">
              VYOMVEER
            </h1>
            <p className="text-xs text-[#00D9FF]/90 font-medium">Junior Astronaut Mission Trainer</p>
          </div>
        </div>

        {/* Right Action Icons: NASA DONKI pill, Download ZIP, Mute toggle */}
        <div className="flex items-center space-x-3">
          {/* Direct Download ZIP Button */}
          <a
            href="/vyomveer-game.zip"
            download="vyomveer-game.zip"
            className="flex items-center space-x-2 bg-[#0B1F3A]/80 hover:bg-[#00D9FF]/25 border border-[#00D9FF]/40 rounded-xl px-3.5 py-2 text-xs transition duration-200 text-[#00D9FF] shadow-md group"
            title="Download Full Project Source Code in ZIP"
          >
            <Download className="w-4 h-4 text-[#00D9FF] group-hover:translate-y-0.5 transition" />
            <span className="font-mono text-xs hidden sm:inline font-bold">DOWNLOAD ZIP</span>
          </a>

          {/* NASA DONKI Live Space Weather Pill */}
          <button 
            onClick={() => setShowNasaModal(true)}
            className="hidden sm:flex items-center space-x-2 bg-[#0B1F3A]/80 hover:bg-[#168BFF]/20 border border-[#00D9FF]/40 rounded-xl px-3 py-2 text-xs transition duration-200 shadow-md"
            title="Click to view NASA DONKI Space Weather & Artemis Data"
          >
            <Radio className="w-4 h-4 text-[#39FF14] animate-pulse" />
            <div className="text-left font-mono">
              <div className="text-[10px] text-slate-400">NASA DONKI FEED</div>
              <div className="text-xs text-[#00D9FF] font-semibold">Kp {currentDonki.kpIndex} • Flare Class {currentDonki.flareClass} (Quiet)</div>
            </div>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-3 bg-[#0B1F3A]/80 hover:bg-[#168BFF]/30 border border-[#00D9FF]/40 rounded-xl transition duration-200 text-[#00D9FF] shadow-md"
            title={soundMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {soundMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-[#00D9FF]" />}
          </button>
        </div>
      </div>

      {/* --- CENTER / LOWER MENU NAVIGATION --- */}
      <div className="max-w-xl mx-auto w-full pointer-events-auto mb-4">
        {/* Astronaut Welcome Pill */}
        <div className="bg-[#0B1F3A]/85 backdrop-blur-md border border-[#00D9FF]/30 rounded-2xl p-4 mb-4 text-center shadow-xl">
          <p className="text-xs text-[#00D9FF] font-mono tracking-wider uppercase mb-1">
            Orbital Gateway Command Station
          </p>
          <h2 className="text-lg md:text-xl font-bold text-white font-space">
            Welcome Aboard, <span className="text-[#FF9D42]">{astronaut.name}</span>!
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
            Prepare for lunar and Martian expeditions, learn real NASA astronaut science, manage survival life support, and explore alien worlds.
          </p>
        </div>

        {/* 4 Main Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setScreen('mission_select')}
            className="flex items-center justify-center space-x-2.5 p-4 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:from-[#1a94ff] hover:to-[#22e3ff] text-slate-950 font-bold rounded-xl shadow-lg shadow-[#00D9FF]/20 transform hover:-translate-y-0.5 transition duration-200 font-orbitron text-sm tracking-wider"
          >
            <Compass className="w-5 h-5 text-slate-950" />
            <span>START MISSION</span>
          </button>

          <button
            onClick={() => setScreen('customization')}
            className="flex items-center justify-center space-x-2.5 p-4 bg-[#0B1F3A]/90 hover:bg-[#168BFF]/30 border border-[#00D9FF]/40 text-white font-semibold rounded-xl shadow-md transform hover:-translate-y-0.5 transition duration-200 font-space text-sm"
          >
            <User className="w-5 h-5 text-[#00D9FF]" />
            <span>CUSTOMIZE ASTRONAUT</span>
          </button>

          <button
            onClick={() => setScreen('equipment')}
            className="flex items-center justify-center space-x-2.5 p-3.5 bg-[#0B1F3A]/90 hover:bg-[#168BFF]/30 border border-[#00D9FF]/40 text-white font-semibold rounded-xl shadow-md transform hover:-translate-y-0.5 transition duration-200 font-space text-sm"
          >
            <Package className="w-5 h-5 text-[#FF9D42]" />
            <span>EQUIPMENT BAY</span>
          </button>

          <button
            onClick={() => setShowHowToPlay(true)}
            className="flex items-center justify-center space-x-2.5 p-3.5 bg-[#0B1F3A]/90 hover:bg-[#168BFF]/30 border border-[#00D9FF]/40 text-white font-semibold rounded-xl shadow-md transform hover:-translate-y-0.5 transition duration-200 font-space text-sm"
          >
            <HelpCircle className="w-5 h-5 text-[#39FF14]" />
            <span>HOW TO PLAY & STEM</span>
          </button>
        </div>

        {/* Progress & Achievements Pill */}
        <div className="flex justify-between items-center bg-[#061329]/90 border border-[#00D9FF]/20 rounded-xl px-4 py-2.5 mt-3 text-xs text-slate-300 font-mono">
          <div className="flex items-center space-x-2">
            <Award className="w-4 h-4 text-[#FF9D42]" />
            <span>Badges Unlocked: <strong className="text-white">{unlockedCount} / {achievements.length}</strong></span>
          </div>
          <button 
            onClick={() => setScreen('results')} 
            className="text-[#00D9FF] hover:underline"
          >
            View Career Log →
          </button>
        </div>
      </div>

      {/* --- HOW TO PLAY MODAL --- */}
      {showHowToPlay && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 pointer-events-auto">
          <div className="bg-[#0B1F3A] border-2 border-[#00D9FF] rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button 
              onClick={() => setShowHowToPlay(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold"
            >
              ✕
            </button>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-[#168BFF]/20 rounded-lg border border-[#00D9FF]">
                <HelpCircle className="w-6 h-6 text-[#00D9FF]" />
              </div>
              <div>
                <h3 className="text-lg font-bold font-orbitron text-white">How To Play VYOMVEER</h3>
                <p className="text-xs text-[#00D9FF]">Junior Astronaut Guide for Space Explorers</p>
              </div>
            </div>

            <div className="space-y-3.5 text-xs text-slate-200">
              <div className="p-3 bg-[#061329] rounded-xl border border-slate-700">
                <h4 className="font-bold text-[#FF9D42] mb-1">1. Customize & Equip</h4>
                <p>Personalize your 3D astronaut with colorful suits, reflective visors, and mission badges. Select oxygen, water, solar panels, and scientific tools for your expedition.</p>
              </div>

              <div className="p-3 bg-[#061329] rounded-xl border border-slate-700">
                <h4 className="font-bold text-[#00D9FF] mb-1">2. Launch & Land</h4>
                <p>Ignite your rocket thrusters to journey to the Moon or Mars. Watch the dramatic retro-rocket landing sequence and see your astronaut egress onto the alien surface!</p>
              </div>

              <div className="p-3 bg-[#061329] rounded-xl border border-slate-700">
                <h4 className="font-bold text-[#39FF14] mb-1">3. Explore & Drive the Rover</h4>
                <p>Move with <kbd className="px-1 py-0.5 bg-slate-800 rounded text-[#00D9FF]">W</kbd><kbd className="px-1 py-0.5 bg-slate-800 rounded text-[#00D9FF]">A</kbd><kbd className="px-1 py-0.5 bg-slate-800 rounded text-[#00D9FF]">S</kbd><kbd className="px-1 py-0.5 bg-slate-800 rounded text-[#00D9FF]">D</kbd> or on-screen touch arrows. Jump in low gravity with <kbd className="px-1 py-0.5 bg-slate-800 rounded">SPACE</kbd>. Click the <strong>"Drive Rover"</strong> button to pilot the 6-wheel terrain vehicle across craters!</p>
              </div>

              <div className="p-3 bg-[#061329] rounded-xl border border-slate-700">
                <h4 className="font-bold text-[#8B5CF6] mb-1">4. Manage Outpost Life Support</h4>
                <p>Monitor your Oxygen, Water, Food, and Power. Clean dust from solar arrays to restore energy, grow crops in the bio-dome, and shield against NASA DONKI space weather solar storms!</p>
              </div>
            </div>

            <button
              onClick={() => setShowHowToPlay(false)}
              className="mt-5 w-full py-3 bg-[#168BFF] hover:bg-[#00D9FF] text-slate-950 font-bold rounded-xl transition duration-200 font-orbitron text-xs"
            >
              GOT IT, FLIGHT DIRECTOR!
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
