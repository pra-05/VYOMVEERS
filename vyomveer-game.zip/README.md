# VYOMVEER – JUNIOR ASTRONAUT MISSION TRAINER
### NASA Space Apps Challenge 2026 | STEM Space Simulation Game

**VYOMVEER** is a complete, browser-based 3D educational space exploration and survival adventure game built for children aged 7–12. It teaches young astronauts how real space explorers plan missions, live off-world, manage life support resources, drive planetary rovers, and survive cosmic weather events.

---

## 🚀 Key Features

1. **Futuristic 3D Space Station (Orbital Gateway)**
   - Observation cupola overlooking photorealistic rotating Earth with glowing blue atmosphere.
   - 3D holographic previews of Earth, Moon, Mars, and Sun with orbital telemetry rings.
   - Floating weightless astronaut with idle zero-g animations.
   - Interactive access to all mission modules.

2. **Astronaut Customization Bay**
   - Live 3D character viewer with 360° orbit and auto-spin.
   - Choose suit colors, reflective helmet visors (Gold mirror, Cyan holo, Obsidian), gloves, boots, and PLSS backpack.
   - Select mission patches: **NASA Artemis**, **NASA Retro Worm**, **VYOM Star**, and **Mars Pathfinder**.
   - Custom cadet callsign with state persistence via `localStorage`.

3. **Cargo & Equipment Bay**
   - High-Pressure O₂ Tanks, Closed-Loop Water Purifiers, Space Rations, UltraFlex Solar Wings, Solid-State Batteries, Raman Spectrometer, and Deep Space Optical Comms.
   - Real-time payload weight calculation and capacity budget bar.
   - Authentic NASA STEM facts for every equipment piece.

4. **Planetary Destinations (Moon vs. Mars)**
   - **Moon (Artemis Base Camp - Shackleton Crater)**: 1.62 m/s² gravity (1/6th Earth), water ice exploration, extreme temperature swings.
   - **Mars (Ares Red Horizon - Jezero Crater)**: 3.72 m/s² gravity (38% Earth), ancient dried river delta, hematite blueberries, MOXIE oxygen production.

5. **Pre-Flight Launch Verification & Liftoff Sequence**
   - Interactive 5-step checklist for young astronauts.
   - Animated Starship launch sequence with countdown (T-3... T-0: Liftoff!), stage separation, and orbital transit.

6. **Cinematic Rocket Landing Sequence (Moon & Mars)**
   - Retro-propulsion descent through planetary sky.
   - Shock-absorbing landing leg deployment, thruster plumes, and landing pad touchdown.

7. **Astronaut Egress Scene (Come Out from the Rocket)**
   - Airlock depressurization and hatch door opening with vapor release.
   - Elevator platform lowers astronaut down the hull.
   - Astronaut takes "One Giant Leap", steps onto the regolith, waves to Mission Control, and plants the expedition flag!

8. **Planetary Surface Exploration & Rover Driving**
   - **Walking Mode**: Walk, run, and float-jump with authentic low-gravity physics (high floaty jumps on Moon, medium jumps on Mars).
   - **Rover Driving Mode**: Press the **"DRIVE ROVER"** button or click on-screen controls to pilot the 6-wheel rover with rotating all-terrain wheels, camera mast tracking, dual headlights, and engine sound!
   - Discover and collect 3 real geological specimens per destination (Anorthosite, Water-Ice Core, Basalt, Hematite Blueberries, Riverbed Delta Clay).

9. **Outpost Life Support & Resource Simulation Engine**
   - Real mathematical formula:
     $$\text{Remaining Resource} = \text{Starting Resource} + \text{Generated} - \text{Consumed}$$
   - Wipe dust off solar arrays to restore electrical power to 100%.
   - Activate hydroponic greenhouse bio-dome for fresh crops and oxygen.
   - Toggle water electrolysis and MOXIE units.
   - Engage electromagnetic radiation deflector shields.

10. **Official NASA Data Integration & STEM Hub**
    - **NASA DONKI** space weather archives (Solar flares, Coronal Mass Ejections, Kp index, solar wind speed).
    - **NASA Artemis & Perseverance** mission data.
    - **NASA OSDR (Open Science Data Repository)** astronaut biology insights.

11. **Results, Achievements & Sound Synthesis**
    - 1-to-3 Star rating system, XP points, and celebratory confetti.
    - Web Audio API real-time sci-fi sound synthesizer (rocket rumble, rover motor, sample collect chimes, warning klaxons, and fanfare).

---

## 🛠️ Technology Stack

- **Framework**: React 18 + TypeScript + Vite 6
- **3D Graphics**: Three.js + React Three Fiber (R3F) + Drei
- **State Management**: Zustand with `persist` middleware (`localStorage`)
- **Styling**: Tailwind CSS + custom Orbitron & Rajdhani Google Fonts
- **Audio**: Web Audio API Procedural Synthesizer (zero external audio asset dependencies)
- **Effects**: canvas-confetti, Lucide React icons

---

## 🎮 How to Run the Game

To launch the game locally in your browser:

```bash
cd "C:\Users\ADMIN\.gemini\antigravity\scratch\vyomveer-game"
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000) in any modern web browser (Chrome, Edge, Firefox, Safari).

### Controls:
- **Move / Steer**: `W`, `A`, `S`, `D` or `Arrow Keys`
- **Jump**: `Spacebar` (low-gravity jump)
- **Interact / Collect / Board**: `E`
- **Rover Drive**: Press the on-screen **"DRIVE ROVER"** button or use the touch directional D-Pad
- **Camera**: Left click + drag mouse to orbit 360°, scroll wheel to zoom
