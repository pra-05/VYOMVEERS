import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGameStore } from '../../store/useGameStore';

interface Astronaut3DProps {
  scale?: number;
  isFloating?: boolean;
  isWalking?: boolean;
  isJumping?: boolean;
  isDriving?: boolean;
  rotationY?: number;
}

export const Astronaut3D: React.FC<Astronaut3DProps> = ({
  scale = 1,
  isFloating = false,
  isWalking = false,
  isJumping = false,
  isDriving = false,
  rotationY = 0
}) => {
  const astronaut = useGameStore((state) => state.astronaut);
  const groupRef = useRef<THREE.Group>(null);
  const leftLegRef = useRef<THREE.Group>(null);
  const rightLegRef = useRef<THREE.Group>(null);
  const leftArmRef = useRef<THREE.Group>(null);
  const rightArmRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();

    if (groupRef.current) {
      if (isFloating) {
        groupRef.current.position.y = Math.sin(t * 1.5) * 0.15;
        groupRef.current.rotation.z = Math.sin(t * 0.8) * 0.05;
        groupRef.current.rotation.x = Math.cos(t * 1.2) * 0.04;
      } else {
        groupRef.current.position.y = isJumping ? 0.4 : 0;
      }
    }

    // Walking animation for limbs
    if (isWalking && leftLegRef.current && rightLegRef.current && leftArmRef.current && rightArmRef.current) {
      const walkSpeed = 8;
      const legAngle = Math.sin(t * walkSpeed) * 0.55;
      const armAngle = Math.cos(t * walkSpeed) * 0.45;

      leftLegRef.current.rotation.x = legAngle;
      rightLegRef.current.rotation.x = -legAngle;
      leftArmRef.current.rotation.x = -armAngle;
      rightArmRef.current.rotation.x = armAngle;
    } else if (isDriving) {
      // Sitting / driving pose
      if (leftLegRef.current && rightLegRef.current) {
        leftLegRef.current.rotation.x = -Math.PI / 2.5;
        rightLegRef.current.rotation.x = -Math.PI / 2.5;
      }
      if (leftArmRef.current && rightArmRef.current) {
        leftArmRef.current.rotation.x = -Math.PI / 4;
        rightArmRef.current.rotation.x = -Math.PI / 4;
      }
    } else {
      // Idle breathing and slight subtle sway
      if (leftLegRef.current && rightLegRef.current && leftArmRef.current && rightArmRef.current) {
        leftLegRef.current.rotation.x = 0;
        rightLegRef.current.rotation.x = 0;
        leftArmRef.current.rotation.x = Math.sin(t * 2) * 0.05;
        rightArmRef.current.rotation.x = -Math.sin(t * 2) * 0.05;
      }
    }

    if (headRef.current && isFloating) {
      headRef.current.rotation.y = Math.sin(t * 1.0) * 0.15;
    }
  });

  return (
    <group ref={groupRef} scale={[scale, scale, scale]} rotation={[0, rotationY, 0]}>
      {/* --- TORSO & CHEST LIFE SUPPORT PACK --- */}
      <mesh position={[0, 1.25, 0]} castShadow>
        <boxGeometry args={[0.7, 0.85, 0.45]} />
        <meshStandardMaterial color={astronaut.suitColor} roughness={0.4} metalness={0.2} />
      </mesh>

      {/* Torso Suit Stripe Accent */}
      <mesh position={[0, 1.25, 0.23]}>
        <boxGeometry args={[0.5, 0.65, 0.02]} />
        <meshStandardMaterial color={astronaut.accentColor} roughness={0.3} metalness={0.5} />
      </mesh>

      {/* Chest Mission Badge */}
      <mesh position={[0.18, 1.45, 0.24]}>
        <circleGeometry args={[0.07, 16]} />
        <meshStandardMaterial 
          color={astronaut.badge === 'artemis' ? '#FF9D42' : astronaut.badge === 'nasa_worm' ? '#FF3B30' : '#00D9FF'} 
          emissive={astronaut.accentColor}
          emissiveIntensity={0.3}
        />
      </mesh>

      {/* Chest Control Dials */}
      <mesh position={[-0.15, 1.25, 0.24]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.04, 0.04, 0.03, 12]} />
        <meshStandardMaterial color="#00D9FF" emissive="#00D9FF" emissiveIntensity={0.6} />
      </mesh>
      <mesh position={[-0.05, 1.25, 0.24]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.04, 0.04, 0.03, 12]} />
        <meshStandardMaterial color="#39FF14" emissive="#39FF14" emissiveIntensity={0.6} />
      </mesh>

      {/* --- BACKPACK (PLSS - Portable Life Support System) --- */}
      <group position={[0, 1.3, -0.32]}>
        <mesh castShadow>
          <boxGeometry args={[0.62, 0.75, 0.28]} />
          <meshStandardMaterial color={astronaut.backpackColor} roughness={0.5} metalness={0.3} />
        </mesh>
        {/* Oxygen Tanks on Backpack */}
        <mesh position={[-0.16, 0.05, -0.06]}>
          <cylinderGeometry args={[0.08, 0.08, 0.6, 16]} />
          <meshStandardMaterial color="#00D9FF" metalness={0.6} roughness={0.3} />
        </mesh>
        <mesh position={[0.16, 0.05, -0.06]}>
          <cylinderGeometry args={[0.08, 0.08, 0.6, 16]} />
          <meshStandardMaterial color="#00D9FF" metalness={0.6} roughness={0.3} />
        </mesh>
        {/* Thruster Nozzle on Backpack (SAFER) */}
        <mesh position={[0, 0.25, -0.1]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.05, 0.07, 0.1, 12]} />
          <meshStandardMaterial color="#555555" metalness={0.8} />
        </mesh>
      </group>

      {/* --- HEAD & HELMET --- */}
      <group ref={headRef} position={[0, 1.85, 0]}>
        {/* Outer Helmet Sphere */}
        <mesh castShadow>
          <sphereGeometry args={[0.38, 28, 28]} />
          <meshStandardMaterial color={astronaut.helmetColor} roughness={0.3} metalness={0.2} />
        </mesh>

        {/* Golden / Cyan Reflective Visor */}
        <mesh position={[0, 0.02, 0.15]}>
          <sphereGeometry args={[0.29, 24, 24, 0, Math.PI, 0, Math.PI * 0.75]} />
          <meshPhysicalMaterial 
            color={astronaut.visorColor} 
            metalness={0.9} 
            roughness={0.1} 
            reflectivity={1.0}
            clearcoat={1.0}
            clearcoatRoughness={0.1}
            emissive={astronaut.visorColor}
            emissiveIntensity={0.15}
          />
        </mesh>

        {/* Helmet Flashlights / Sensors on Sides */}
        <mesh position={[0.38, 0.05, 0.05]} rotation={[0, 0, -Math.PI / 2]}>
          <cylinderGeometry args={[0.05, 0.05, 0.08, 12]} />
          <meshStandardMaterial color="#222222" />
        </mesh>
        <mesh position={[0.42, 0.05, 0.05]}>
          <circleGeometry args={[0.04, 12]} />
          <meshBasicMaterial color="#FFFFFF" />
        </mesh>
        <mesh position={[-0.38, 0.05, 0.05]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.05, 0.05, 0.08, 12]} />
          <meshStandardMaterial color="#222222" />
        </mesh>
        <mesh position={[-0.42, 0.05, 0.05]}>
          <circleGeometry args={[0.04, 12]} />
          <meshBasicMaterial color="#FFFFFF" />
        </mesh>
      </group>

      {/* --- ARMS --- */}
      {/* Left Arm */}
      <group ref={leftArmRef} position={[-0.46, 1.55, 0]}>
        <mesh position={[0, -0.25, 0]} castShadow>
          <capsuleGeometry args={[0.11, 0.45, 12, 12]} />
          <meshStandardMaterial color={astronaut.suitColor} roughness={0.4} />
        </mesh>
        {/* Left Glove */}
        <mesh position={[0, -0.55, 0]} castShadow>
          <sphereGeometry args={[0.13, 16, 16]} />
          <meshStandardMaterial color={astronaut.glovesColor} roughness={0.6} />
        </mesh>
      </group>

      {/* Right Arm */}
      <group ref={rightArmRef} position={[0.46, 1.55, 0]}>
        <mesh position={[0, -0.25, 0]} castShadow>
          <capsuleGeometry args={[0.11, 0.45, 12, 12]} />
          <meshStandardMaterial color={astronaut.suitColor} roughness={0.4} />
        </mesh>
        {/* Right Glove */}
        <mesh position={[0, -0.55, 0]} castShadow>
          <sphereGeometry args={[0.13, 16, 16]} />
          <meshStandardMaterial color={astronaut.glovesColor} roughness={0.6} />
        </mesh>
      </group>

      {/* --- LEGS --- */}
      {/* Left Leg */}
      <group ref={leftLegRef} position={[-0.2, 0.82, 0]}>
        <mesh position={[0, -0.35, 0]} castShadow>
          <capsuleGeometry args={[0.13, 0.6, 12, 12]} />
          <meshStandardMaterial color={astronaut.suitColor} roughness={0.4} />
        </mesh>
        {/* Left Boot */}
        <mesh position={[0, -0.75, 0.06]} castShadow>
          <boxGeometry args={[0.22, 0.18, 0.36]} />
          <meshStandardMaterial color={astronaut.bootsColor} roughness={0.5} />
        </mesh>
      </group>

      {/* Right Leg */}
      <group ref={rightLegRef} position={[0.2, 0.82, 0]}>
        <mesh position={[0, -0.35, 0]} castShadow>
          <capsuleGeometry args={[0.13, 0.6, 12, 12]} />
          <meshStandardMaterial color={astronaut.suitColor} roughness={0.4} />
        </mesh>
        {/* Right Boot */}
        <mesh position={[0, -0.75, 0.06]} castShadow>
          <boxGeometry args={[0.22, 0.18, 0.36]} />
          <meshStandardMaterial color={astronaut.bootsColor} roughness={0.5} />
        </mesh>
      </group>
    </group>
  );
};
