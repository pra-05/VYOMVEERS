import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  GameScreen, 
  Destination, 
  VehicleMode, 
  AstronautConfig, 
  EquipmentConfig, 
  ResourceState, 
  SampleItem, 
  ScienceOutpost, 
  SpaceWeatherAlert, 
  MissionEvent, 
  Achievement, 
  ActivityLog, 
  MissionObjective 
} from '../types/game';
import { MISSIONS_DATA } from '../data/missionsData';
import { INITIAL_ACHIEVEMENTS } from '../data/achievementsData';
import { REAL_NASA_DONKI_ARCHIVE } from '../data/nasaData';
import { soundManager } from '../utils/soundEffects';

const INITIAL_ASTRONAUT: AstronautConfig = {
  name: 'Vyom Cadet',
  gender: 'cadet_alex',
  skinTone: '#F0C08A',
  hairStyle: 'short',
  hairColor: '#2C1B18',
  suitColor: '#FFFFFF',
  accentColor: '#00D9FF',
  helmetColor: '#F3F8FF',
  visorColor: '#FFD700',
  glovesColor: '#168BFF',
  bootsColor: '#168BFF',
  backpackColor: '#0B1F3A',
  badge: 'artemis'
};

const INITIAL_EQUIPMENT: EquipmentConfig = {
  oxygenTanks: 4,
  waterPurifiers: 3,
  foodRations: 4,
  firstAidKits: 2,
  researchTools: 2,
  commRelays: 2,
  solarPanels: 3,
  emergencyBatteries: 2,
  roverDrillModules: 2
};

const INITIAL_RESOURCES: ResourceState = {
  oxygen: 100,
  water: 95,
  food: 90,
  power: 100,
  radiationProtection: 100,
  roverBattery: 100,
  habitatIntegrity: 100
};

const INITIAL_OUTPOST: ScienceOutpost = {
  solarArraysClean: true,
  greenhouseActive: true,
  electrolysisActive: false,
  shieldingActive: false,
  lastMaintenance: Date.now()
};

export const MOON_SAMPLES: SampleItem[] = [
  {
    id: 's_moon_1',
    name: 'Anorthosite Highland Rock',
    type: 'lunar_anorthosite',
    position: [8, 0.4, 6],
    collected: false,
    description: 'Ancient light-colored plagioclase feldspar rock from the lunar crust, over 4.4 billion years old!',
    scienceFact: 'Similar to the famous "Genesis Rock" retrieved by Apollo 15, showing the Moon once had a magma ocean.',
    weightKg: 2.4
  },
  {
    id: 's_moon_2',
    name: 'South Pole Water-Ice Core',
    type: 'water_ice',
    position: [-14, 0.4, -10],
    collected: false,
    description: 'Sub-surface cryo-frozen volatile ice trapped inside permanently shadowed crater permafrost.',
    scienceFact: 'NASA LCROSS confirmed billions of tons of water-ice at the lunar South Pole, vital for rocket fuel and drinking water.',
    weightKg: 3.1
  },
  {
    id: 's_moon_3',
    name: 'Titanium-Rich Mare Basalt',
    type: 'basalt',
    position: [16, 0.4, -14],
    collected: false,
    description: 'Dark volcanic rock formed from cooled lava flows containing ilmenite (iron titanium oxide).',
    scienceFact: 'Contains trapped solar wind helium-3 and abundant titanium for 3D printing moon base structures.',
    weightKg: 4.0
  }
];

export const MARS_SAMPLES: SampleItem[] = [
  {
    id: 's_mars_1',
    name: 'Hematite "Blueberry" Spherule',
    type: 'martian_hematite',
    position: [10, 0.4, 7],
    collected: false,
    description: 'Spherical concretions of iron oxide mineral that formed inside standing liquid water billions of years ago.',
    scienceFact: 'First discovered by NASA Opportunity rover in Meridiani Planum, proving ancient Mars had liquid acidic water.',
    weightKg: 1.8
  },
  {
    id: 's_mars_2',
    name: 'Ancient Riverbed Delta Clay',
    type: 'mineral',
    position: [-12, 0.4, -12],
    collected: false,
    description: 'Fine-grained smectite clay sediment transported by an ancient rushing Martian river into Jezero lake.',
    scienceFact: 'Clays preserve organic molecules and microscopic fossil traces of ancient biosignatures if microbial life ever existed.',
    weightKg: 2.6
  },
  {
    id: 's_mars_3',
    name: 'Martian Volcanic Olivine Crust',
    type: 'basalt',
    position: [18, 0.4, -8],
    collected: false,
    description: 'Igneous rock formed from early magma crystallization, rich in magnesium silicate.',
    scienceFact: 'Studied by NASA Perseverance PIXL instrument to date the volcanic timeline of Jezero Crater.',
    weightKg: 3.5
  }
];

interface GameStoreState {
  screen: GameScreen;
  astronaut: AstronautConfig;
  equipment: EquipmentConfig;
  selectedMission: Destination;
  resources: ResourceState;
  vehicleMode: VehicleMode;
  astronautPosition: [number, number, number];
  roverPosition: [number, number, number];
  roverRotation: number;
  outpost: ScienceOutpost;
  samples: SampleItem[];
  objectives: MissionObjective[];
  weatherAlert: SpaceWeatherAlert | null;
  currentEvent: MissionEvent | null;
  achievements: Achievement[];
  missionTime: number;
  score: number;
  soundMuted: boolean;
  logs: ActivityLog[];
  showNasaModal: boolean;

  // Actions
  setScreen: (screen: GameScreen) => void;
  updateAstronaut: (config: Partial<AstronautConfig>) => void;
  updateEquipment: (config: Partial<EquipmentConfig>) => void;
  selectMission: (destination: Destination) => void;
  startLaunchSequence: () => void;
  finishLaunchToLanding: () => void;
  finishLandingToExit: () => void;
  finishExitToExploration: () => void;
  toggleVehicleMode: () => void;
  setVehicleMode: (mode: VehicleMode) => void;
  setAstronautPosition: (pos: [number, number, number]) => void;
  setRoverPosition: (pos: [number, number, number], rot?: number) => void;
  collectSample: (sampleId: string) => void;
  cleanSolarPanels: () => void;
  toggleGreenhouse: () => void;
  toggleElectrolysis: () => void;
  toggleShielding: () => void;
  triggerWeatherAlert: (alert?: SpaceWeatherAlert) => void;
  dismissWeatherAlert: () => void;
  unlockAchievement: (id: string) => void;
  addLog: (text: string, type?: 'info' | 'science' | 'alert' | 'success') => void;
  tickSimulation: () => void;
  toggleSound: () => void;
  setShowNasaModal: (show: boolean) => void;
  resetGame: () => void;
}

export const useGameStore = create<GameStoreState>()(
  persist(
    (set, get) => ({
      screen: 'station',
      astronaut: INITIAL_ASTRONAUT,
      equipment: INITIAL_EQUIPMENT,
      selectedMission: 'moon',
      resources: INITIAL_RESOURCES,
      vehicleMode: 'astronaut',
      astronautPosition: [0, 0, 0],
      roverPosition: [6, 0, 4],
      roverRotation: 0,
      outpost: INITIAL_OUTPOST,
      samples: MOON_SAMPLES,
      objectives: MISSIONS_DATA.moon.objectives,
      weatherAlert: null,
      currentEvent: null,
      achievements: INITIAL_ACHIEVEMENTS,
      missionTime: 0,
      score: 100,
      soundMuted: false,
      logs: [
        {
          id: '1',
          timestamp: '00:00',
          text: 'Welcome to VYOMVEER Junior Astronaut Station! Systems nominal.',
          type: 'info'
        }
      ],
      showNasaModal: false,

      setScreen: (screen) => {
        soundManager.playClick();
        set({ screen });
      },

      updateAstronaut: (config) => {
        soundManager.playClick();
        set((state) => ({
          astronaut: { ...state.astronaut, ...config }
        }));
      },

      updateEquipment: (config) => {
        soundManager.playClick();
        set((state) => ({
          equipment: { ...state.equipment, ...config }
        }));
      },

      selectMission: (destination) => {
        soundManager.playClick();
        const mission = MISSIONS_DATA[destination];
        const newSamples = destination === 'moon' ? MOON_SAMPLES : MARS_SAMPLES;
        set({
          selectedMission: destination,
          objectives: mission.objectives.map(o => ({ ...o, completed: false })),
          samples: newSamples.map(s => ({ ...s, collected: false })),
          astronautPosition: [0, 0, 0],
          roverPosition: [6, 0, 4],
          vehicleMode: 'astronaut'
        });
        get().addLog(`Selected Destination: ${mission.title}. Target set for ${mission.planetName}.`, 'info');
      },

      startLaunchSequence: () => {
        soundManager.playThruster(4.0);
        // Calculate starting resources based on selected equipment
        const eq = get().equipment;
        const initialO2 = Math.min(100, 60 + eq.oxygenTanks * 8);
        const initialWater = Math.min(100, 50 + eq.waterPurifiers * 12);
        const initialFood = Math.min(100, 55 + eq.foodRations * 9);
        const initialPower = Math.min(100, 65 + eq.solarPanels * 8 + eq.emergencyBatteries * 5);

        set({
          screen: 'launch_anim',
          resources: {
            oxygen: initialO2,
            water: initialWater,
            food: initialFood,
            power: initialPower,
            radiationProtection: 100,
            roverBattery: 100,
            habitatIntegrity: 100
          }
        });
        get().addLog('T-0: Main Engine Ignition! Spacecraft launched into transit trajectory.', 'info');
      },

      finishLaunchToLanding: () => {
        soundManager.playThruster(3.5);
        set({ screen: 'landing_anim' });
        const mission = MISSIONS_DATA[get().selectedMission];
        get().addLog(`Entering ${mission.planetName} gravity field. Retro-propulsion activated!`, 'info');
      },

      finishLandingToExit: () => {
        soundManager.playAirlock();
        // Complete the landing objective
        const missionId = get().selectedMission;
        const landingObjId = missionId === 'moon' ? 'obj_moon_land' : 'obj_mars_land';
        set((state) => ({
          screen: 'exit_rocket_anim',
          objectives: state.objectives.map((o) => 
            o.id === landingObjId ? { ...o, completed: true } : o
          ),
          score: state.score + 150
        }));
        get().addLog('Touchdown confirmed! Lunar/Martian surface contact sensors verified.', 'success');
      },

      finishExitToExploration: () => {
        soundManager.playClick();
        const missionId = get().selectedMission;
        const exitObjId = missionId === 'moon' ? 'obj_moon_exit' : 'obj_mars_exit';
        get().unlockAchievement('ach_first_steps');
        set((state) => ({
          screen: 'surface_exploration',
          objectives: state.objectives.map((o) => 
            o.id === exitObjId ? { ...o, completed: true } : o
          ),
          score: state.score + 120
        }));
        get().addLog('Airlock door opened. Astronaut has stepped onto the alien terrain!', 'success');
      },

      toggleVehicleMode: () => {
        const nextMode: VehicleMode = get().vehicleMode === 'astronaut' ? 'rover' : 'astronaut';
        get().setVehicleMode(nextMode);
      },

      setVehicleMode: (mode) => {
        if (mode === 'rover') {
          soundManager.startRoverEngine();
          get().unlockAchievement('ach_rover_ace');
          const missionId = get().selectedMission;
          const roverObjId = missionId === 'moon' ? 'obj_moon_rover' : 'obj_mars_rover';
          set((state) => ({
            vehicleMode: 'rover',
            objectives: state.objectives.map((o) => 
              o.id === roverObjId ? { ...o, completed: true } : o
            ),
            score: state.score + 100
          }));
          get().addLog('Rover control interface active. Driving mode engaged!', 'info');
        } else {
          soundManager.stopRoverEngine();
          soundManager.playClick();
          set({ vehicleMode: 'astronaut' });
          get().addLog('Exited Rover. Walking mode active.', 'info');
        }
      },

      setAstronautPosition: (pos) => {
        set({ astronautPosition: pos });
      },

      setRoverPosition: (pos, rot) => {
        set((state) => ({
          roverPosition: pos,
          roverRotation: rot !== undefined ? rot : state.roverRotation,
          resources: {
            ...state.resources,
            roverBattery: Math.max(0, state.resources.roverBattery - 0.05)
          }
        }));
      },

      collectSample: (sampleId) => {
        const sample = get().samples.find(s => s.id === sampleId);
        if (!sample || sample.collected) return;

        soundManager.playSampleCollect();
        const researchBonus = get().equipment.researchTools * 40;
        const updatedSamples = get().samples.map(s => s.id === sampleId ? { ...s, collected: true } : s);
        const allCollected = updatedSamples.every(s => s.collected);

        const missionId = get().selectedMission;
        const sampleObjId = missionId === 'moon' ? 'obj_moon_samples' : 'obj_mars_samples';

        set((state) => ({
          samples: updatedSamples,
          score: state.score + 200 + researchBonus,
          objectives: allCollected 
            ? state.objectives.map(o => o.id === sampleObjId ? { ...o, completed: true } : o)
            : state.objectives
        }));

        get().addLog(`Discovered sample: ${sample.name}! ${sample.scienceFact}`, 'science');

        if (allCollected) {
          get().unlockAchievement('ach_geologist');
          get().addLog('All planetary geological samples successfully collected!', 'success');
        }
      },

      cleanSolarPanels: () => {
        soundManager.playClick();
        const missionId = get().selectedMission;
        const outpostObjId = missionId === 'moon' ? 'obj_moon_outpost' : 'obj_mars_outpost';
        set((state) => ({
          outpost: { ...state.outpost, solarArraysClean: true },
          resources: {
            ...state.resources,
            power: Math.min(100, state.resources.power + 15)
          },
          score: state.score + 100,
          objectives: state.objectives.map((o) =>
            o.id === outpostObjId ? { ...o, completed: true } : o
          )
        }));
        get().unlockAchievement('ach_clean_energy');
        get().addLog('Solar panels wiped clean of dust. Photovoltaic efficiency at 100%!', 'success');
      },

      toggleGreenhouse: () => {
        soundManager.playClick();
        const missionId = get().selectedMission;
        const outpostObjId = missionId === 'moon' ? 'obj_moon_outpost' : 'obj_mars_outpost';
        const nextState = !get().outpost.greenhouseActive;
        set((state) => ({
          outpost: { ...state.outpost, greenhouseActive: nextState },
          objectives: state.objectives.map((o) =>
            o.id === outpostObjId ? { ...o, completed: true } : o
          )
        }));
        if (nextState) {
          get().unlockAchievement('ach_green_thumb');
          get().addLog('Hydroponic Greenhouse active: Cultivating dwarf crops and fresh oxygen.', 'science');
        } else {
          get().addLog('Hydroponic Greenhouse placed on standby.', 'info');
        }
      },

      toggleElectrolysis: () => {
        soundManager.playClick();
        const nextState = !get().outpost.electrolysisActive;
        set((state) => ({
          outpost: { ...state.outpost, electrolysisActive: nextState }
        }));
        get().addLog(nextState 
          ? 'Electrolysis unit online: Splitting H₂O into breathable O₂ and H₂ fuel.' 
          : 'Electrolysis unit offline.', 'info');
      },

      toggleShielding: () => {
        soundManager.playClick();
        const nextState = !get().outpost.shieldingActive;
        set((state) => ({
          outpost: { ...state.outpost, shieldingActive: nextState }
        }));
        get().addLog(nextState 
          ? 'Electromagnetic radiation deflectors powered up! High energy consumption.' 
          : 'Radiation shielding disabled.', 'alert');
      },

      triggerWeatherAlert: (customAlert) => {
        soundManager.playWarning();
        const alert: SpaceWeatherAlert = customAlert || {
          id: 'storm_' + Date.now(),
          title: 'Solar Particle Event (SPE) Warning',
          type: 'cme',
          severity: 'high',
          radiationSurgeRate: 0.6,
          durationSeconds: 25,
          nasaReference: REAL_NASA_DONKI_ARCHIVE[1].source,
          educationalTip: 'Coronal Mass Ejections release trillions of protons at near-light speed. Base shields or deep regolith bunkers prevent radiation illness!'
        };
        set({ weatherAlert: alert });
        get().addLog(`SPACE WEATHER ALERT: ${alert.title}! Activate shielding or enter habitat shelter immediately.`, 'alert');
      },

      dismissWeatherAlert: () => {
        get().unlockAchievement('ach_storm_survivor');
        set({ weatherAlert: null });
        get().addLog('Solar particle storm subsided. Surface radiation returned to nominal levels.', 'success');
      },

      unlockAchievement: (id) => {
        const achievement = get().achievements.find(a => a.id === id);
        if (achievement && !achievement.unlocked) {
          soundManager.playAchievement();
          set((state) => ({
            achievements: state.achievements.map(a => 
              a.id === id ? { ...a, unlocked: true, unlockedAt: new Date().toLocaleTimeString() } : a
            ),
            score: state.score + 250
          }));
          get().addLog(`ACHIEVEMENT UNLOCKED: ${achievement.title} – ${achievement.description}`, 'success');
        }
      },

      addLog: (text, type = 'info') => {
        const mins = Math.floor(get().missionTime / 60);
        const secs = get().missionTime % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const newLog: ActivityLog = {
          id: Math.random().toString(36).substring(2, 9),
          timestamp: timeStr,
          text,
          type
        };
        set((state) => ({
          logs: [newLog, ...state.logs.slice(0, 40)]
        }));
      },

      tickSimulation: () => {
        const state = get();
        if (state.screen !== 'surface_exploration' && state.screen !== 'outpost_mgmt') {
          return;
        }

        const newTime = state.missionTime + 1;
        const outpost = state.outpost;
        const res = { ...state.resources };

        // Oxygen simulation:
        let o2Delta = -0.06; // standard consumption
        if (outpost.greenhouseActive) o2Delta += 0.04;
        if (outpost.electrolysisActive && res.water > 5) {
          o2Delta += 0.08;
          res.water = Math.max(0, res.water - 0.04);
        }
        res.oxygen = Math.max(0, Math.min(100, res.oxygen + o2Delta));

        // Water consumption
        res.water = Math.max(0, res.water - 0.02);

        // Food consumption
        let foodDelta = -0.02;
        if (outpost.greenhouseActive) foodDelta += 0.03;
        res.food = Math.max(0, Math.min(100, res.food + foodDelta));

        // Power balance
        let powerDelta = -0.05; // base base consumption
        if (outpost.solarArraysClean) powerDelta += 0.12; // daytime solar generation
        else powerDelta += 0.04; // dirty panels cut power

        if (outpost.shieldingActive) powerDelta -= 0.18; // high shield power draw
        if (outpost.electrolysisActive) powerDelta -= 0.08;

        res.power = Math.max(0, Math.min(100, res.power + powerDelta));

        // Radiation protection
        if (state.weatherAlert) {
          if (!outpost.shieldingActive) {
            res.radiationProtection = Math.max(0, res.radiationProtection - state.weatherAlert.radiationSurgeRate * 0.4);
            if (res.radiationProtection < 30) soundManager.playWarning();
          }
        } else {
          // Slow recovery inside shielded outpost
          if (res.radiationProtection < 100) {
            res.radiationProtection = Math.min(100, res.radiationProtection + 0.05);
          }
        }

        // Rover passive battery recharge if daytime solar panels installed
        if (state.vehicleMode !== 'rover' && res.roverBattery < 100) {
          res.roverBattery = Math.min(100, res.roverBattery + 0.08);
        }

        // Random space weather trigger (low chance after 60 seconds)
        if (!state.weatherAlert && newTime > 40 && Math.random() < 0.005) {
          get().triggerWeatherAlert();
        }

        // Low resource sound alert
        if (res.oxygen < 20 || res.power < 15 || res.radiationProtection < 25) {
          if (newTime % 8 === 0) soundManager.playWarning();
        }

        // Check if all objectives completed
        const allCompleted = state.objectives.every(o => o.completed);
        if (allCompleted) {
          get().unlockAchievement('ach_nasa_scholar');
        }

        set({
          missionTime: newTime,
          resources: res
        });
      },

      toggleSound: () => {
        const next = !get().soundMuted;
        soundManager.setMuted(next);
        set({ soundMuted: next });
      },

      setShowNasaModal: (show) => {
        set({ showNasaModal: show });
      },

      resetGame: () => {
        soundManager.playClick();
        set({
          screen: 'station',
          astronaut: INITIAL_ASTRONAUT,
          equipment: INITIAL_EQUIPMENT,
          selectedMission: 'moon',
          resources: INITIAL_RESOURCES,
          vehicleMode: 'astronaut',
          astronautPosition: [0, 0, 0],
          roverPosition: [6, 0, 4],
          roverRotation: 0,
          outpost: INITIAL_OUTPOST,
          samples: MOON_SAMPLES,
          objectives: MISSIONS_DATA.moon.objectives,
          weatherAlert: null,
          currentEvent: null,
          achievements: INITIAL_ACHIEVEMENTS,
          missionTime: 0,
          score: 100,
          logs: [
            {
              id: '1',
              timestamp: '00:00',
              text: 'Mission reset. Ready for next space expedition!',
              type: 'info'
            }
          ]
        });
      }
    }),
    {
      name: 'vyomveer_game_state_v1',
      partialize: (state) => ({
        astronaut: state.astronaut,
        equipment: state.equipment,
        selectedMission: state.selectedMission,
        achievements: state.achievements,
        score: state.score,
        soundMuted: state.soundMuted
      })
    }
  )
);
