import React from 'react';
import { 
  ArrowLeft, 
  Wind, 
  Droplet, 
  Utensils, 
  Sun, 
  Zap, 
  Search, 
  Radio, 
  ShieldAlert, 
  Hammer, 
  Plus, 
  Minus,
  CheckCircle2,
  Info
} from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { EQUIPMENT_CATALOG, EquipmentItemInfo } from '../../data/equipmentData';

export const EquipmentSelector: React.FC = () => {
  const equipment = useGameStore((state) => state.equipment);
  const updateEquipment = useGameStore((state) => state.updateEquipment);
  const setScreen = useGameStore((state) => state.setScreen);

  // Compute total weight
  const totalWeight = EQUIPMENT_CATALOG.reduce((acc, item) => {
    return acc + equipment[item.key] * item.weightPerUnitKg;
  }, 0);

  const maxPayloadKg = 600;
  const weightPercent = Math.min(100, Math.round((totalWeight / maxPayloadKg) * 100));

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Wind': return <Wind className="w-5 h-5 text-[#00D9FF]" />;
      case 'Droplet': return <Droplet className="w-5 h-5 text-[#168BFF]" />;
      case 'Utensils': return <Utensils className="w-5 h-5 text-[#FF9D42]" />;
      case 'Sun': return <Sun className="w-5 h-5 text-[#FFD700]" />;
      case 'Zap': return <Zap className="w-5 h-5 text-[#39FF14]" />;
      case 'Search': return <Search className="w-5 h-5 text-[#8B5CF6]" />;
      case 'Radio': return <Radio className="w-5 h-5 text-[#00D9FF]" />;
      case 'ShieldAlert': return <ShieldAlert className="w-5 h-5 text-[#FF3B30]" />;
      case 'Hammer': return <Hammer className="w-5 h-5 text-[#FF9D42]" />;
      default: return <Wind className="w-5 h-5 text-[#00D9FF]" />;
    }
  };

  const handleAdjust = (key: keyof typeof equipment, delta: number, min: number, max: number) => {
    const current = equipment[key];
    const next = Math.max(min, Math.min(max, current + delta));
    updateEquipment({ [key]: next });
  };

  return (
    <div className="absolute inset-0 bg-[#061329] flex flex-col z-20 overflow-hidden">
      {/* --- TOP BAR --- */}
      <div className="p-5 border-b border-[#00D9FF]/30 bg-[#0B1F3A]/90 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setScreen('customization')}
            className="flex items-center space-x-2 bg-[#061329] hover:bg-[#168BFF]/40 border border-[#00D9FF]/40 rounded-xl px-3.5 py-2 text-xs text-white transition"
          >
            <ArrowLeft className="w-4 h-4 text-[#00D9FF]" />
            <span>Astronaut</span>
          </button>
          <div>
            <h2 className="text-xl font-bold font-orbitron text-white">Cargo & Life Support Bay</h2>
            <p className="text-xs text-slate-300">Equip your spacecraft with life support, power arrays, and science tools.</p>
          </div>
        </div>

        {/* Payload Weight Indicator */}
        <div className="flex items-center space-x-4 bg-[#061329] border border-[#00D9FF]/40 rounded-xl px-4 py-2">
          <div>
            <div className="text-[10px] text-slate-400 font-mono">PAYLOAD CAPACITY</div>
            <div className="text-sm font-bold text-white font-mono">
              {totalWeight} kg <span className="text-slate-400">/ {maxPayloadKg} kg</span>
            </div>
          </div>
          <div className="w-28 bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-700">
            <div 
              className={`h-full transition-all duration-300 ${
                weightPercent > 90 ? 'bg-red-500' : weightPercent > 70 ? 'bg-[#FF9D42]' : 'bg-[#00D9FF]'
              }`}
              style={{ width: `${weightPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* --- EQUIPMENT CARDS GRID --- */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {EQUIPMENT_CATALOG.map((item) => {
            const count = equipment[item.key];
            return (
              <div
                key={item.key}
                className="bg-[#0B1F3A]/80 border border-[#00D9FF]/25 hover:border-[#00D9FF]/50 rounded-2xl p-4.5 flex flex-col justify-between shadow-lg transition duration-200"
              >
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 bg-[#061329] rounded-xl border border-[#00D9FF]/30">
                        {getIcon(item.icon)}
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white font-space leading-tight">{item.name}</h3>
                        <span className="text-[10px] font-mono text-[#00D9FF]">{item.weightPerUnitKg} kg / unit</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 mb-3">{item.description}</p>

                  <div className="p-2.5 bg-[#061329]/90 rounded-xl border border-slate-800 text-[11px] text-slate-200 space-y-1">
                    <div className="text-[#39FF14] font-medium flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{item.effectExplanation}</span>
                    </div>
                    <div className="text-slate-400 text-[10px] italic">
                      NASA Fact: {item.nasaFact}
                    </div>
                  </div>
                </div>

                {/* Counter controls */}
                <div className="flex items-center justify-between pt-4 mt-3 border-t border-slate-800">
                  <span className="text-xs text-slate-400 font-mono">QUANTITY:</span>
                  <div className="flex items-center space-x-3 bg-[#061329] px-2 py-1 rounded-lg border border-slate-700">
                    <button
                      onClick={() => handleAdjust(item.key, -1, item.min, item.max)}
                      disabled={count <= item.min}
                      className="p-1 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="font-mono font-bold text-sm text-[#00D9FF] w-6 text-center">{count}</span>
                    <button
                      onClick={() => handleAdjust(item.key, 1, item.min, item.max)}
                      disabled={count >= item.max || totalWeight + item.weightPerUnitKg > maxPayloadKg}
                      className="p-1 text-slate-400 hover:text-white disabled:opacity-30 disabled:hover:text-slate-400"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* --- BOTTOM PROCEED BAR --- */}
      <div className="p-4 border-t border-[#00D9FF]/30 bg-[#0B1F3A]/90 flex justify-between items-center px-8">
        <button
          onClick={() => setScreen('station')}
          className="text-xs text-slate-400 hover:text-white font-mono"
        >
          Cancel & Return
        </button>
        <button
          onClick={() => setScreen('mission_select')}
          className="py-3 px-8 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:from-[#1a94ff] hover:to-[#22e3ff] text-slate-950 font-bold rounded-xl transition duration-200 font-orbitron text-xs tracking-wider shadow-lg shadow-[#00D9FF]/20"
        >
          CONFIRM PAYLOAD & SELECT MISSION →
        </button>
      </div>
    </div>
  );
};
