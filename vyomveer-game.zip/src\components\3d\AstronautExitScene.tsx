import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Stars, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { Rocket3D } from './Rocket3D';
import { Astronaut3D } from './Astronaut3D';
import { Outpost3D } from './Outpost3D';
import { HoloPlanet } from './PlanetsHolo';
import { useGameStore } from '../../store/useGameStore';

export const AstronautExitScene: React.FC = () => {
  const selectedMission = useGameStore((state) => state.selectedMission);
  const finishExitToExploration = useGameStore((state) => state.finishExitToExploration);

  const [phase, setPhase] = useState<'hatch_opening' | 'elevator_descending' | 'walking_off' | 'flag_planted'>('hatch_opening');
  const [elevatorProgress, setElevatorProgress] = useState(0); // 0 to 1
  const [astronautPos, setAstronautPos] = useState<[number, number, number]>([0, 3.8, 1.6]);
  const [astronautWalking, setAstronautWalking] = useState(false);
  const [showFlag, setShowFlag] = useState(false);

  const startTimeRef = useRef<number>(Date.now());
  const isMoon = selectedMission === 'moon';
  const terrainColor = isMoon ? '#475569' : '#993D22';
  const skyColor = isMoon ? '#061329' : '#451A14';

  useEffect(() => {
    startTimeRef.current = Date.now();
  }, []);

  useFrame(() => {
    const elapsed = (Date.now() - startTimeRef.current) / 1000;

    // Timeline:
    // 0.0s - 2.0s: Hatch opens with steam whoosh
    // 2.0s - 5.5s: Elevator descends with astronaut from y=3.8 to y=0.15
    // 5.5s - 7.5s: Astronaut walks off platform onto the surface regolith
    // 7.5s+: Flag appears planted, victory pose!

    if (elapsed < 2.0) {
      setPhase('hatch_opening');
      setAstronautPos([0, 3.8, 1.6]);
      setElevatorProgress(0);
      setAstronautWalking(false);
    } else if (elapsed >= 2.0 && elapsed < 5.5) {
      setPhase('elevator_descending');
      const p = (elapsed - 2.0) / 3.5;
      setElevatorProgress(p);
      const currentY = 3.8 - p * 3.65;
      setAstronautPos([0, currentY, 1.95]);
      setAstronautWalking(false);
    } else if (elapsed >= 5.5 && elapsed < 7.5) {
      setPhase('walking_off');
      const walkP = (elapsed - 5.5) / 2.0;
      setAstronautWalking(true);
      // Walk forward in +Z direction from 1.95 to 3.8
      setAstronautPos([0, 0.15, 1.95 + walkP * 1.85]);
    } else {
      setPhase('flag_planted');
      setAstronautWalking(false);
      setShowFlag(true);
      setAstronautPos([0, 0.15, 3.8]);
    }
  });

  return (
    <>
      <ambientLight intensity={isMoon ? 0.4 : 0.6} />
      <directionalLight position={[15, 20, 10]} intensity={isMoon ? 1.8 : 1.4} castShadow />
      <color attach="background" args={[skyColor]} />
      {isMoon && <Stars radius={120} depth={50} count={5000} factor={4} fade />}

      <OrbitControls 
        enablePan={false} 
        enableZoom={true} 
        minDistance={3} 
        maxDistance={15} 
        target={[0, 1.8, 2.5]} 
      />

      {/* Earth or Sun in sky */}
      {isMoon ? (
        <group position={[-25, 20, -50]}>
          <HoloPlanet planet="earth" radius={6} showAtmosphere={true} />
        </group>
      ) : (
        <group position={[-20, 22, -40]}>
          <HoloPlanet planet="sun" radius={3} showAtmosphere={true} />
        </group>
      )}

      {/* --- STANDING ROCKET --- */}
      <group position={[0, 0, 0]}>
        <Rocket3D 
          scale={1.2} 
          thrusterFiring={false} 
          legsExtended={true} 
          hatchOpen={true} 
          elevatorProgress={elevatorProgress} 
        />
      </group>

      {/* --- CUSTOMIZED ASTRONAUT EXITING --- */}
      <group position={astronautPos}>
        <Astronaut3D 
          scale={0.9} 
          isWalking={astronautWalking} 
          rotationY={phase === 'flag_planted' ? 0.3 : 0} 
        />
      </group>

      {/* --- PLANTED EXPEDITION MISSION FLAG --- */}
      {showFlag && (
        <group position={[0.7, 0, 3.8]}>
          {/* Flagpole */}
          <mesh position={[0, 1.1, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 2.2, 8]} />
            <meshStandardMaterial color="#D1D5DB" metalness={0.9} roughness={0.1} />
          </mesh>
          {/* Flag Fabric Banner */}
          <mesh position={[0.35, 1.8, 0]}>
            <boxGeometry args={[0.7, 0.45, 0.02]} />
            <meshStandardMaterial 
              color={isMoon ? '#00D9FF' : '#FF9D42'} 
              roughness={0.6} 
              emissive={isMoon ? '#00D9FF' : '#FF9D42'} 
              emissiveIntensity={0.3} 
            />
          </mesh>
          {/* Gold Finial on top */}
          <mesh position={[0, 2.22, 0]}>
            <sphereGeometry args={[0.05, 12, 12]} />
            <meshStandardMaterial color="#FFD700" metalness={0.9} />
          </mesh>
        </group>
      )}

      {/* --- LANDING SITE TERRAIN --- */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[100, 100, 32, 32]} />
        <meshStandardMaterial color={terrainColor} roughness={0.9} metalness={0.1} />
      </mesh>

      {/* Landing Pad */}
      <mesh position={[0, 0.02, 0]} receiveShadow>
        <cylinderGeometry args={[5.5, 5.8, 0.15, 6]} />
        <meshStandardMaterial color="#1E293B" metalness={0.6} roughness={0.5} />
      </mesh>

      {/* Base in background */}
      <group position={[18, 0, -10]}>
        <Outpost3D scale={0.7} destination={selectedMission} />
      </group>
    </>
  );
};
