import React from 'react';
import { 
  X, 
  Sun, 
  Wind, 
  Droplet, 
  Utensils, 
  ShieldAlert, 
  Sparkles, 
  Power, 
  CheckCircle, 
  AlertTriangle,
  Activity,
  Calculator
} from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';

export const OutpostManagerModal: React.FC = () => {
  const setScreen = useGameStore((state) => state.setScreen);
  const resources = useGameStore((state) => state.resources);
  const outpost = useGameStore((state) => state.outpost);
  const cleanSolarPanels = useGameStore((state) => state.cleanSolarPanels);
  const toggleGreenhouse = useGameStore((state) => state.toggleGreenhouse);
  const toggleElectrolysis = useGameStore((state) => state.toggleElectrolysis);
  const toggleShielding = useGameStore((state) => state.toggleShielding);
  const selectedMission = useGameStore((state) => state.selectedMission);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-40 flex items-center justify-center p-4">
      <div className="bg-[#0B1F3A] border-2 border-[#00D9FF] rounded-3xl max-w-4xl w-full p-6 text-white shadow-2xl relative max-h-[92vh] overflow-y-auto flex flex-col justify-between">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-700 pb-4 mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-[#061329] rounded-2xl border border-[#00D9FF]/40">
              <Activity className="w-6 h-6 text-[#00D9FF]" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-[#00D9FF]">CENTRAL SIMULATION ENGINE</div>
              <h2 className="text-xl font-bold font-orbitron text-white">
                {selectedMission === 'moon' ? 'Artemis Base Camp Life Support' : 'Ares Habitat Environmental Controls'}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setScreen('surface_exploration')}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* --- MATHEMATICAL RESOURCE SIMULATION FORMULA BANNER --- */}
        <div className="bg-[#061329] border border-[#00D9FF]/30 rounded-2xl p-4 mb-5 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <Calculator className="w-5 h-5 text-[#FF9D42]" />
            <div>
              <div className="text-xs font-mono font-bold text-white">
                Formula: <span className="text-[#00D9FF]">Remaining</span> = Initial + Generated - Consumed
              </div>
              <div className="text-[11px] text-slate-300">
                All systems compute real-time delta values. Balances reflect actual life support physics!
              </div>
            </div>
          </div>
          <div className="text-xs font-mono bg-[#0B1F3A] px-3 py-1.5 rounded-lg border border-slate-700 text-[#39FF14]">
            HABITAT INTEGRITY: 100%
          </div>
        </div>

        {/* --- 4 INTERACTIVE MANAGEMENT CARDS --- */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* 1. Solar Panels & Dust Maintenance */}
          <div className="bg-[#061329] border border-slate-700 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <Sun className="w-5 h-5 text-[#FFD700]" />
                  <h3 className="text-sm font-bold text-white font-space">Solar Array Dust Cleaning</h3>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  outpost.solarArraysClean ? 'bg-green-950 text-[#39FF14] border border-green-700' : 'bg-amber-950 text-amber-400 border border-amber-700'
                }`}>
                  {outpost.solarArraysClean ? '100% CLEAN' : 'DUST COATED (-50%)'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-2">
                {selectedMission === 'moon' 
                  ? 'Electrostatic lunar regolith dust clings to glass, cutting solar electricity in half.'
                  : 'Martian dust storms coat photovoltaic panels in iron oxide rust powder.'}
              </p>
              <div className="text-[11px] font-mono text-[#00D9FF] bg-[#0B1F3A] p-2 rounded-lg">
                Generates: +12 kW Power/sec when clean (currently {outpost.solarArraysClean ? '+12' : '+4'} kW)
              </div>
            </div>

            <button
              onClick={cleanSolarPanels}
              disabled={outpost.solarArraysClean}
              className={`mt-4 py-2.5 px-4 rounded-xl text-xs font-bold font-orbitron flex items-center justify-center space-x-2 transition ${
                outpost.solarArraysClean
                  ? 'bg-slate-800 text-slate-500 cursor-default'
                  : 'bg-[#FF9D42] text-slate-950 hover:bg-white shadow-lg'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{outpost.solarArraysClean ? 'ARRAYS OPTIMAL' : 'WIPE DUST OFF PANELS (+15 PWR)'}</span>
            </button>
          </div>

          {/* 2. Hydroponic Greenhouse Bio-Dome */}
          <div className="bg-[#061329] border border-slate-700 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <Utensils className="w-5 h-5 text-[#39FF14]" />
                  <h3 className="text-sm font-bold text-white font-space">Hydroponic Greenhouse</h3>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  outpost.greenhouseActive ? 'bg-green-950 text-[#39FF14] border border-green-700' : 'bg-slate-800 text-slate-400'
                }`}>
                  {outpost.greenhouseActive ? 'ONLINE' : 'STANDBY'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-2">
                Cultivates dwarf wheat, red romaine lettuce, and algae using LED grow lamps and recycled water.
              </p>
              <div className="text-[11px] font-mono text-[#39FF14] bg-[#0B1F3A] p-2 rounded-lg">
                Yield: +0.03 Food/sec & +0.04 O₂/sec (Uses 0.05 Power/sec)
              </div>
            </div>

            <button
              onClick={toggleGreenhouse}
              className={`mt-4 py-2.5 px-4 rounded-xl text-xs font-bold font-orbitron flex items-center justify-center space-x-2 transition ${
                outpost.greenhouseActive
                  ? 'bg-red-500/20 text-red-300 border border-red-500 hover:bg-red-500/40'
                  : 'bg-[#39FF14] text-slate-950 hover:bg-white shadow-lg'
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{outpost.greenhouseActive ? 'PUT ON STANDBY' : 'ACTIVATE BIO-GREENHOUSE'}</span>
            </button>
          </div>

          {/* 3. Water Electrolysis / MOXIE O2 Generation */}
          <div className="bg-[#061329] border border-slate-700 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <Wind className="w-5 h-5 text-[#00D9FF]" />
                  <h3 className="text-sm font-bold text-white font-space">
                    {selectedMission === 'moon' ? 'Water-Ice Electrolysis (H₂O → O₂)' : 'MOXIE CO₂ Oxygen Generator'}
                  </h3>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  outpost.electrolysisActive ? 'bg-green-950 text-[#39FF14] border border-green-700' : 'bg-slate-800 text-slate-400'
                }`}>
                  {outpost.electrolysisActive ? 'ONLINE' : 'STANDBY'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-2">
                {selectedMission === 'moon' 
                  ? 'Splits harvested lunar ice into breathable oxygen gas and liquid hydrogen rocket propellant.'
                  : 'NASA MOXIE instrument electrochemically extracts oxygen molecules from Martian atmospheric CO₂.'}
              </p>
              <div className="text-[11px] font-mono text-[#00D9FF] bg-[#0B1F3A] p-2 rounded-lg">
                Yield: +0.08 O₂/sec (Consumes 0.04 H₂O/sec & 0.08 Power/sec)
              </div>
            </div>

            <button
              onClick={toggleElectrolysis}
              className={`mt-4 py-2.5 px-4 rounded-xl text-xs font-bold font-orbitron flex items-center justify-center space-x-2 transition ${
                outpost.electrolysisActive
                  ? 'bg-red-500/20 text-red-300 border border-red-500 hover:bg-red-500/40'
                  : 'bg-[#00D9FF] text-slate-950 hover:bg-white shadow-lg'
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{outpost.electrolysisActive ? 'DEACTIVATE ELECTROLYSIS' : 'ACTIVATE HIGH-O₂ GENERATOR'}</span>
            </button>
          </div>

          {/* 4. Electromagnetic Radiation Deflector Shielding */}
          <div className="bg-[#061329] border border-slate-700 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <ShieldAlert className="w-5 h-5 text-[#8B5CF6]" />
                  <h3 className="text-sm font-bold text-white font-space">Electromagnetic Deflector Shields</h3>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  outpost.shieldingActive ? 'bg-purple-950 text-[#8B5CF6] border border-purple-700' : 'bg-slate-800 text-slate-400'
                }`}>
                  {outpost.shieldingActive ? 'SHIELDS CHARGED' : 'SHIELDS OFFLINE'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-2">
                Creates an artificial magnetic bubble around the habitat to deflect cosmic rays and solar storm protons.
              </p>
              <div className="text-[11px] font-mono text-[#8B5CF6] bg-[#0B1F3A] p-2 rounded-lg">
                Protection: 100% Radiation Immunity (Consumes 0.18 Power/sec)
              </div>
            </div>

            <button
              onClick={toggleShielding}
              className={`mt-4 py-2.5 px-4 rounded-xl text-xs font-bold font-orbitron flex items-center justify-center space-x-2 transition ${
                outpost.shieldingActive
                  ? 'bg-red-500/20 text-red-300 border border-red-500 hover:bg-red-500/40'
                  : 'bg-[#8B5CF6] text-white hover:bg-white hover:text-slate-950 shadow-lg'
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{outpost.shieldingActive ? 'DISENGAGE DEFLECTORS' : 'ENGAGE RADIATION SHIELDS'}</span>
            </button>
          </div>
        </div>

        {/* Bottom Return Button */}
        <div className="pt-4 border-t border-slate-700 flex justify-end">
          <button
            onClick={() => setScreen('surface_exploration')}
            className="py-3 px-8 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] text-slate-950 font-bold rounded-xl font-orbitron text-xs tracking-wider"
          >
            RETURN TO SURFACE EXPLORATION →
          </button>
        </div>
      </div>
    </div>
  );
};
