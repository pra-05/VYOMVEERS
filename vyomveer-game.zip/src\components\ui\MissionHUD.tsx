import React, { useState } from 'react';
import { 
  Wind, 
  Droplet, 
  Utensils, 
  Zap, 
  ShieldAlert, 
  BatteryCharging, 
  Car, 
  Footprints, 
  Target, 
  Settings, 
  Radio, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Award, 
  Trophy 
} from 'lucide-react';
import { useGameStore } from '../../store/useGameStore';
import { MISSIONS_DATA } from '../../data/missionsData';

interface MissionHUDProps {
  nearSampleId: string | null;
  nearRover: boolean;
  nearOutpost: boolean;
}

export const MissionHUD: React.FC<MissionHUDProps> = ({
  nearSampleId,
  nearRover,
  nearOutpost
}) => {
  const selectedMission = useGameStore((state) => state.selectedMission);
  const resources = useGameStore((state) => state.resources);
  const vehicleMode = useGameStore((state) => state.vehicleMode);
  const toggleVehicleMode = useGameStore((state) => state.toggleVehicleMode);
  const objectives = useGameStore((state) => state.objectives);
  const score = useGameStore((state) => state.score);
  const missionTime = useGameStore((state) => state.missionTime);
  const soundMuted = useGameStore((state) => state.soundMuted);
  const toggleSound = useGameStore((state) => state.toggleSound);
  const setScreen = useGameStore((state) => state.setScreen);
  const setShowNasaModal = useGameStore((state) => state.setShowNasaModal);
  const samples = useGameStore((state) => state.samples);
  const collectSample = useGameStore((state) => state.collectSample);
  const weatherAlert = useGameStore((state) => state.weatherAlert);

  const [showObjectivesDrawer, setShowObjectivesDrawer] = useState(false);

  const mission = MISSIONS_DATA[selectedMission];
  const minutes = Math.floor(missionTime / 60);
  const seconds = missionTime % 60;
  const timeFormatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const nearSample = samples.find(s => s.id === nearSampleId);
  const completedObjectivesCount = objectives.filter(o => o.completed).length;

  // Simulate directional key press for on-screen touch D-Pad
  const triggerKeyEvent = (key: string, type: 'keydown' | 'keyup') => {
    window.dispatchEvent(new KeyboardEvent(type, { key }));
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 z-20">
      {/* --- TOP HUD BAR --- */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-3 pointer-events-auto">
        {/* Mission Identification & Timer */}
        <div className="bg-[#0B1F3A]/90 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl p-3 shadow-lg flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-[#061329] border border-[#00D9FF]/30">
            {vehicleMode === 'rover' ? (
              <Car className="w-5 h-5 text-[#00D9FF]" />
            ) : (
              <Footprints className="w-5 h-5 text-[#FF9D42]" />
            )}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#168BFF]/30 text-[#00D9FF] font-bold">
                {mission.planetName.toUpperCase()}
              </span>
              <span className="text-[11px] font-mono text-slate-300">T+ {timeFormatted}</span>
            </div>
            <div className="text-sm font-bold font-orbitron text-white">
              {vehicleMode === 'rover' ? 'ROVER DRIVE MODE' : 'ASTRONAUT EVA ON FOOT'}
            </div>
          </div>
        </div>

        {/* Live Resource Gauge Bars */}
        <div className="bg-[#0B1F3A]/90 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl p-3 shadow-lg flex flex-wrap items-center gap-3 font-mono">
          {/* Oxygen */}
          <div className="flex items-center space-x-1.5" title="Oxygen (O2)">
            <Wind className={`w-4 h-4 ${resources.oxygen < 25 ? 'text-red-400 animate-pulse' : 'text-[#00D9FF]'}`} />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">O₂</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.oxygen)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div 
                className={`h-full ${resources.oxygen < 25 ? 'bg-red-500' : 'bg-[#00D9FF]'}`}
                style={{ width: `${resources.oxygen}%` }}
              />
            </div>
          </div>

          {/* Water */}
          <div className="flex items-center space-x-1.5" title="Water (H2O)">
            <Droplet className="w-4 h-4 text-[#168BFF]" />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">H₂O</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.water)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div className="h-full bg-[#168BFF]" style={{ width: `${resources.water}%` }} />
            </div>
          </div>

          {/* Food */}
          <div className="flex items-center space-x-1.5" title="Nutrition">
            <Utensils className="w-4 h-4 text-[#FF9D42]" />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">FOOD</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.food)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div className="h-full bg-[#FF9D42]" style={{ width: `${resources.food}%` }} />
            </div>
          </div>

          {/* Power */}
          <div className="flex items-center space-x-1.5" title="Base & Suit Power">
            <Zap className={`w-4 h-4 ${resources.power < 20 ? 'text-red-400 animate-pulse' : 'text-[#FFD700]'}`} />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">PWR</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.power)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div 
                className={`h-full ${resources.power < 20 ? 'bg-red-500' : 'bg-[#FFD700]'}`}
                style={{ width: `${resources.power}%` }}
              />
            </div>
          </div>

          {/* Radiation Protection */}
          <div className="flex items-center space-x-1.5" title="Radiation Shielding">
            <ShieldAlert className={`w-4 h-4 ${resources.radiationProtection < 30 ? 'text-red-400 animate-pulse' : 'text-[#8B5CF6]'}`} />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">RAD</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.radiationProtection)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div 
                className={`h-full ${resources.radiationProtection < 30 ? 'bg-red-500' : 'bg-[#8B5CF6]'}`}
                style={{ width: `${resources.radiationProtection}%` }}
              />
            </div>
          </div>

          {/* Rover Battery */}
          <div className="flex items-center space-x-1.5" title="Rover Battery">
            <BatteryCharging className="w-4 h-4 text-[#39FF14]" />
            <div className="text-right">
              <div className="text-[9px] text-slate-400">ROVER</div>
              <div className="text-xs font-bold text-white">{Math.round(resources.roverBattery)}%</div>
            </div>
            <div className="w-12 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
              <div className="h-full bg-[#39FF14]" style={{ width: `${resources.roverBattery}%` }} />
            </div>
          </div>
        </div>

        {/* Score & Sound Toggle */}
        <div className="flex items-center space-x-2">
          <div className="bg-[#0B1F3A]/90 border border-[#00D9FF]/40 rounded-2xl px-3.5 py-2.5 text-xs font-mono text-white flex items-center space-x-2 shadow-lg">
            <Trophy className="w-4 h-4 text-[#FFD700]" />
            <span>XP: <strong className="text-[#00D9FF]">{score}</strong></span>
          </div>

          <button
            onClick={toggleSound}
            className="p-3 bg-[#0B1F3A]/90 hover:bg-[#168BFF]/30 border border-[#00D9FF]/40 rounded-2xl transition text-[#00D9FF] shadow-lg"
          >
            {soundMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-[#00D9FF]" />}
          </button>
        </div>
      </div>

      {/* --- SPACE WEATHER ALERT BANNER (IF ACTIVE) --- */}
      {weatherAlert && (
        <div className="mx-auto my-2 max-w-xl w-full bg-red-950/90 border-2 border-red-500 rounded-2xl p-3 flex items-center justify-between text-white shadow-2xl animate-pulse pointer-events-auto">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <div>
              <div className="text-xs font-bold font-orbitron text-red-300">{weatherAlert.title}</div>
              <div className="text-[11px] text-slate-200">NASA DONKI Warning: High solar proton flux! Shelter or activate shields.</div>
            </div>
          </div>
          <button
            onClick={() => setScreen('outpost_mgmt')}
            className="px-3 py-1.5 bg-red-600 hover:bg-red-500 font-bold rounded-lg text-xs font-orbitron"
          >
            BASE SHIELDS
          </button>
        </div>
      )}

      {/* --- PROXIMITY INTERACTIVE PROMPT BANNER --- */}
      <div className="max-w-lg mx-auto w-full pointer-events-auto">
        {nearSample && (
          <div className="bg-[#0B1F3A]/95 border-2 border-[#00D9FF] rounded-2xl p-4 shadow-2xl flex items-center justify-between animate-bounce">
            <div>
              <div className="text-[10px] font-mono text-[#00D9FF]">SCIENTIFIC SAMPLE DETECTED</div>
              <h4 className="text-sm font-bold text-white">{nearSample.name}</h4>
              <p className="text-[11px] text-slate-300">{nearSample.scienceFact}</p>
            </div>
            <button
              onClick={() => collectSample(nearSample.id)}
              className="ml-3 px-4 py-2 bg-[#00D9FF] text-slate-950 font-bold font-orbitron text-xs rounded-xl shadow-md hover:bg-white"
            >
              COLLECT [E]
            </button>
          </div>
        )}

        {nearRover && !nearSample && (
          <div className="bg-[#0B1F3A]/95 border border-[#39FF14] rounded-2xl p-3.5 shadow-2xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Car className="w-6 h-6 text-[#39FF14]" />
              <div>
                <div className="text-[10px] font-mono text-[#39FF14]">VEHICLE STANDBY</div>
                <div className="text-xs font-bold text-white">Planetary Exploration Rover Available</div>
              </div>
            </div>
            <button
              onClick={toggleVehicleMode}
              className="px-4 py-2 bg-[#39FF14] text-slate-950 font-bold font-orbitron text-xs rounded-xl hover:bg-white"
            >
              MOUNT ROVER [E]
            </button>
          </div>
        )}

        {nearOutpost && !nearSample && !nearRover && (
          <div className="bg-[#0B1F3A]/95 border border-[#00D9FF] rounded-2xl p-3.5 shadow-2xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="w-6 h-6 text-[#00D9FF]" />
              <div>
                <div className="text-[10px] font-mono text-[#00D9FF]">RESEARCH OUTPOST AIRLOCK</div>
                <div className="text-xs font-bold text-white">Central Life Support Terminal</div>
              </div>
            </div>
            <button
              onClick={() => setScreen('outpost_mgmt')}
              className="px-4 py-2 bg-[#00D9FF] text-slate-950 font-bold font-orbitron text-xs rounded-xl hover:bg-white"
            >
              OPEN CONSOLE [E]
            </button>
          </div>
        )}
      </div>

      {/* --- BOTTOM CONTROLS & OBJECTIVES DOCK --- */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-3 pointer-events-auto">
        {/* Objectives Collapsible Pill */}
        <div className="w-full md:w-80 bg-[#0B1F3A]/90 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl overflow-hidden shadow-lg">
          <button
            onClick={() => setShowObjectivesDrawer(!showObjectivesDrawer)}
            className="w-full p-3 flex items-center justify-between text-left hover:bg-[#168BFF]/20 transition"
          >
            <div className="flex items-center space-x-2">
              <Target className="w-4 h-4 text-[#00D9FF]" />
              <span className="text-xs font-bold font-orbitron text-white">Mission Objectives</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#168BFF]/30 text-[#00D9FF]">
                {completedObjectivesCount}/{objectives.length}
              </span>
            </div>
            {showObjectivesDrawer ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronUp className="w-4 h-4 text-slate-400" />}
          </button>

          {showObjectivesDrawer && (
            <div className="p-3 pt-0 space-y-2 border-t border-slate-800 max-h-48 overflow-y-auto">
              {objectives.map((obj) => (
                <div key={obj.id} className="flex items-start space-x-2 text-xs">
                  {obj.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-[#39FF14] flex-shrink-0 mt-0.5" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div>
                    <div className={obj.completed ? 'line-through text-slate-400' : 'text-slate-200'}>
                      {obj.text}
                    </div>
                    {!obj.completed && <div className="text-[10px] text-[#00D9FF]">{obj.hint}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ON-SCREEN ROVER / ASTRONAUT BUTTONS (Requested by user!) */}
        <div className="flex items-center space-x-2 bg-[#0B1F3A]/90 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl p-2.5 shadow-lg">
          {/* Explicit Drive Rover Toggle Button */}
          <button
            onClick={toggleVehicleMode}
            className={`px-4 py-2.5 rounded-xl font-orbitron text-xs font-bold flex items-center space-x-2 shadow-md transition ${
              vehicleMode === 'rover'
                ? 'bg-[#39FF14] text-slate-950 hover:bg-white'
                : 'bg-gradient-to-r from-[#168BFF] to-[#00D9FF] text-slate-950 hover:from-[#22e3ff]'
            }`}
            title="Toggle between driving the rover and walking on foot"
          >
            {vehicleMode === 'rover' ? (
              <>
                <Footprints className="w-4 h-4" />
                <span>EXIT ROVER</span>
              </>
            ) : (
              <>
                <Car className="w-4 h-4" />
                <span>DRIVE ROVER</span>
              </>
            )}
          </button>

          {/* Outpost Management Button */}
          <button
            onClick={() => setScreen('outpost_mgmt')}
            className="p-2.5 bg-[#061329] hover:bg-[#168BFF]/30 border border-[#00D9FF]/30 rounded-xl text-[#00D9FF] text-xs font-medium flex items-center space-x-1.5"
            title="Manage Outpost Life Support"
          >
            <Settings className="w-4 h-4 text-[#00D9FF]" />
            <span className="hidden sm:inline font-mono">Outpost</span>
          </button>

          {/* NASA STEM Feed */}
          <button
            onClick={() => setShowNasaModal(true)}
            className="p-2.5 bg-[#061329] hover:bg-[#168BFF]/30 border border-[#00D9FF]/30 rounded-xl text-[#39FF14] text-xs font-medium flex items-center space-x-1.5"
            title="Open NASA STEM & Space Weather Briefing"
          >
            <Radio className="w-4 h-4 text-[#39FF14]" />
            <span className="hidden sm:inline font-mono">NASA</span>
          </button>

          {/* Finish Mission / Results */}
          <button
            onClick={() => setScreen('results')}
            className="p-2.5 bg-[#061329] hover:bg-[#168BFF]/30 border border-[#FF9D42]/40 rounded-xl text-[#FF9D42] text-xs font-medium flex items-center space-x-1.5"
            title="View Mission Debrief & Results"
          >
            <Award className="w-4 h-4 text-[#FF9D42]" />
            <span className="hidden sm:inline font-mono">Results</span>
          </button>

          {/* On-Screen D-PAD Movement Buttons (for Rover & Astronaut driving) */}
          <div className="flex items-center space-x-1 pl-2 border-l border-slate-700">
            <button
              onMouseDown={() => triggerKeyEvent('a', 'keydown')}
              onMouseUp={() => triggerKeyEvent('a', 'keyup')}
              onTouchStart={() => triggerKeyEvent('a', 'keydown')}
              onTouchEnd={() => triggerKeyEvent('a', 'keyup')}
              className="p-2 bg-[#061329] hover:bg-slate-700 active:bg-[#00D9FF] active:text-black rounded-lg text-slate-300"
              title="Steer Left"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div className="flex flex-col space-y-1">
              <button
                onMouseDown={() => triggerKeyEvent('w', 'keydown')}
                onMouseUp={() => triggerKeyEvent('w', 'keyup')}
                onTouchStart={() => triggerKeyEvent('w', 'keydown')}
                onTouchEnd={() => triggerKeyEvent('w', 'keyup')}
                className="p-2 bg-[#061329] hover:bg-slate-700 active:bg-[#00D9FF] active:text-black rounded-lg text-slate-300"
                title="Drive Forward"
              >
                <ArrowUp className="w-4 h-4" />
              </button>
              <button
                onMouseDown={() => triggerKeyEvent('s', 'keydown')}
                onMouseUp={() => triggerKeyEvent('s', 'keyup')}
                onTouchStart={() => triggerKeyEvent('s', 'keydown')}
                onTouchEnd={() => triggerKeyEvent('s', 'keyup')}
                className="p-2 bg-[#061329] hover:bg-slate-700 active:bg-[#00D9FF] active:text-black rounded-lg text-slate-300"
                title="Drive Reverse"
              >
                <ArrowDown className="w-4 h-4" />
              </button>
            </div>

            <button
              onMouseDown={() => triggerKeyEvent('d', 'keydown')}
              onMouseUp={() => triggerKeyEvent('d', 'keyup')}
              onTouchStart={() => triggerKeyEvent('d', 'keydown')}
              onTouchEnd={() => triggerKeyEvent('d', 'keyup')}
              className="p-2 bg-[#061329] hover:bg-slate-700 active:bg-[#00D9FF] active:text-black rounded-lg text-slate-300"
              title="Steer Right"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
