import React, { useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGameStore } from './store/useGameStore';

// 3D Scenes
import { SpaceStationScene } from './components/3d/SpaceStationScene';
import { RocketLandingScene } from './components/3d/RocketLandingScene';
import { AstronautExitScene } from './components/3d/AstronautExitScene';
import { SurfaceScene } from './components/3d/SurfaceScene';

// UI Screens and Modals
import { WelcomeScreen } from './components/ui/WelcomeScreen';
import { AstronautCustomizer } from './components/ui/AstronautCustomizer';
import { EquipmentSelector } from './components/ui/EquipmentSelector';
import { MissionSelector } from './components/ui/MissionSelector';
import { LaunchPrepModal } from './components/ui/LaunchPrepModal';
import { LaunchSequence } from './components/ui/LaunchSequence';
import { MissionHUD } from './components/ui/MissionHUD';
import { OutpostManagerModal } from './components/ui/OutpostManagerModal';
import { NASAInfoModal } from './components/ui/NASAInfoModal';
import { ResultsModal } from './components/ui/ResultsModal';

export const App: React.FC = () => {
  const screen = useGameStore((state) => state.screen);
  const tickSimulation = useGameStore((state) => state.tickSimulation);
  const finishLandingToExit = useGameStore((state) => state.finishLandingToExit);
  const finishExitToExploration = useGameStore((state) => state.finishExitToExploration);
  const selectedMission = useGameStore((state) => state.selectedMission);

  // Proximity states for surface exploration
  const [nearSampleId, setNearSampleId] = useState<string | null>(null);
  const [nearRover, setNearRover] = useState<boolean>(false);
  const [nearOutpost, setNearOutpost] = useState<boolean>(false);

  // Run central resource simulation tick every 1000ms
  useEffect(() => {
    const timer = setInterval(() => {
      tickSimulation();
    }, 1000);
    return () => clearInterval(timer);
  }, [tickSimulation]);

  return (
    <div className="w-screen h-screen relative bg-[#061329] overflow-hidden select-none font-space text-[#F3F8FF]">
      {/* =========================================================================
          SCREEN 1: SPACE STATION (ORBITAL GATEWAY)
          ========================================================================= */}
      {screen === 'station' && (
        <div className="w-full h-full relative">
          <Canvas camera={{ position: [0, 1.2, 5.5], fov: 50 }}>
            <SpaceStationScene />
          </Canvas>
          <WelcomeScreen />
        </div>
      )}

      {/* =========================================================================
          SCREEN 2: ASTRONAUT CUSTOMIZATION BAY
          ========================================================================= */}
      {screen === 'customization' && <AstronautCustomizer />}

      {/* =========================================================================
          SCREEN 3: EQUIPMENT SELECTION BAY
          ========================================================================= */}
      {screen === 'equipment' && <EquipmentSelector />}

      {/* =========================================================================
          SCREEN 4: MISSION SELECTION (MOON VS MARS)
          ========================================================================= */}
      {screen === 'mission_select' && <MissionSelector />}

      {/* =========================================================================
          SCREEN 5: PRE-FLIGHT LAUNCH CHECKLIST
          ========================================================================= */}
      {screen === 'launch_prep' && <LaunchPrepModal />}

      {/* =========================================================================
          SCREEN 6: ROCKET LAUNCH SEQUENCE
          ========================================================================= */}
      {screen === 'launch_anim' && <LaunchSequence />}

      {/* =========================================================================
          SCREEN 7: ROCKET LANDING ON MOON / MARS (CINEMATIC)
          ========================================================================= */}
      {screen === 'landing_anim' && (
        <div className="w-full h-full relative">
          <Canvas camera={{ position: [0, 5, 24], fov: 50 }}>
            <RocketLandingScene />
          </Canvas>

          {/* Landing Telemetry Overlay & Egress Trigger */}
          <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 z-20">
            <div className="bg-[#0B1F3A]/85 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl p-4 max-w-sm pointer-events-auto shadow-xl">
              <span className="text-[10px] font-mono text-[#00D9FF]">TOUCHDOWN RADAR</span>
              <h3 className="text-base font-bold font-orbitron text-white">
                {selectedMission === 'moon' ? 'Lunar South Pole Landing Site' : 'Jezero Crater Delta Touchdown'}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Retro-propulsion rockets firing. Surface ground sensors active.
              </p>
            </div>

            <div className="flex justify-center pointer-events-auto">
              <button
                onClick={finishLandingToExit}
                className="py-4 px-8 bg-gradient-to-r from-[#168BFF] to-[#00D9FF] hover:scale-105 text-slate-950 font-extrabold font-orbitron text-xs tracking-wider rounded-2xl shadow-xl shadow-[#00D9FF]/30 transition animate-pulse"
              >
                TOUCHDOWN CONFIRMED: EGRESS FROM SPACECRAFT →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 8: ASTRONAUT COME OUT FROM ROCKET SCENE (CINEMATIC)
          ========================================================================= */}
      {screen === 'exit_rocket_anim' && (
        <div className="w-full h-full relative">
          <Canvas camera={{ position: [0, 2.5, 7.5], fov: 48 }}>
            <AstronautExitScene />
          </Canvas>

          {/* Egress Banner Overlay & Proceed to Exploration */}
          <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 z-20">
            <div className="bg-[#0B1F3A]/85 backdrop-blur-md border border-[#00D9FF]/40 rounded-2xl p-4 max-w-md pointer-events-auto shadow-xl">
              <span className="text-[10px] font-mono text-[#39FF14]">AIRLOCK DEPRESSURIZED</span>
              <h3 className="text-base font-bold font-orbitron text-white">
                One Small Step for a Junior Astronaut!
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Airlock hatch open. Descending elevator to surface. Astronaut stepping onto {selectedMission === 'moon' ? 'lunar regolith' : 'Martian soil'}.
              </p>
            </div>

            <div className="flex justify-center pointer-events-auto">
              <button
                onClick={finishExitToExploration}
                className="py-4 px-8 bg-gradient-to-r from-[#FF9D42] to-[#FF3B30] hover:scale-105 text-white font-extrabold font-orbitron text-xs tracking-wider rounded-2xl shadow-xl shadow-orange-500/30 transition animate-pulse"
              >
                BEGIN SURFACE EXPLORATION & ROVER DEPLOYMENT →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 9: SURFACE EXPLORATION & ROVER DRIVING
          ========================================================================= */}
      {screen === 'surface_exploration' && (
        <div className="w-full h-full relative">
          <Canvas camera={{ position: [0, 4, 8], fov: 50 }}>
            <SurfaceScene
              onNearSample={setNearSampleId}
              onNearRover={setNearRover}
              onNearOutpost={setNearOutpost}
            />
          </Canvas>

          {/* Mission HUD & Rover Movement Controls */}
          <MissionHUD
            nearSampleId={nearSampleId}
            nearRover={nearRover}
            nearOutpost={nearOutpost}
          />
        </div>
      )}

      {/* =========================================================================
          SCREEN 10: OUTPOST LIFE SUPPORT MANAGEMENT MODAL OVERLAY
          ========================================================================= */}
      {screen === 'outpost_mgmt' && (
        <div className="w-full h-full relative">
          {/* Surface scene remains running in background */}
          <Canvas camera={{ position: [16, 4, -4], fov: 50 }}>
            <SurfaceScene />
          </Canvas>
          <OutpostManagerModal />
        </div>
      )}

      {/* =========================================================================
          SCREEN 11: MISSION RESULTS & ACHIEVEMENTS MODAL
          ========================================================================= */}
      {screen === 'results' && <ResultsModal />}

      {/* =========================================================================
          GLOBAL MODALS (NASA STEM Info Hub)
          ========================================================================= */}
      <NASAInfoModal />
    </div>
  );
};
