import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface HoloPlanetProps {
  planet: 'earth' | 'moon' | 'mars' | 'sun';
  radius?: number;
  rotationSpeed?: number;
  position?: [number, number, number];
  showAtmosphere?: boolean;
}

export const HoloPlanet: React.FC<HoloPlanetProps> = ({
  planet,
  radius = 2,
  rotationSpeed = 0.2,
  position = [0, 0, 0],
  showAtmosphere = true
}) => {
  const planetRef = useRef<THREE.Mesh>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (planetRef.current) {
      planetRef.current.rotation.y += delta * rotationSpeed;
    }
    if (cloudsRef.current) {
      cloudsRef.current.rotation.y += delta * (rotationSpeed * 1.3);
    }
    if (ringRef.current) {
      ringRef.current.rotation.z += delta * 0.1;
    }
  });

  // Color schemes for Three.js procedural planetary surfaces
  const getColor = () => {
    switch (planet) {
      case 'earth':
        return '#1E6BFF';
      case 'moon':
        return '#C2C5CC';
      case 'mars':
        return '#D9532F';
      case 'sun':
        return '#FF9D42';
    }
  };

  const getAtmosphereColor = () => {
    switch (planet) {
      case 'earth':
        return '#00D9FF';
      case 'moon':
        return '#FFFFFF';
      case 'mars':
        return '#FF7744';
      case 'sun':
        return '#FFAA00';
    }
  };

  return (
    <group position={position}>
      {/* --- PLANETARY SPHERE --- */}
      <mesh ref={planetRef} castShadow receiveShadow>
        <sphereGeometry args={[radius, 36, 36]} />
        <meshStandardMaterial 
          color={getColor()} 
          roughness={planet === 'moon' ? 0.9 : planet === 'mars' ? 0.8 : 0.4} 
          metalness={planet === 'sun' ? 0 : 0.15} 
          emissive={planet === 'sun' ? '#FF5500' : '#000000'}
          emissiveIntensity={planet === 'sun' ? 0.8 : 0}
        />
      </mesh>

      {/* Earth Continents Procedural Overlay Wireframe / Landmass Highlights */}
      {planet === 'earth' && (
        <mesh>
          <sphereGeometry args={[radius * 1.002, 28, 28]} />
          <meshStandardMaterial 
            color="#22C55E" 
            roughness={0.9} 
            wireframe={true} 
            transparent 
            opacity={0.35} 
          />
        </mesh>
      )}

      {/* Earth Cloud Layer */}
      {planet === 'earth' && (
        <mesh ref={cloudsRef}>
          <sphereGeometry args={[radius * 1.025, 32, 32]} />
          <meshStandardMaterial 
            color="#FFFFFF" 
            transparent 
            opacity={0.4} 
            roughness={1.0} 
            wireframe={false} 
          />
        </mesh>
      )}

      {/* Mars Craters / Canyon Highlight Rings */}
      {planet === 'mars' && (
        <mesh>
          <sphereGeometry args={[radius * 1.003, 24, 24]} />
          <meshStandardMaterial color="#882211" wireframe={true} transparent opacity={0.25} />
        </mesh>
      )}

      {/* Moon Crater Relief Texture wireframe */}
      {planet === 'moon' && (
        <mesh>
          <sphereGeometry args={[radius * 1.003, 24, 24]} />
          <meshStandardMaterial color="#666666" wireframe={true} transparent opacity={0.2} />
        </mesh>
      )}

      {/* --- ATMOSPHERIC GLOW SHELL --- */}
      {showAtmosphere && planet !== 'moon' && (
        <mesh>
          <sphereGeometry args={[radius * 1.08, 32, 32]} />
          <meshPhysicalMaterial 
            color={getAtmosphereColor()} 
            transparent 
            opacity={planet === 'sun' ? 0.5 : 0.25} 
            roughness={0.1} 
            metalness={0.1} 
            side={THREE.BackSide} 
          />
        </mesh>
      )}

      {/* Sun Solar Corona Radiance Light */}
      {planet === 'sun' && (
        <pointLight color="#FFAA00" intensity={8} distance={60} decay={1.5} />
      )}

      {/* Holographic Orbital Tracking Rings */}
      <group ref={ringRef} rotation={[Math.PI / 3, 0, 0]}>
        <mesh>
          <ringGeometry args={[radius * 1.35, radius * 1.37, 48]} />
          <meshBasicMaterial color="#00D9FF" transparent opacity={0.4} side={THREE.DoubleSide} />
        </mesh>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <ringGeometry args={[radius * 1.48, radius * 1.5, 48]} />
          <meshBasicMaterial color="#168BFF" transparent opacity={0.25} side={THREE.DoubleSide} />
        </mesh>
      </group>
    </group>
  );
};
